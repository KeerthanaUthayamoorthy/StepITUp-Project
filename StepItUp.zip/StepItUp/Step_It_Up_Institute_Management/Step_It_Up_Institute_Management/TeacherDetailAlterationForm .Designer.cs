﻿namespace Step_It_Up_Institute_Management
{
    partial class TeacherDetailAlterationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.BirthYear = new System.Windows.Forms.TextBox();
            this.EmailID = new System.Windows.Forms.TextBox();
            this.StudentFee = new System.Windows.Forms.TextBox();
            this.TelephoneNo = new System.Windows.Forms.TextBox();
            this.Address = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.TextBox();
            this.FirstName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Last_Name = new System.Windows.Forms.Label();
            this.First_Name = new System.Windows.Forms.Label();
            this.Sex = new System.Windows.Forms.TextBox();
            this.Subject = new System.Windows.Forms.TextBox();
            this.Updatebutton = new System.Windows.Forms.Button();
            this.Deletebutton = new System.Windows.Forms.Button();
            this.BirthMonth = new System.Windows.Forms.TextBox();
            this.BirthDate = new System.Windows.Forms.TextBox();
            this.TeacherID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(567, 363);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 47);
            this.button1.TabIndex = 55;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Clearbutton
            // 
            this.Clearbutton.Location = new System.Drawing.Point(378, 363);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(115, 47);
            this.Clearbutton.TabIndex = 54;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            // 
            // BirthYear
            // 
            this.BirthYear.Location = new System.Drawing.Point(236, 97);
            this.BirthYear.Name = "BirthYear";
            this.BirthYear.Size = new System.Drawing.Size(84, 20);
            this.BirthYear.TabIndex = 52;
            // 
            // EmailID
            // 
            this.EmailID.Location = new System.Drawing.Point(203, 285);
            this.EmailID.Name = "EmailID";
            this.EmailID.Size = new System.Drawing.Size(309, 20);
            this.EmailID.TabIndex = 47;
            // 
            // StudentFee
            // 
            this.StudentFee.Location = new System.Drawing.Point(203, 252);
            this.StudentFee.Name = "StudentFee";
            this.StudentFee.Size = new System.Drawing.Size(309, 20);
            this.StudentFee.TabIndex = 46;
            // 
            // TelephoneNo
            // 
            this.TelephoneNo.Location = new System.Drawing.Point(203, 220);
            this.TelephoneNo.Name = "TelephoneNo";
            this.TelephoneNo.Size = new System.Drawing.Size(309, 20);
            this.TelephoneNo.TabIndex = 45;
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(203, 190);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(309, 20);
            this.Address.TabIndex = 44;
            // 
            // LastName
            // 
            this.LastName.Location = new System.Drawing.Point(203, 59);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(309, 20);
            this.LastName.TabIndex = 43;
            // 
            // FirstName
            // 
            this.FirstName.Location = new System.Drawing.Point(203, 29);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(309, 20);
            this.FirstName.TabIndex = 42;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(97, 288);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(109, 20);
            this.label10.TabIndex = 41;
            this.label10.Text = "Email ID";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(519, 97);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 20);
            this.label9.TabIndex = 40;
            this.label9.Text = "Day";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(326, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 20);
            this.label8.TabIndex = 39;
            this.label8.Text = "Month";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(190, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 20);
            this.label7.TabIndex = 38;
            this.label7.Text = "Year";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(97, 252);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 20);
            this.label6.TabIndex = 37;
            this.label6.Text = "Student Fee";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(97, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 20);
            this.label5.TabIndex = 36;
            this.label5.Text = "Telephone No";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(97, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 20);
            this.label4.TabIndex = 35;
            this.label4.Text = "Address";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(97, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 20);
            this.label3.TabIndex = 34;
            this.label3.Text = "Subject";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(97, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 33;
            this.label2.Text = "Sex";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(97, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 20);
            this.label1.TabIndex = 32;
            this.label1.Text = "Date Of Birth";
            // 
            // Last_Name
            // 
            this.Last_Name.Location = new System.Drawing.Point(97, 62);
            this.Last_Name.Name = "Last_Name";
            this.Last_Name.Size = new System.Drawing.Size(109, 20);
            this.Last_Name.TabIndex = 31;
            this.Last_Name.Text = "Last Name";
            // 
            // First_Name
            // 
            this.First_Name.Location = new System.Drawing.Point(97, 32);
            this.First_Name.Name = "First_Name";
            this.First_Name.Size = new System.Drawing.Size(109, 20);
            this.First_Name.TabIndex = 30;
            this.First_Name.Text = "First Name";
            // 
            // Sex
            // 
            this.Sex.Location = new System.Drawing.Point(203, 130);
            this.Sex.Name = "Sex";
            this.Sex.Size = new System.Drawing.Size(309, 20);
            this.Sex.TabIndex = 56;
            // 
            // Subject
            // 
            this.Subject.Location = new System.Drawing.Point(203, 157);
            this.Subject.Name = "Subject";
            this.Subject.Size = new System.Drawing.Size(309, 20);
            this.Subject.TabIndex = 57;
            // 
            // Updatebutton
            // 
            this.Updatebutton.Location = new System.Drawing.Point(114, 364);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(115, 47);
            this.Updatebutton.TabIndex = 58;
            this.Updatebutton.Text = "Update Details";
            this.Updatebutton.UseVisualStyleBackColor = true;
            this.Updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // Deletebutton
            // 
            this.Deletebutton.Location = new System.Drawing.Point(257, 363);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(115, 47);
            this.Deletebutton.TabIndex = 59;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = true;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // BirthMonth
            // 
            this.BirthMonth.Location = new System.Drawing.Point(366, 97);
            this.BirthMonth.Name = "BirthMonth";
            this.BirthMonth.Size = new System.Drawing.Size(84, 20);
            this.BirthMonth.TabIndex = 60;
            // 
            // BirthDate
            // 
            this.BirthDate.Location = new System.Drawing.Point(567, 97);
            this.BirthDate.Name = "BirthDate";
            this.BirthDate.Size = new System.Drawing.Size(84, 20);
            this.BirthDate.TabIndex = 61;
            // 
            // TeacherID
            // 
            this.TeacherID.Location = new System.Drawing.Point(203, 3);
            this.TeacherID.Name = "TeacherID";
            this.TeacherID.Size = new System.Drawing.Size(309, 20);
            this.TeacherID.TabIndex = 62;
            // 
            // TeacherDetailAlterationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 439);
            this.Controls.Add(this.TeacherID);
            this.Controls.Add(this.BirthDate);
            this.Controls.Add(this.BirthMonth);
            this.Controls.Add(this.Deletebutton);
            this.Controls.Add(this.Updatebutton);
            this.Controls.Add(this.Subject);
            this.Controls.Add(this.Sex);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.BirthYear);
            this.Controls.Add(this.EmailID);
            this.Controls.Add(this.StudentFee);
            this.Controls.Add(this.TelephoneNo);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Last_Name);
            this.Controls.Add(this.First_Name);
            this.Name = "TeacherDetailAlterationForm";
            this.Text = "TeacherDetailAlterationForm";
            this.Load += new System.EventHandler(this.TeacherDetailAlterationForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.TextBox BirthYear;
        private System.Windows.Forms.TextBox EmailID;
        private System.Windows.Forms.TextBox StudentFee;
        private System.Windows.Forms.TextBox TelephoneNo;
        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.TextBox LastName;
        private System.Windows.Forms.TextBox FirstName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Last_Name;
        private System.Windows.Forms.Label First_Name;
        private System.Windows.Forms.TextBox Sex;
        private System.Windows.Forms.TextBox Subject;
        private System.Windows.Forms.Button Updatebutton;
        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.TextBox BirthMonth;
        private System.Windows.Forms.TextBox BirthDate;
        private System.Windows.Forms.TextBox TeacherID;
    }
}