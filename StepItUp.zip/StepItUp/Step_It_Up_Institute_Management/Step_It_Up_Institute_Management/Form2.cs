﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Step_It_Up_Institute_Management
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string conn = @"Data Source=desktop-d852h6d;Initial Catalog=master;Integrated Security=True";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            String TeacherDetail = "SELECT COUNT(*) FROM Teacher_Details WHERE TeacherID='"+textBox1.Text+"'";

            SqlCommand cmd = new SqlCommand(TeacherDetail, connection);
            SqlDataReader Line = cmd.ExecuteReader();
            while (Line.Read())
            {
                
                String key = (Line["TeacherKey"].ToString());
                Console.WriteLine("Teacher",key);
            }

                connection.Close();
        }
    }
}
