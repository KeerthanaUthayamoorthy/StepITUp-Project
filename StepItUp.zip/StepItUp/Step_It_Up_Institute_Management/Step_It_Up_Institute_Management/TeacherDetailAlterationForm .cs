﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Step_It_Up_Institute_Management
{
    public partial class TeacherDetailAlterationForm : Form
    {
        public TeacherDetailAlterationForm(String s1, String s2, String s3, int s4, String s5, int s6, String s7, String s8, String s9, int s10, String s11, String s12)
        {
            Clickbutton detail = new Clickbutton();
            InitializeComponent();
            TeacherID.Text = s1;
            FirstName.Text = s2;
            LastName.Text = s3;
            BirthYear.Text = s4.ToString();
            BirthMonth.Text = s5;
            BirthDate.Text = s6.ToString();
            Sex.Text = s7;
            Subject.Text = s8;
            Address.Text = s9;
            TelephoneNo.Text = s10.ToString();
            StudentFee.Text = s11;
            EmailID.Text = s12;





        }

        private void Updatebutton_Click(object sender, EventArgs e)
        {

            string conn = @"Data Source=desktop-d852h6d;Initial Catalog=master;Integrated Security=True";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            String TeacherDetail = "UPDATE Teacher_Details SET FirstName='"+FirstName.Text+ "',LastName='" + LastName.Text + "',BirthYear= '" + BirthYear.Text+"', BirthMonth='"+BirthMonth.Text+"',BirthDate='" + BirthDate.Text + "',Sex= '" + Sex.Text+"',Subject ='"+Subject.Text+"',Address='" + Address.Text + "',TelephoneNo= '" + TelephoneNo.Text+"',StudentFee ='"+StudentFee.Text+"',EmailID='" + EmailID.Text + "' WHERE TeacherID= '"+TeacherID.Text+"'";

            SqlCommand command = new SqlCommand(TeacherDetail, connection);


            command.ExecuteNonQuery();
            MessageBox.Show("Teacher details has been Updated successfully!");
            connection.Close();
            
        }

        private void TeacherDetailAlterationForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {

        }
    }
}
