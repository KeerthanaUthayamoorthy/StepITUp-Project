﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Step_It_Up_Institute_Management
{
    public partial class Clickbutton : Form
    {


        public Clickbutton()
        {
            InitializeComponent();
        }

        void toClear()
        {
            DataGridViewSelectionMode firstmode = TeacherDetaildataGridView.SelectionMode;
            TeacherDetaildataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            TeacherDetaildataGridView.ClearSelection();
            TeacherDetaildataGridView.SelectionMode = firstmode;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            


            /* DataTable Table = new DataTable();
             Table.Columns.Add("TeacherID",typeof(String));
             Table.Columns.Add("FirstName", typeof(String));
             Table.Columns.Add("LastName", typeof(String));
             Table.Columns.Add("BirthMonth", typeof(String));
             Table.Columns.Add("Sex", typeof(String));
             Table.Columns.Add("Subject", typeof(String));
             Table.Columns.Add("Address", typeof(String));
             Table.Columns.Add("TelephoneNo", typeof(int));
             Table.Columns.Add("StudentFee", typeof(int));
             Table.Columns.Add("EmailID", typeof(String));

             Table.Rows.Add(1,);
             TeacherDetaildataGridView.DataSource = Table;
             */
        }

        private void ViewDetailsbutton_Click(object sender, EventArgs e)
        {
            try
            {
                int check = 0;
                toClear();

                foreach (DataGridViewRow row in TeacherDetaildataGridView.Rows)
                {
                    if (row.Cells[0].Value.ToString() == TeacherID.Text)
                    {
                        check = 1;
                        row.Selected = true;
                        break;
                    }
                }
                if (check == 0)
                {
                    MessageBox.Show("TeacherID is Not found");
                }

            }
            catch { MessageBox.Show("Error..."); }


        


        /*
        string conn = @"Data Source=desktop-d852h6d;Initial Catalog=master;Integrated Security=True";
        SqlConnection connection = new SqlConnection(conn);
        connection.Open();
        String TeacherDetail = "SELECT COUNT(*) FROM Teacher_Details WHERE TeacherID=TeacherID.Text";

        SqlCommand cmd = new SqlCommand(TeacherDetail, connection);



        SqlDataAdapter SDA = new SqlDataAdapter();
        SDA.SelectCommand = cmd;
        DataTable DTable = new DataTable();
        SDA.Fill(DTable);
        BindingSource bsource = new BindingSource();
        bsource.DataSource = DTable;
        TeacherDetaildataGridView.DataSource = bsource;
        SDA.Update(DTable);
        */


    }



    private void TeacherDetailSearchForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'teacherData.Teacher_Details' table. You can move, or remove it, as needed.
            this.teacher_DetailsTableAdapter.Fill(this.teacherData.Teacher_Details);

        }

        private void button1_Click(object sender, EventArgs e)

        {
            /*
            string conn = @"Data Source=desktop-d852h6d;Initial Catalog=master;Integrated Security=True";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            String TeacherDetail = "SELECT COUNT(*) FROM Teacher_Details WHERE TeacherID=TeacherID.Text";

            SqlCommand cmd = new SqlCommand(TeacherDetail, connection);
            SqlDataReader Line = cmd.ExecuteReader();
            if (Line.Read())
            {

                //string FirstName =Line.GetString("FirstName");
                textBox1.Text = Line.GetString("FirstName");
                   // Line["FirstName"]);

            }
            */


          

    }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void TeacherDetaildataGridview_click(object sender, MouseEventArgs e)
        {

            
            
            // TeacherDetaildataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //int index1 = e.RowIndex;
            //DataGridViewRow selectedRow = TeacherDetaildataGridView.Rows[index1];
            string s1 = TeacherDetaildataGridView.SelectedRows[0].Cells[0].Value.ToString();
            String s2 = TeacherDetaildataGridView.SelectedRows[0].Cells[1].Value.ToString();
            String s3 = TeacherDetaildataGridView.SelectedRows[0].Cells[2].Value.ToString();
            int s4 =(int) TeacherDetaildataGridView.SelectedRows[0].Cells[3].Value;
            String s5= TeacherDetaildataGridView.SelectedRows[0].Cells[4].Value.ToString();
            int s6 = (int)TeacherDetaildataGridView.SelectedRows[0].Cells[5].Value;
            String s7= TeacherDetaildataGridView.SelectedRows[0].Cells[6].Value.ToString();
            String s8= TeacherDetaildataGridView.SelectedRows[0].Cells[7].Value.ToString();
            String s9= TeacherDetaildataGridView.SelectedRows[0].Cells[8].Value.ToString();
            int s10= (int)TeacherDetaildataGridView.SelectedRows[0].Cells[9].Value;
            //int s11 = 12;
            String s11= TeacherDetaildataGridView.SelectedRows[0].Cells[10].Value.ToString();
            String s12= TeacherDetaildataGridView.SelectedRows[0].Cells[11].Value.ToString();
            TeacherDetailAlterationForm form_init = new TeacherDetailAlterationForm(s1,s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12);
            form_init.Show();
            this.Hide();
        }
    }
}
