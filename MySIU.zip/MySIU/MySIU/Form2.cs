﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class Form2 : Form
    {
        bool flag = false;
        String studentID;
        public Form2(String studentID)
        {
            InitializeComponent();
            this.studentID = studentID;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True");
                connection.Open(); //query
                SqlDataAdapter adap = new SqlDataAdapter("Select  TeacherKey, Name, Subject from Teacher1 where Status='Active' ", connection);

                DataSet ds = new System.Data.DataSet();
                adap.Fill(ds, "Teacher");
                dataGridView1.DataSource = ds.Tables[0];

                DataGridViewCheckBoxColumn chc = new DataGridViewCheckBoxColumn();
                chc.HeaderText = "Selection";
                chc.Width = 100;
                chc.Name = "Column4";
                chc.ReadOnly = false;
                dataGridView1.Columns.Insert(3, chc);

                dataGridView1.Columns[1].ReadOnly = true;
                dataGridView1.Columns[0].Visible = false;
                dataGridView1.Columns[1].ReadOnly = true;
                dataGridView1.Columns[2].ReadOnly = true;
                
                connection.Close();

                string query = "select StudentKey from Student where StudentID='" + studentID + "'";
                using (SqlConnection connection1 = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True"))
                {
                    SqlCommand command = new SqlCommand(query, connection1);
                    connection1.Open(); //query
                    SqlDataReader reader = command.ExecuteReader();
                    try
                    {
                        Console.WriteLine(reader);
                        while (reader.Read())
                        {
                            int a = (int)reader[0];
                            Test.Text = a.ToString();
                        }
                        reader.Close();
                    }
                    catch
                    {
                        reader.Close();
                    }
                }

                SqlConnection connection2 = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True");
                connection2.Open(); //query
                SqlCommand command1 = new SqlCommand();
                command1.CommandText = "Select TeacherKey from Teacher_Student where StudentKey='" + Test.Text + "' and  Status='Active'";
                command1.Connection = connection2;
                
               
                for (int count = 0; count < dataGridView1.Rows.Count; count++)
                {
                    SqlDataReader rd = command1.ExecuteReader();

                    try
                    {
                        while (rd.Read())
                        {
                            if (rd[0].ToString() == dataGridView1.Rows[count].Cells[0].Value.ToString())
                            {
                                dataGridView1.Rows[count].Cells[3].Value = true;
           
                                break;

                            }
                        }
                        rd.Close();
                    }

                    catch
                    {
                        rd.Close();
                    }
                    
                }
                connection2.Close();
               

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True");
            conn.Open(); //query
            SqlCommand command2 = new SqlCommand();
            command2.CommandText = "Select TeacherKey from Teacher_Student where StudentKey='" + Test.Text + "'";
            command2.Connection = conn;
           
            for (int count = 0; count < dataGridView1.Rows.Count; count++)
            {
                SqlDataReader rd = command2.ExecuteReader();
                try
                {
                    bool god = false;
                    while (rd.Read())
                    {
                        if (rd[0].ToString() == dataGridView1.Rows[count].Cells[0].Value.ToString())
                        {
                            god = true;
                            int s = (int)rd[0];
                            break;

                        }
                    }
                    //rd.Close();
                    if (god == true)
                    {
                        if ((bool)(dataGridView1.Rows[count].Cells[3].Value)==false)
                        {
                            //MessageBox.Show("Hi");
                            string l = dataGridView1.Rows[count].Cells[0].Value.ToString();
                            string connec = @"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True";
                            SqlConnection connection4 = new SqlConnection(connec);
                            string query4 = "update Teacher_Student set Status='Deactive' where StudentKey='" + Test.Text+"' and TeacherKey='" + l + "'";
                            
                            SqlCommand command = new SqlCommand(query4, connection4);
                           
                            connection4.Open();
                            command.ExecuteNonQuery();
                            //MessageBox.Show("show1");
                            connection4.Close();
                        }
                        else
                        {
                            //MessageBox.Show("Hi1");
                            string j = dataGridView1.Rows[count].Cells[0].Value.ToString();
                            string Conn = @"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True";
                            SqlConnection connection5 = new SqlConnection(Conn);
                            string query5 = "update Teacher_Student set Status='Active' where StudentKey='" + Test.Text + "' and TeacherKey='" + j + "'";

                            SqlCommand command = new SqlCommand(query5, connection5);

                            connection5.Open();
                            command.ExecuteNonQuery();
                            //MessageBox.Show("show3");
                            connection5.Close();
                        }
                    }
                    else
                    {
                        if ((bool)(dataGridView1.Rows[count].Cells[3].Value) == true)
                        {
                            //MessageBox.Show("hi");
                            String z = dataGridView1.Rows[count].Cells[0].Value.ToString();
                            string conne = @"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True";
                            SqlConnection connection3 = new SqlConnection(conne);
                            connection3.Open();
                            string query3 = "insert into Teacher_Student(StudentKey,TeacherKey,Status) values('" + Test.Text + "', '" + z + "' ,'Active')";
                            SqlCommand command = new SqlCommand(query3, connection3);
                            command.ExecuteNonQuery();
                            
                            //MessageBox.Show("show2");
                            connection3.Close();
                        }
                           
                    }
                    
                    rd.Close();
                }

                catch
                {
                    rd.Close();
                }

            }
            conn.Close();
            this.Hide();
            Form3 frm3 = new Form3(Test.Text);
            frm3.ShowDialog();
            
            this.Close();
            //MessageBox.Show("Happy");
        }
    }
    
}
