﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class Form1 : Form
    {
        bool flag = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=DataTest;Integrated Security=True");
                connection.Open(); //query
                SqlCommand command = new SqlCommand();
                command.CommandText = "Select IndexNo from Student where Status='Active'";
                command.Connection = connection;
                SqlDataReader rd = command.ExecuteReader();
                while (rd.Read())
                {
                    if (rd[0].ToString() == textBox1.Text)
                    {

                        flag = true;
                        break;
                    }

                }
                
                if (flag == true)
                {
                    this.Hide();
                    Form2 frm = new Form2(textBox1.Text);
                    frm.ShowDialog();
                    this.Close();
                }
                else
                {
                    this.Hide();
                    MessageBox.Show("Index Number not Valid");
                    this.Close();


                }
                connection.Close();
            }
            catch
            {
                MessageBox.Show("Error occured in Connection.");

            }

        }

        private void IndexNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) & !char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }
        }
    }
    
}
