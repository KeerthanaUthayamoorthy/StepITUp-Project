﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class SearchAdmin : Form
    {
        public SearchAdmin()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SearchAdmin_Load(object sender, EventArgs e)
        {

            txtAdminID.ReadOnly = true;
            txtFirstName.ReadOnly = true;
            txtLastName.ReadOnly = true;
            txtYear.ReadOnly = true;
            txtSex.ReadOnly = true;
            txtHomeAddress.ReadOnly = true;
            txtTPNumber.ReadOnly = true;
            txtEmail.ReadOnly = true;
            string query = "select AdminID,FirstName,LastName,DateOfBirth,Sex,HomeAddress,TelephoneNumber,EmailAddress  from Admin where AdminID='AID0001'";
            using (SqlConnection connection1 = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True"))
            {
                SqlCommand command = new SqlCommand(query, connection1);
                connection1.Open(); //query
                SqlDataReader reader = command.ExecuteReader();
                try
                {
                    Console.WriteLine(reader);
                    while (reader.Read())
                    {
                        txtAdminID.Text = (String)reader[0];
                        txtFirstName.Text = (String)reader[1];
                        txtLastName.Text = (String)reader[2];
                        txtYear.Text = (String)reader[3];
                        txtSex.Text = (String)reader[4];
                        txtHomeAddress.Text = (String)reader[5];
                        int a = (int)reader[6];
                        txtTPNumber.Text = a.ToString();
                        txtEmail.Text = (String)reader[7];

                    }
                    reader.Close();
                }
                catch
                {
                    reader.Close();
                }
            }
        }
    }
}
