﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class RemovalConfirmation : Form
    {
        string adminID;
        public RemovalConfirmation(string adminID )
        {
            InitializeComponent();
            this.adminID = adminID;
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            string conn = @"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open(); //query





            string query = "update Admin set AdminStatus='Deactive' where AdminID='"+adminID+"'";

            SqlCommand command = new SqlCommand(query, connection);

            command.ExecuteNonQuery();
            //MessageBox.Show("Hi");

            connection.Close();

            MessageBox.Show("Admin has removed");
            
            this.Close();
        }
    }
}
