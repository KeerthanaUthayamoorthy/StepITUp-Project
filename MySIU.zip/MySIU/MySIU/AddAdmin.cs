﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class AddAdmin : Form
    {
        public AddAdmin()
        {
            InitializeComponent();
            txtAppointment.Text = DateTime.Now.ToString("yyyy/MM/dd");
        }

        private void lblFirstName_Click(object sender, EventArgs e)
        {

        }

        private void btnAddAdmin_Click(object sender, EventArgs e)
        {
            String Sex = " ";
            try
            {
                if (txtFirstName.Text.Length < 1 || txtLastName.Text.Length < 1 || txtYear.Text.Length < 1 || cmbDOBMonth.Text == "" || cmbDOBDay.Text == "" || txtHomeAddress.Text.Length < 1 || (radioBtnMale.Checked != true && radioBtnFemale.Checked != true))
                {
                    MessageBox.Show("Please fill all the required Boxes");
                }
                if (txtTPNumber.Text.Length != 10 && txtTPNumber.Text.Length != 0)
                {
                    txtTPNumber.BackColor = Color.Red;
                }
                else
                {
                    if (radioBtnMale.Checked)
                    {
                        Sex =radioBtnMale.Text;

                    }
                    if (radioBtnFemale.Checked)
                    {
                        Sex = radioBtnFemale.Text;

                    }

                    string conn = @"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True";
                    SqlConnection connection = new SqlConnection(conn);
                    connection.Open(); //query

                    //For AdminID
                    String forId = "SELECT COUNT(*) FROM Admin";
                    int count = 0;
                    SqlCommand cmdCount = new SqlCommand(forId, connection);
                    //thisConnec.Open();
                    count = (int)cmdCount.ExecuteScalar();
                    MessageBox.Show(count.ToString());

                    String preId = "AID";
                    //StaticClass1.studentIDVal();
                    String postId1 = Convert.ToString(count+1);
                    // int s = StudentMainDetail.Data.Count();
                    for (int i = 0; i <= (3 - postId1.Length); i++)
                    {
                        preId += '0';
                    }
                    String AdminIDNo = preId + postId1;
                    MessageBox.Show(AdminIDNo);

                    String DOB = txtYear.Text + '/' + cmbDOBMonth.Text + '/' + cmbDOBDay.Text;

                    string query = "insert into Admin(AdminID,FirstName,LastName,DateOfBirth,Sex,HomeAddress,TelephoneNumber,EmailAddress,AppointedDate,AdminStatus) values  ('" + AdminIDNo + "','" + txtFirstName.Text + "', '" + txtLastName.Text + "', '"+ DOB +"', '" + Sex + "', '" + txtHomeAddress.Text + "', '" + txtTPNumber.Text + "', '" + txtEmail.Text + "','"+txtAppointment.Text+"','Active')";

                    SqlCommand command = new SqlCommand(query, connection);

                    command.ExecuteNonQuery();
                    //MessageBox.Show("Hi");

                    connection.Close();
                    
                    MessageBox.Show("Admin Details has been successfully added");
                    ClearAll();
                    this.Close();
                }
            }

            catch
            {
                MessageBox.Show("Error occured in Admin addition");

            }
        }


        private void ClearAll()
        {

            txtFirstName.Text = " ";
            txtLastName.Text = " ";
            txtYear.Text = " ";
            cmbDOBMonth.Text = "";
            cmbDOBDay.Text = "";
            txtHomeAddress.Text = " ";
            txtTPNumber.Text = " ";
            txtEmail.Text = " ";
            radioBtnMale.Checked = false;
            radioBtnFemale.Checked = false;

        }
        
        private void FirstNameKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' '))
            {
                e.Handled = true;
            }
        }

        private void LastNameKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' '))
            {
                e.Handled = true;
            }

        }

        private void YearKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }

        }



        private void AddressKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & !Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' ') & e.KeyChar != (',') & e.KeyChar != ('"') & e.KeyChar != ('.') & e.KeyChar != ('/'))
            {
                e.Handled = true;
            }

        }

        private void TelephoneKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }

        }

        

        private void EmailIDKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & !Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != ('.') & e.KeyChar != ('@'))
            {
                e.Handled = true;
            }

        }
        private void TelephoneNo_TextChanged(object sender, EventArgs e)
        {
            txtTPNumber.BackColor = Color.White;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearAll();
        }
    }
}
