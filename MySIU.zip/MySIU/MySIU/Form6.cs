﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

       
        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection2 = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=DataTest;Integrated Security=True");
            connection2.Open(); //query
            SqlCommand command1 = new SqlCommand();
            command1.CommandText = "Select TeacherReg from Teacher1";
            command1.Connection = connection2;
            SqlDataReader rd = command1.ExecuteReader();

            try
            {
                while (rd.Read())
                {

                    int a = (int)rd[0];
                    MessageBox.Show(a.ToString());
                    string conn = @"Data Source=DESKTOP-USO1L40;Initial Catalog=DataTest;Integrated Security=True";
                    SqlConnection connection = new SqlConnection(conn);
                    connection.Open();
                    String forId = "SELECT COUNT(*) FROM Teacher_Student1 WHERE TeacherReg='"+a+"' and Status='Active'";
                    int count = 0;
                    SqlCommand cmdCount = new SqlCommand(forId, connection);
                    
                    count = (int)cmdCount.ExecuteScalar();
                    MessageBox.Show(count.ToString());
                    connection.Close();

                    textBox1.Text="February";
                    String n = "February";
                    string conne = @"Data Source=DESKTOP-USO1L40;Initial Catalog=DataTest;Integrated Security=True";
                    SqlConnection connection1 = new SqlConnection(conne);
                    connection1.Open();
                    String query = "update CountTable1 set '"+textBox1.Text+"' = '"+ count +"' where TeacherReg='" + a + "'";
                    
                    SqlCommand command = new SqlCommand(query, connection1);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Check");
                    connection1.Close();


                }
                    rd.Close();
            }

            catch
             {
                    rd.Close();
             }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
