﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            comboBox1.Text = DateTime.Now.ToString("MMMMMMMMM");
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            
        }

        

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form frm5 = new Form5(comboBox1.Text);
            frm5.ShowDialog();
            this.Close();
        }

        private void Form4_Load_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
}
