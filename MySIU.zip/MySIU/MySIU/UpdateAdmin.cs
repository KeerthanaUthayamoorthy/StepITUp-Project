﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class UpdateAdmin : Form
    {
        public UpdateAdmin()
        {
            InitializeComponent();
        }

        private void btnAddAdmin_Click(object sender, EventArgs e)
        {
            String Sex = " ";
            try
            {
                if (txtFirstName.Text.Length < 1 || txtLastName.Text.Length < 1 || txtYear.Text.Length < 1 || cmbDOBMonth.Text == "" || cmbDOBDay.Text == "" || txtHomeAddress.Text.Length < 1 || (radioBtnMale.Checked != true && radioBtnFemale.Checked != true))
                {
                    MessageBox.Show("Please fill all the required Boxes");
                }
                if (txtTPNumber.Text.Length != 10 && txtTPNumber.Text.Length != 0)
                {
                    txtTPNumber.BackColor = Color.Red;
                }
                else
                {
                    if (radioBtnMale.Checked)
                    {
                        Sex = radioBtnMale.Text;

                    }
                    if (radioBtnFemale.Checked)
                    {
                        Sex = radioBtnFemale.Text;

                    }

                    string conn = @"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True";
                    SqlConnection connection = new SqlConnection(conn);
                    connection.Open(); //query

                    
                    

                    String DOB = txtYear.Text + '/' + cmbDOBMonth.Text + '/' + cmbDOBDay.Text;

                    string query = "update Admin set FirstName=txtFirstName.Text,LastName=txtLastName.Text,DateOfBirth=DOB,Sex=Sex,HomeAddress=txtHomeAddress.Text,TelephoneNumber=txtTPNumber.Text,EmailAddress=txtEmail.Text,AppointedDate,AdminStatus where AdminID=txtAdminId";

                    SqlCommand command = new SqlCommand(query, connection);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Hi");

                    connection.Close();

                    MessageBox.Show("Admin Details has been successfully updated");
                    ClearAll();
                    this.Close();
                }
            }

            catch
            {
                MessageBox.Show("Error occured in Admin update");

            }
        }


        private void ClearAll()
        {

            txtFirstName.Text = " ";
            txtLastName.Text = " ";
            txtYear.Text = " ";
            cmbDOBMonth.Text = "";
            cmbDOBDay.Text = "";
            txtHomeAddress.Text = " ";
            txtTPNumber.Text = " ";
            txtEmail.Text = " ";
            radioBtnMale.Checked = false;
            radioBtnFemale.Checked = false;

        }

        private void FirstNameKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' '))
            {
                e.Handled = true;
            }
        }

        private void LastNameKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' '))
            {
                e.Handled = true;
            }

        }

        private void YearKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }

        }



        private void AddressKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & !Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' ') & e.KeyChar != (',') & e.KeyChar != ('"') & e.KeyChar != ('.') & e.KeyChar != ('/'))
            {
                e.Handled = true;
            }

        }

        private void TelephoneKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }

        }



        private void EmailIDKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & !Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != ('.') & e.KeyChar != ('@'))
            {
                e.Handled = true;
            }

        }
        private void TelephoneNo_TextChanged(object sender, EventArgs e)
        {
            txtTPNumber.BackColor = Color.White;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearAll();
        }

        private void UpdateAdmin_Load(object sender, EventArgs e)
        {
            try
            {



                String connection = @"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True";

                string queryString = "SELECT AdminID,FirstName,LastName,DateOfBirth,Sex,HomeAddress,TelephoneNumber,EmailAddress FROM Admin where AdminID ='AID0001'";
                using (SqlConnection connectionObj = new SqlConnection(connection))
                {
                    SqlCommand command = new SqlCommand(queryString, connectionObj);
                    connectionObj.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    try
                    {
                        Console.WriteLine(reader);
                        while (reader.Read())
                        {
                            
                            txtAdminId.Text = (String)reader[0];
                            txtFirstName.Text = (String)reader[1];
                            txtLastName.Text = (String)reader[2];
                            textBox1.Text = (String)reader[3];
                            if ((String)reader[4] == "Male")
                            {
                                radioBtnMale.Checked = true;
                            }
                            else
                            {
                                radioBtnFemale.Checked = true;
                            }
                            txtHomeAddress.Text = (String)reader[5];
                            txtTPNumber.Text = (String)reader[6];
                            txtEmail.Text = (String)reader[7];
                            


                            
                        }


                    }
                    finally
                    {
                        // Always call Close when done reading.
                        reader.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void lblFirstName_Click(object sender, EventArgs e)
        {

        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
