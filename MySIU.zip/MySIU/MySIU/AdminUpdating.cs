﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class AdminUpdating : Form
    {
        public AdminUpdating()
        {
            InitializeComponent();
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdateAdmin_Click(object sender, EventArgs e)
        {
            String Sex = " ";
            try
            {
                if (txtFirstName.Text.Length < 1 || txtLastName.Text.Length < 1 || txtYear.Text.Length < 1 ||  txtHomeAddress.Text.Length < 1 || (txtSex.Text!="Male" && txtSex.Text!="Female"))
                {
                    MessageBox.Show("Please fill all the required Boxes");
                }
                if (txtTPNumber.Text.Length != 10 && txtTPNumber.Text.Length != 0)
                {
                    txtTPNumber.BackColor = Color.Red;
                }
                else
                {
                   

                    string conn = @"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True";
                    SqlConnection connection = new SqlConnection(conn);
                    connection.Open(); //query

                    

                    

                    string query = "update Admin set FirstName='"+txtFirstName.Text+"', LastName='"+txtLastName.Text+"', DateOfBirth='"+txtYear.Text+"', Sex='"+txtSex.Text+"', HomeAddress='"+txtHomeAddress.Text+"', TelephoneNumber='"+txtTPNumber.Text+"', EmailAddress='"+txtEmail.Text+"' where AdminID='AID0001'";

                    SqlCommand command = new SqlCommand(query, connection);

                    command.ExecuteNonQuery();
                    //MessageBox.Show("Hi");

                    connection.Close();

                    MessageBox.Show("Admin Details has been successfully updated");
                    ClearAll();
                    this.Close();
                }
            }

            catch
            {
                MessageBox.Show("Error occured in Admin update");

            }
        }



        private void ClearAll()
        {

            txtFirstName.Text = " ";
            txtLastName.Text = " ";
            txtYear.Text = " ";
            
            txtHomeAddress.Text = " ";
            txtTPNumber.Text = " ";
            txtEmail.Text = " ";
            txtSex.Text = "";

        }


        private void FirstNameKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' '))
            {
                e.Handled = true;
            }
        }

        private void LastNameKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' '))
            {
                e.Handled = true;
            }

        }

        private void YearKeyPress(object sender, KeyPressEventArgs e)
        {

            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }
        }

    



        private void AddressKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & !Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' ') & e.KeyChar != (',') & e.KeyChar != ('"') & e.KeyChar != ('.') & e.KeyChar != ('/'))
            {
                e.Handled = true;
            }

        }

        private void TelephoneKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }

        }



        private void EmailIDKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & !Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != ('.') & e.KeyChar != ('@'))
            {
                e.Handled = true;
            }
        }

        private void TelephoneNo_TextChanged(object sender, EventArgs e)
        {
            txtTPNumber.BackColor = Color.White;
        }

        

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearAll();
        }

        private void AdminUpdating_Load(object sender, EventArgs e)
        {
            string query = "select FirstName,LastName,DateOfBirth,Sex,HomeAddress,TelephoneNumber,EmailAddress  from Admin where AdminID='AID0001'";
            using (SqlConnection connection1 = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True"))
            {
                SqlCommand command = new SqlCommand(query, connection1);
                connection1.Open(); //query
                SqlDataReader reader = command.ExecuteReader();
                try
                {
                    Console.WriteLine(reader);
                    while (reader.Read())
                    {
                        txtFirstName.Text = (String)reader[0];
                        txtLastName.Text = (String)reader[1];
                        txtYear.Text = (String)reader[2];
                        txtSex.Text = (String)reader[3];
                        txtHomeAddress.Text = (String)reader[4];
                        int a = (int)reader[5];
                        txtTPNumber.Text = a.ToString();
                        txtEmail.Text = (String)reader[6];

                    }
                    reader.Close();
                }
                catch
                {
                    reader.Close();
                }
            }

        }
    }
}
