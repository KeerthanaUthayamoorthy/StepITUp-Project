﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class Form5 : Form
    {
        String month;
        public Form5(String month)
        {
            InitializeComponent();
            this.month = month;
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            textBox4.Text = month;

            int a = 0;
            //MessageBox.Show(month);
            string query = "select [2] from CountTable where Month= '"+month+"' ";
            using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=DataTest;Integrated Security=True"))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open(); //query
                SqlDataReader reader = command.ExecuteReader();
                try
                {
                    Console.WriteLine(reader);
                    while (reader.Read())
                    {
                        a = (int)reader[0];
                        textBox1.Text = a.ToString();
                        //MessageBox.Show("God");
                        
                    }
                    reader.Close();
                }
                catch
                {
                    reader.Close();
                }
            }

            int b = 0;
            string query1 = "select Fees from Teacher1 where TeacherReg= 2";
            using (SqlConnection connection1 = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=DataTest;Integrated Security=True"))
            {
                SqlCommand command1 = new SqlCommand(query1, connection1);
                connection1.Open(); //query
                SqlDataReader reader1 = command1.ExecuteReader();
                try
                {
                    Console.WriteLine(reader1);
                    while (reader1.Read())
                    {
                        b = (int)reader1[0];
                        textBox2.Text = reader1[0].ToString();
                        

                    }
                    reader1.Close();
                }
                catch
                {
                    reader1.Close();
                }
            }

            textBox3.Text = ((int)a * (int)b).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }
    
    }
}
