﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class Form3 : Form
    {
        
        String StReg;
        public Form3(String StReg)
        {
            InitializeComponent();
            this.StReg = StReg;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            try
            {
                string conn = @"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True";


                string query = "select TeacherKey from Teacher_Student where StudentKey='" + StReg + "' and Status = 'Active'";
                using (SqlConnection connection = new SqlConnection(conn))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open(); //query
                    SqlDataReader reader = command.ExecuteReader();
                    int fee1 = 0;
                    try
                    {
                        
                        Console.WriteLine(reader);
                        while (reader.Read())
                        {
                            int a = (int)reader[0];
                            string b = a.ToString();
                            //MessageBox.Show(reader[0].ToString());
                            string query1 = "select Fees from Teacher1 where TeacherKey='" + b + "' and Status = 'Active'";
                            using (SqlConnection connection1 = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True"))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open(); //query
                                SqlDataReader reader1 = command1.ExecuteReader();
                                int fee2 = 0;
                                try
                                {
                                    Console.WriteLine(reader1);
                                    while (reader1.Read())
                                    {
                                       
                                        int fee3 =(int) reader1[0];
                                        //MessageBox.Show(reader1[0].ToString());
                                        fee2 = fee3;
                                        fee1 = (int)fee1+ (int)fee2;
                                       

                                    }

                                  
                                    //reader.Close();
                                }
                                catch
                                {
                            
                                    reader1.Close();
                                }
                            }
                        }
                        reader.Close();
                        try
                        {
                            bool flag = false;
                            SqlConnection connectiona = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True");
                            connectiona.Open(); //query
                            SqlCommand commanda = new SqlCommand();
                            commanda.CommandText = "Select StudentKey from Initial_Payment";
                            commanda.Connection = connection;
                            SqlDataReader rd = commanda.ExecuteReader();
                            while (rd.Read())
                            {
                                if (rd[0].ToString() == StReg)
                                {

                                    flag = true;
                                    break;
                                }

                            }

                            if (flag == true)
                            {
                                string conne = @"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True";
                                SqlConnection connection2 = new SqlConnection(conne);
                                string query2 = "update Initial_Payment set MonthlyFee='" + fee1 + "' where StudentKey= '" + StReg + "' ";
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open(); //query
                                command2.ExecuteNonQuery();
                                MessageBox.Show("Happy1");
                                //MessageBox.Show("Excecute");
                                connection2.Close();

                                MessageBox.Show("Fees= " + fee1.ToString());
                            }
                            else
                            {
                                string conne = @"Data Source=DESKTOP-USO1L40;Initial Catalog=Final_SIU_Database;Integrated Security=True";
                                SqlConnection connection2 = new SqlConnection(conne);
                                string query2 = "insert into Initial_Payment(StudentKey, MonthlyFee, Balance, StudentStatus, UpdateStatus) values('"+StReg+"','"+fee1+"',0,'Active','Active')";
                                SqlCommand command2 = new SqlCommand(query2, connection2);
                                connection2.Open(); //query
                                command2.ExecuteNonQuery();
                                MessageBox.Show("Happy2");
                                //MessageBox.Show("Excecute");
                                connection2.Close();

                                MessageBox.Show("Fees= " + fee1.ToString());

                            }
                            connection.Close();
                        }
                        catch
                        {
                            MessageBox.Show("Error occured in Connection.");

                        }
                        
                    }
                    catch
                    {
                        reader.Close();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Error occured in connection");
            }
            this.Close();
        }
    }
    
}
