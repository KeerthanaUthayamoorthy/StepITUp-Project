﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySIU
{
    public partial class Form3 : Form
    {
        
        String StReg;
        public Form3(String StReg)
        {
            InitializeComponent();
            this.StReg = StReg;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            try
            {
                string conn = @"Data Source=DESKTOP-USO1L40;Initial Catalog=DataTest;Integrated Security=True";


                string query = "select TeacherReg from Teacher_Student1 where StudentReg='" + StReg + "' and Status = 'Active'";
                using (SqlConnection connection = new SqlConnection(conn))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open(); //query
                    SqlDataReader reader = command.ExecuteReader();
                    int fee1 = 0;
                    try
                    {
                        
                        Console.WriteLine(reader);
                        while (reader.Read())
                        {
                            int a = (int)reader[0];
                            string b = a.ToString();
                            //MessageBox.Show(reader[0].ToString());
                            string query1 = "select Fees from Teacher1 where TeacherReg='" + b + "' and Status = 'Active'";
                            using (SqlConnection connection1 = new SqlConnection(@"Data Source=DESKTOP-USO1L40;Initial Catalog=DataTest;Integrated Security=True"))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open(); //query
                                SqlDataReader reader1 = command1.ExecuteReader();
                                int fee2 = 0;
                                try
                                {
                                    Console.WriteLine(reader1);
                                    while (reader1.Read())
                                    {
                                       
                                        int fee3 =(int) reader1[0];
                                        //MessageBox.Show(reader1[0].ToString());
                                        fee2 = fee3;
                                        fee1 = (int)fee1+ (int)fee2;
                                       

                                    }

                                  
                                    //reader.Close();
                                }
                                catch
                                {
                                    reader1.Close();
                                }
                            }
                            
                        }
                        reader.Close();
                        string conne = @"Data Source=DESKTOP-USO1L40;Initial Catalog=DataTest;Integrated Security=True";
                        SqlConnection connection2 = new SqlConnection(conne);
                        string query2 = "update FeeTable set Fees='"+fee1+"' where StudentReg='" + StReg + "'";
                        SqlCommand command2 = new SqlCommand(query2, connection2);
                        connection2.Open(); //query
                        command2.ExecuteNonQuery();
                        //MessageBox.Show("Excecute");
                        connection2.Close();
                       
                        MessageBox.Show("Fees= "+fee1.ToString());
                    }
                    catch
                    {
                        reader.Close();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Error occured in connection");
            }
            this.Close();
        }
    }
    
}
