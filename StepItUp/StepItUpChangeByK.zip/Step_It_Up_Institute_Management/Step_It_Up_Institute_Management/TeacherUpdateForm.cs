﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Step_It_Up_Institute_Management
{
    public partial class TeacherUpdateForm : Form
    {
        public TeacherUpdateForm()
        {
            InitializeComponent();
        }
    }
}
