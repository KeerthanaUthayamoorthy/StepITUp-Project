﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Log
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            Password.PasswordChar = '*';
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            

                SqlConnection connection = new SqlConnection(@"Data Source=ISHA-PC\SQLEXPRESS;Initial Catalog=DatabaseKeer;Integrated Security=True");
                //connection.Open();
            SqlDataAdapter SDA = new SqlDataAdapter("Select Role from LoginTable Where UserName='" + Username.Text + "' and Password='" + Password.Text + "' ", connection);
                //SqlDataAdapter SDA = new SqlDataAdapter("Select Count(*) from LoginTable Where UserName='" + Username.Text + "' and Password='" + Password.Text + "' ", connection);
                DataTable DT = new DataTable();
                SDA.Fill(DT);
            if (DT.Rows.Count ==1){


               
                String query = "select Password,Role from LoginTable where UserName='" + Username.Text + "' ";
               
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                String UserName = Username.Text;
                String Pass = Password.Text;
                
                    while (reader.Read())
                    {
                        

                        String PassCo = (String)reader[0];
                        String UserRole = (String)reader[1];
                        //connection.Close();

                        if (Pass == PassCo)
                        {
                           // MessageBox.Show("correct");
                            
                            //SqlConnection connection1 = new SqlConnection(@"Data Source=ISHA-PC\SQLEXPRESS;Initial Catalog=DatabaseKeer;Integrated Security=True");
                           //
                           
                            //String query1 = "select Role from LoginTable where UserName='" + Username.Text + "' ";
                            //SqlCommand command1 = new SqlCommand(query1, connection);
                             //connection1.Open();
                            //SqlDataReader reader1 = command1.ExecuteReader();
                            //while (reader1.Read())
                            //{


                                //String UserRole = (String)reader1[0];
                                if (UserRole=="Teacher") {
                                    MessageBox.Show("This is Teacher");
                                    
                                }
                                else if (UserRole == "Admin")
                                {
                                    MessageBox.Show("This is Admin");
                                   
                                }
                                else if (UserRole == "Head")
                                {
                                    MessageBox.Show("This is Head");
                                    
                                }
                                ClearTextBox();
                               
                            //}

                               
                        }
                        else
                        {
                            MessageBox.Show("You have entered an Incorrect Password!!!");
                            ClearTextBox();
                        }
                    }
                }
                
            
        
        else
            {
                MessageBox.Show("Invalid Login to the System!!! Please Try Again");
                ClearTextBox();
            }

        }

        private void ClearTextBox() {
            Username.Text = "";
            Password.Text = "";
        }           
                    
                    

                
            
            
            
        

        private void Username_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
