﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Step_It_Up_Institute_Management
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            /*string conn = @"Data Source=ISHA-PC\SQLEXPRESS;Initial Catalog=DatabaseKeer;Integrated Security=True";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            String TeacherDetail = "SELECT COUNT(*) FROM Teacher_Details WHERE TeacherID='"+textBox1.Text+"'";

            SqlCommand cmd = new SqlCommand(TeacherDetail, connection);
            SqlDataReader Line = cmd.ExecuteReader();
            while (Line.Read())
            {
                
                String key = (Line["TeacherKey"].ToString());
                Console.WriteLine("Teacher",key);
            }

                connection.Close();
             * */
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'databaseKeerDataSet.Teacher_Details' table. You can move, or remove it, as needed.
            this.teacher_DetailsTableAdapter.Fill(this.databaseKeerDataSet.Teacher_Details);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
