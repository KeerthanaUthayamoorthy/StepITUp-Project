﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Step_It_Up_Institute_Management
{
    public partial class Teacher_delete_confirm : Form
    {
        public Teacher_delete_confirm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Yesbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
