﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Step_It_Up_Institute_Management
{
    class SIU_DataBase_Connection
    {

    }
}
