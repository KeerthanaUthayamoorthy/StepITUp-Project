﻿namespace Step_It_Up_Institute_Management
{
    partial class TeacherRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.First_Name = new System.Windows.Forms.Label();
            this.Last_Name = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.TextBox();
            this.Address = new System.Windows.Forms.TextBox();
            this.TelephoneNo = new System.Windows.Forms.TextBox();
            this.StudentFee = new System.Windows.Forms.TextBox();
            this.EmailID = new System.Windows.Forms.TextBox();
            this.BirthMonth = new System.Windows.Forms.ComboBox();
            this.BirthDate = new System.Windows.Forms.ComboBox();
            this.MaleButton = new System.Windows.Forms.RadioButton();
            this.FemaleButton = new System.Windows.Forms.RadioButton();
            this.BirthYear = new System.Windows.Forms.TextBox();
            this.AddTeacherbutton = new System.Windows.Forms.Button();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Subject = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.NIC = new System.Windows.Forms.TextBox();
            this.Date = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // First_Name
            // 
            this.First_Name.Location = new System.Drawing.Point(94, 91);
            this.First_Name.Name = "First_Name";
            this.First_Name.Size = new System.Drawing.Size(109, 20);
            this.First_Name.TabIndex = 0;
            this.First_Name.Text = "First Name";
            this.First_Name.Click += new System.EventHandler(this.label1_Click);
            // 
            // Last_Name
            // 
            this.Last_Name.Location = new System.Drawing.Point(94, 121);
            this.Last_Name.Name = "Last_Name";
            this.Last_Name.Size = new System.Drawing.Size(109, 20);
            this.Last_Name.TabIndex = 1;
            this.Last_Name.Text = "Last Name";
            this.Last_Name.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(94, 156);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Date Of Birth";
            this.label1.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(94, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Sex";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(94, 219);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Subject";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(94, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Address";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(94, 279);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Telephone No";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(94, 311);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 20);
            this.label6.TabIndex = 7;
            this.label6.Text = "Student Fee";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(585, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 20);
            this.label7.TabIndex = 8;
            this.label7.Text = "Date";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(94, 370);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(109, 20);
            this.label10.TabIndex = 11;
            this.label10.Text = "Email ID";
            // 
            // FirstName
            // 
            this.FirstName.Location = new System.Drawing.Point(200, 88);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(309, 20);
            this.FirstName.TabIndex = 12;
            this.FirstName.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Firstname_MouseEnter);
            this.FirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FirstNameKeyPress);
            // 
            // LastName
            // 
            this.LastName.Location = new System.Drawing.Point(200, 118);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(309, 20);
            this.LastName.TabIndex = 13;
            this.LastName.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LastName_mouseclick);
            this.LastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.LastNameKeyPress);
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(200, 249);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(309, 20);
            this.Address.TabIndex = 16;
            this.Address.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Address_MouseClick);
            this.Address.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AddressKeyPress);
            // 
            // TelephoneNo
            // 
            this.TelephoneNo.Location = new System.Drawing.Point(200, 279);
            this.TelephoneNo.Name = "TelephoneNo";
            this.TelephoneNo.Size = new System.Drawing.Size(309, 20);
            this.TelephoneNo.TabIndex = 17;
            this.TelephoneNo.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TelephoneNo_mouseclick);
            this.TelephoneNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TelephoneKeyPress);
            // 
            // StudentFee
            // 
            this.StudentFee.Location = new System.Drawing.Point(200, 311);
            this.StudentFee.Name = "StudentFee";
            this.StudentFee.Size = new System.Drawing.Size(309, 20);
            this.StudentFee.TabIndex = 18;
            this.StudentFee.MouseClick += new System.Windows.Forms.MouseEventHandler(this.StudentFee_Mouseclick);
            this.StudentFee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.StudentFeeKeyPress);
            // 
            // EmailID
            // 
            this.EmailID.Location = new System.Drawing.Point(200, 370);
            this.EmailID.Name = "EmailID";
            this.EmailID.Size = new System.Drawing.Size(309, 20);
            this.EmailID.TabIndex = 19;
            this.EmailID.MouseClick += new System.Windows.Forms.MouseEventHandler(this.EmailID_MouseClick);
            this.EmailID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.EmailIDKeyPress);
            // 
            // BirthMonth
            // 
            this.BirthMonth.FormattingEnabled = true;
            this.BirthMonth.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
            "Month"});
            this.BirthMonth.Location = new System.Drawing.Point(368, 156);
            this.BirthMonth.Name = "BirthMonth";
            this.BirthMonth.Size = new System.Drawing.Size(122, 21);
            this.BirthMonth.TabIndex = 21;
            this.BirthMonth.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BirthMonth_moseClick);
            // 
            // BirthDate
            // 
            this.BirthDate.FormattingEnabled = true;
            this.BirthDate.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "11",
            "12",
            "13",
            "14",
            "15",
            "Day",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.BirthDate.Location = new System.Drawing.Point(550, 153);
            this.BirthDate.Name = "BirthDate";
            this.BirthDate.Size = new System.Drawing.Size(48, 21);
            this.BirthDate.TabIndex = 22;
            this.BirthDate.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Day_moseClick);
            // 
            // MaleButton
            // 
            this.MaleButton.AutoSize = true;
            this.MaleButton.Location = new System.Drawing.Point(209, 192);
            this.MaleButton.Name = "MaleButton";
            this.MaleButton.Size = new System.Drawing.Size(48, 17);
            this.MaleButton.TabIndex = 23;
            this.MaleButton.TabStop = true;
            this.MaleButton.Text = "Male";
            this.MaleButton.UseVisualStyleBackColor = true;
            this.MaleButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Male_mouseclick);
            // 
            // FemaleButton
            // 
            this.FemaleButton.AutoSize = true;
            this.FemaleButton.Location = new System.Drawing.Point(347, 192);
            this.FemaleButton.Name = "FemaleButton";
            this.FemaleButton.Size = new System.Drawing.Size(59, 17);
            this.FemaleButton.TabIndex = 24;
            this.FemaleButton.TabStop = true;
            this.FemaleButton.Text = "Female";
            this.FemaleButton.UseVisualStyleBackColor = true;
            this.FemaleButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Female_Mouseclick);
            // 
            // BirthYear
            // 
            this.BirthYear.Location = new System.Drawing.Point(233, 156);
            this.BirthYear.Name = "BirthYear";
            this.BirthYear.Size = new System.Drawing.Size(84, 20);
            this.BirthYear.TabIndex = 25;
            this.BirthYear.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BirthYear_mouseClick);
            this.BirthYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.YearKeyPress);
            // 
            // AddTeacherbutton
            // 
            this.AddTeacherbutton.Location = new System.Drawing.Point(180, 422);
            this.AddTeacherbutton.Name = "AddTeacherbutton";
            this.AddTeacherbutton.Size = new System.Drawing.Size(115, 47);
            this.AddTeacherbutton.TabIndex = 26;
            this.AddTeacherbutton.Text = "Add Teacher";
            this.AddTeacherbutton.UseVisualStyleBackColor = true;
            this.AddTeacherbutton.Click += new System.EventHandler(this.AddTeacherbutton_Click);
            // 
            // Clearbutton
            // 
            this.Clearbutton.Location = new System.Drawing.Point(375, 422);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(115, 47);
            this.Clearbutton.TabIndex = 27;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(564, 422);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 47);
            this.button1.TabIndex = 28;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Subject
            // 
            this.Subject.FormattingEnabled = true;
            this.Subject.Items.AddRange(new object[] {
            "Combined Maths",
            "Biology",
            "Chemistry",
            "Physics",
            "Technology",
            "Choose....."});
            this.Subject.Location = new System.Drawing.Point(200, 218);
            this.Subject.Name = "Subject";
            this.Subject.Size = new System.Drawing.Size(309, 21);
            this.Subject.TabIndex = 29;
            this.Subject.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Subject_Mouseclick);
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(94, 340);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(109, 20);
            this.label11.TabIndex = 30;
            this.label11.Text = "NIC Number";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // NIC
            // 
            this.NIC.Location = new System.Drawing.Point(200, 337);
            this.NIC.Name = "NIC";
            this.NIC.Size = new System.Drawing.Size(309, 20);
            this.NIC.TabIndex = 31;
            this.NIC.MouseClick += new System.Windows.Forms.MouseEventHandler(this.NIC_mouseclick);
            this.NIC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NIC_Key_Press);
            // 
            // Date
            // 
            this.Date.Location = new System.Drawing.Point(665, 12);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(147, 20);
            this.Date.TabIndex = 32;
            // 
            // TeacherRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 535);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.NIC);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Subject);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.AddTeacherbutton);
            this.Controls.Add(this.BirthYear);
            this.Controls.Add(this.FemaleButton);
            this.Controls.Add(this.MaleButton);
            this.Controls.Add(this.BirthDate);
            this.Controls.Add(this.BirthMonth);
            this.Controls.Add(this.EmailID);
            this.Controls.Add(this.StudentFee);
            this.Controls.Add(this.TelephoneNo);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Last_Name);
            this.Controls.Add(this.First_Name);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TeacherRegistration";
            this.Load += new System.EventHandler(this.TeacherRegistration_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label First_Name;
        private System.Windows.Forms.Label Last_Name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox FirstName;
        private System.Windows.Forms.TextBox LastName;
        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.TextBox TelephoneNo;
        private System.Windows.Forms.TextBox StudentFee;
        private System.Windows.Forms.TextBox EmailID;
        private System.Windows.Forms.ComboBox BirthMonth;
        private System.Windows.Forms.ComboBox BirthDate;
        private System.Windows.Forms.RadioButton MaleButton;
        private System.Windows.Forms.RadioButton FemaleButton;
        private System.Windows.Forms.TextBox BirthYear;
        private System.Windows.Forms.Button AddTeacherbutton;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox Subject;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox NIC;
        private System.Windows.Forms.TextBox Date;
    }
}

