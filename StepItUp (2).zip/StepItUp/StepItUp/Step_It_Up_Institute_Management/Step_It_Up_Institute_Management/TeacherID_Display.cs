﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Step_It_Up_Institute_Management
{
    public partial class TeacherID_Display : Form
    {
        public TeacherID_Display()
        {
            String UName=TeacherRegistration.TeacherIDNo;
            InitializeComponent();
           // var id = Guid.NewGuid().ToString();

            //Password.Text = id;
            DateTime now = DateTime.Now;
            Password.Text = DateTime.Today.ToString("yyyyMMdd") + DateTime.Now.ToString("hmmsstt");
            UserName.Text = UName;
        }

        private void TeacherID_Display_Load(object sender, EventArgs e)
        {

        }
    }
}
