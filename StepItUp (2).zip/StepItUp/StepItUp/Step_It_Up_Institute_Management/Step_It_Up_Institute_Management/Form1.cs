﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Step_It_Up_Institute_Management
{
    public partial class TeacherRegistration : Form
    {
        public static String TeacherIDNo = " ";
        public TeacherRegistration()
        {
            InitializeComponent();
            BirthMonth.Text = "Month";
            BirthDate.Text = "Day";
            Subject.Text = "Choose.....";
            DateTime now = DateTime.Now;
            Date.Text=DateTime.Today.ToString("yyyy-MM-dd");
            Date.ReadOnly = true;
            BirthYear.MaxLength = 4;
            NIC.MaxLength = 10;
            
            
        }


        //String TeacherID=" ";
        private void AddTeacherbutton_Click(object sender, EventArgs e)
        {
            
            String Sex = " ";
            String Status = "Active";
          
            
                
                try
                {
                    if (FirstName.Text.Length < 1 || LastName.Text.Length < 1 || BirthYear.Text.Length < 1 || BirthMonth.Text == "Month" || BirthDate.Text == "Day" || Subject.Text == "Choose....." || Address.Text.Length < 1 || TelephoneNo.Text.Length ==0||EmailID.Text.Length==0|| NIC.Text.Length < 1 || StudentFee.Text.Length < 1 || (MaleButton.Checked != true && FemaleButton.Checked != true))
                {
                    MessageBox.Show("Please fill all the required Boxes");
                }
                if(TelephoneNo.Text.Length != 10 && TelephoneNo.Text.Length == 0)
                {
                    TelephoneNo.BackColor = Color.IndianRed;
                }
                if (FirstName.Text.Length == 0)
                {
                    FirstName.BackColor = Color.IndianRed;
                }
                if (LastName.Text.Length == 0)
                {
                    LastName.BackColor = Color.IndianRed;
                }
                if (BirthYear.Text.Length == 0)
                {
                    BirthYear.BackColor = Color.IndianRed;
                }
                if (BirthMonth.Text == "Month")
                {
                    BirthMonth.BackColor = Color.IndianRed;
                }
                if (BirthDate.Text == "Day")
                {
                    BirthDate.BackColor = Color.IndianRed;
                }
                if (Address.Text.Length == 0)
                {
                    Address.BackColor = Color.IndianRed;
                }
                if (StudentFee.Text.Length == 0)
                {
                    StudentFee.BackColor = Color.IndianRed;
                }
                if (Subject.Text == "Choose.....")
                {
                    Subject.BackColor = Color.IndianRed;
                }
                if (FemaleButton.Checked == false && MaleButton.Checked == false)
                {
                    FemaleButton.BackColor = Color.IndianRed;
                    MaleButton.BackColor = Color.IndianRed;
                }
                if (NIC.Text.Length == 0)
                {
                    NIC.BackColor = Color.IndianRed;
                }

                if (emailValidityCheck() == false || EmailID.Text.Length == 0)
                {
                    EmailID.BackColor = Color.IndianRed;
                }
                else
                {
                    if (MaleButton.Checked)
                    {
                        Sex = MaleButton.Text;

                    }
                    if (FemaleButton.Checked)
                    {
                        Sex = FemaleButton.Text;

                    }

                    string conn = @"Data Source=ISHA-PC\SQLEXPRESS;Initial Catalog=DatabaseKeer;Integrated Security=True";
                    SqlConnection connection = new SqlConnection(conn);
                    connection.Open(); //query

                    //For TeacherID
                    String forId = "SELECT COUNT(*) FROM Teacher_Details";
                    int count = 0;
                    SqlCommand cmdCount = new SqlCommand(forId, connection);
                    //thisConnec.Open();
                    count = (int)cmdCount.ExecuteScalar();

                    String preId = "TID";
                    //StaticClass1.studentIDVal();
                    String postId1 = Convert.ToString(count);
                    // int s = StudentMainDetail.Data.Count();
                    for (int i = 0; i <= (3 - postId1.Length); i++)
                    {
                        preId += '0';
                    }
                    TeacherIDNo = preId + postId1;
                    
                    String RemovalDate = "None";
                    String m=BirthMonth.Text.ToString();
                    int d=int.Parse (BirthDate.Text);
                    if (m == "January") { m = "01"; }
                    else if (m == "February") { m = "02"; }
                    else if (m == "March") { m = "03"; }
                    else if (m == "April") { m = "04"; }
                    else if (m == "May") { m = "05"; }
                    else if (m == "June") { m = "06"; }
                    else if (m == "July") { m = "07"; }
                    else if (m == "August") { m = "08"; }
                    else if (m == "September") { m = "09"; }
                    else if (m == "October") { m = "10"; }
                    else if (m == "November") { m = "11"; }
                    else if (m == "December") { m = "12"; }
                    String day;
                    if (d < 10) {  day = "0" + d.ToString(); }
                    else {  day = d.ToString(); }
                    String DOB = BirthYear.Text.ToString() + "-" + m + "-" + day;

                    string query = "insert into Teacher_Details(TeacherID,FirstName,LastName,DateOfBirth,Sex,Subject,Address,TelephoneNo,StudentFee,EmailID,NIC,AdmissionDate,RemovalDate,Status) VALUES  ('" + TeacherIDNo + "','" + FirstName.Text + "', '" + LastName.Text + "', '" + DOB + "', '" + Sex + "', '" + Subject.Text + "', '" + Address.Text + "', '" + TelephoneNo.Text + "', '" + StudentFee.Text + "', '" + EmailID.Text + "','" + NIC.Text + "','" + Date.Text + "','" + RemovalDate + "','" + Status + "')";

                    SqlCommand command = new SqlCommand(query, connection);

                    command.ExecuteNonQuery();

                    connection.Close();
                    MessageBox.Show("Teacher Details has been successfully added");
                    TeacherID_Display TID_Display = new TeacherID_Display();
                    TID_Display.Show();
                    ClearAll();
                }
                }
            
            catch
            {
                MessageBox.Show("Error occured in teacher addition");

            }
        }
        private void Clearbutton_Click(object sender, EventArgs e)
        {
            ClearAll();
        }
        private void ClearAll()
        {

            FirstName.Text = " ";
            LastName.Text = " ";
            BirthYear.Text = " ";
            BirthMonth.Text = "Month";
            BirthDate.Text = "Day";
            Subject.Text = "Choose.....";
            Address.Text = " ";
            TelephoneNo.Text = " ";
            StudentFee.Text = " ";
            EmailID.Text = " ";
            NIC.Text = " ";
            MaleButton.Checked = false;
            FemaleButton.Checked = false;

        }
        Boolean emailValidityCheck()
        {
           
            bool eValid = false;
           
            try
            {
                var validEmail = new System.Net.Mail.MailAddress(EmailID.Text);
                eValid = true;
            }
            catch
            {
                if (EmailID.Text.Length > 0)
                {
                    MessageBox.Show("Invalid email address!!!");
                }
            }
            return eValid;
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void FirstNameKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' '))
            {
                e.Handled = true;
            }
        }

        private void LastNameKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' '))
            {
                e.Handled = true;
            }

        }

        private void YearKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }

        }

        

        private void AddressKeyPress(object sender, KeyPressEventArgs e)
        {
            /*if (!Char.IsLetter(e.KeyChar) & !Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' ') & e.KeyChar != (',') & e.KeyChar != ('"') & e.KeyChar != ('.') & e.KeyChar != ('/'))
            {
                e.Handled = true;
            }*/

        }

        private void TelephoneKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }

        }

        private void StudentFeeKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != ('.'))
            {
                e.Handled = true;
            }

        }

        private void EmailIDKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & !Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != ('.') & e.KeyChar != ('@'))
            {
                e.Handled = true;
            }

        }
        private void NIC_Key_Press(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != ('v') & e.KeyChar != ('V'))
            {
                e.Handled = true;
            }

        }

        private void Firstname_MouseEnter(object sender, EventArgs e)
        {
            FirstName.BackColor = Color.White;
        }


        private void LastName_mouseclick(object sender, MouseEventArgs e)
        {
            LastName.BackColor = Color.White;
        }

        private void BirthYear_mouseClick(object sender, MouseEventArgs e)
        {
            BirthYear.BackColor = Color.White;
        }

        private void BirthMonth_moseClick(object sender, MouseEventArgs e)
        {
            BirthMonth.BackColor = Color.White;
        }

        private void Day_moseClick(object sender, MouseEventArgs e)
        {
            BirthDate.BackColor = Color.White;

        }

        private void Male_mouseclick(object sender, MouseEventArgs e)
        {

            MaleButton.BackColor = Color.White;
            FemaleButton.BackColor = Color.White;
        }

        private void Female_Mouseclick(object sender, MouseEventArgs e)
        {

            MaleButton.BackColor = Color.White;
            FemaleButton.BackColor = Color.White;
        }

        private void Subject_Mouseclick(object sender, MouseEventArgs e)
        {
            Subject.BackColor = Color.White;
        }

        private void Address_MouseClick(object sender, MouseEventArgs e)
        {
            Address.BackColor = Color.White;
        }

        private void TelephoneNo_mouseclick(object sender, MouseEventArgs e)
        {
            TelephoneNo.BackColor = Color.White;
        }

        private void StudentFee_Mouseclick(object sender, MouseEventArgs e)
        {
            StudentFee.BackColor = Color.White;
        }

        private void NIC_mouseclick(object sender, MouseEventArgs e)
        {
            NIC.BackColor = Color.White;
        }

        private void EmailID_MouseClick(object sender, MouseEventArgs e)
        {
            EmailID.BackColor = Color.White;
        }


       

        



       

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TeacherRegistration_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        

       
       

        private void Subject_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        
        

        
    }
}
