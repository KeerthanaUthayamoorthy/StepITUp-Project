﻿CREATE TABLE [dbo].[Teacher_Details] (
    [TeacherKey]  INT          IDENTITY (1, 1) NOT NULL,
    [TeacherID]   VARCHAR (20) NOT NULL,
    [FirstName]   VARCHAR (50) NOT NULL,
    [LastName]    VARCHAR (50) NOT NULL,
    [BirthYear]   INT          NOT NULL,
    [BirthMonth]  VARCHAR (20) NOT NULL,
    [BirthDate]   INT          NOT NULL,
    [Sex]         VARCHAR (20) NOT NULL,
    [Subject]     VARCHAR (20) NOT NULL,
    [Address]     VARCHAR (50) NOT NULL,
    [TelephoneNo] INT          NULL,
    [StudentFee]  FLOAT (53)   NOT NULL,
    [EmailID]     VARCHAR (50) NULL,
    [TStatus] VARCHAR(20) NOT NULL, 
    CONSTRAINT [PK_Teacher_Details] PRIMARY KEY CLUSTERED ([TeacherKey] ASC)
);

