﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Step_It_Up_Institute_Management
{
    public partial class TeacherDetailAlterationForm : Form
    {
        public TeacherDetailAlterationForm(String s1, String s2, String s3, String s4, String s5, String s6, String s7, int s8, int s9, String s10, String s11, String s12, String s13, String s14)
        {
            Clickbutton detail = new Clickbutton();
            InitializeComponent();
           

            TeacherID.Text = s1;
            FirstName.Text = s2;
            LastName.Text = s3;
            DOB.Text = s4;
           // BirthMonth.Text = s5;
           // BirthDate.Text = s6.ToString();
            String Sex = s5;
             if (Sex=="Male")
             {
                  Malebutton.Checked = true;
                Femalebutton.Checked = false;
             }
              if (Sex=="Female")
             {
                  Malebutton.Checked = false;
                  Femalebutton.Checked = true;
             } 
            Subject.Text = s6;
            Address.Text = s7;
            TelephoneNo.Text = s8.ToString();
            StudentFee.Text = s9.ToString();
            EmailID.Text = s11;
            Date.Text = s14;
            NIC.Text=s10;
            //String RemovalDate=s12;
            Status.Text = s13;
            TeacherID.ReadOnly = true;
            Date.ReadOnly = true;
            Status.ReadOnly = true;


        }


        private void Updatebutton_Click(object sender, EventArgs e)
        {
            String SexUpdate = " ";
            try
            {
                if (Status.Text != "Deactive")
                {
                    if (FirstName.Text.Length < 1 || LastName.Text.Length < 1 || DOB.Text.Length < 1 || Address.Text.Length < 1 || TelephoneNo.Text.Length == 0 || EmailID.Text.Length == 0 || NIC.Text.Length < 1 || StudentFee.Text.Length < 1 || (Malebutton.Checked != true && Femalebutton.Checked != true))
                    {
                        MessageBox.Show("Please fill all the required Boxes");
                    }
                    if (TelephoneNo.Text.Length != 10 && TelephoneNo.Text.Length == 0)
                    {
                        TelephoneNo.BackColor = Color.IndianRed;
                    }
                    if (FirstName.Text.Length == 0)
                    {
                        FirstName.BackColor = Color.IndianRed;
                    }
                    if (LastName.Text.Length == 0)
                    {
                        LastName.BackColor = Color.IndianRed;
                    }
                    if (DOB.Text.Length == 0)
                    {
                        DOB.BackColor = Color.IndianRed;
                    }

                    if (Address.Text.Length == 0)
                    {
                        Address.BackColor = Color.IndianRed;
                    }
                    if (StudentFee.Text.Length == 0)
                    {
                        StudentFee.BackColor = Color.IndianRed;
                    }

                    if (Femalebutton.Checked == false && Malebutton.Checked == false)
                    {
                        Femalebutton.BackColor = Color.IndianRed;
                        Malebutton.BackColor = Color.IndianRed;
                    }
                    if (NIC.Text.Length == 0)
                    {
                        NIC.BackColor = Color.IndianRed;
                    }

                    if (emailValidityCheck() == false || EmailID.Text.Length == 0)
                    {
                        EmailID.BackColor = Color.IndianRed;
                    }
                    else
                    {


                        if (Malebutton.Checked)
                        {
                            SexUpdate = Malebutton.Text;

                        }
                        if (Femalebutton.Checked)
                        {
                            SexUpdate = Femalebutton.Text;

                        }

                        string conn = @"Data Source=ISHA-PC\SQLEXPRESS;Initial Catalog=DatabaseKeer;Integrated Security=True";
                        SqlConnection connection = new SqlConnection(conn);
                        connection.Open();

                        String TeacherDetail = "UPDATE Teacher_Details SET FirstName='" + FirstName.Text + "',LastName='" + LastName.Text + "',DateOfBirth= '" + DOB.Text + "', Sex= '" + SexUpdate + "',Subject ='" + Subject.Text + "',Address='" + Address.Text + "',TelephoneNo= '" + TelephoneNo.Text + "',StudentFee ='" + StudentFee.Text + "',EmailID='" + EmailID.Text + "',NIC='" + NIC.Text + "' WHERE TeacherID= '" + TeacherID.Text + "'";
                        MessageBox.Show("Teacher details has been Updated successfully!");
                        SqlCommand command = new SqlCommand(TeacherDetail, connection);


                        command.ExecuteNonQuery();
                        
                        connection.Close();
                       
                    }
                }

                else
                {
                    MessageBox.Show("This teacher was already removed from the System!!! \n You can't update the details");
                }

            }

            catch
            {
                MessageBox.Show("Error occured in teacher addition");
            }
        }       
        

        private void TeacherDetailAlterationForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            if (Status.Text != "Deactive")
            {
                Teacher_delete_confirm Teac_del_con = new Teacher_delete_confirm();//call the confirmation interface
                Teac_del_con.Show();

                string conn = @"Data Source=ISHA-PC\SQLEXPRESS;Initial Catalog=DatabaseKeer;Integrated Security=True";
                SqlConnection connection = new SqlConnection(conn);
                connection.Open();
                String TeacherDetail = "UPDATE Teacher_Details SET Status='Deactive' where TeacherID='" + TeacherID.Text + "'";

                SqlCommand command = new SqlCommand(TeacherDetail, connection);
                command.ExecuteNonQuery();

                MessageBox.Show("Teacher details has been Deactivted in the System!");
                ClearAll();
                connection.Close();
            }
            else {
                MessageBox.Show("This teacher was already removed from the System!!!");
            }
            
        }
        private void ClearAll()
        {
            TeacherID.Text = " ";
            Date.Text = " ";
            FirstName.Text = " ";
            LastName.Text = " ";
            DOB.Text = " ";
            Subject.Text = " ";
            Address.Text = " ";
            TelephoneNo.Text = " ";
            StudentFee.Text = " ";
            EmailID.Text = " ";
            NIC.Text = " ";
            Status.Text = " ";
            Malebutton.Checked = false;
            Femalebutton.Checked = false;

        }
        Boolean emailValidityCheck()
        {
           
            bool eValid = false;
           
            try
            {
                var validEmail = new System.Net.Mail.MailAddress(EmailID.Text);
                eValid = true;
            }
            catch
            {
                if (EmailID.Text.Length > 0)
                {
                    MessageBox.Show("Invalid email address!!!");
                }
            }
            return eValid;
        }

        private void Clearbutton_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        private void Firstname_mouseclick(object sender, MouseEventArgs e)
        {
            FirstName.BackColor = Color.White;
        }

        private void LastName_mouseclick(object sender, MouseEventArgs e)
        {
            LastName.BackColor = Color.White;
        }

        private void DOB_mouseclick(object sender, MouseEventArgs e)
        {
            DOB.BackColor = Color.White;
        }

        private void Malebutton_mouseclick(object sender, MouseEventArgs e)
        {
            Malebutton.BackColor = Color.White;
            Femalebutton.BackColor = Color.White;
        }

        private void Femalebutton_mouseclick(object sender, MouseEventArgs e)
        {
            Malebutton.BackColor = Color.White;
            Femalebutton.BackColor = Color.White;
        }

        private void Subject_mouseclick(object sender, MouseEventArgs e)
        {
            Subject.BackColor = Color.White;
        }

        private void Address_mouseclick(object sender, MouseEventArgs e)
        {
            Address.BackColor = Color.White;
        }

        private void TelephoneNo_mouseClick(object sender, MouseEventArgs e)
        {
            TelephoneNo.BackColor = Color.White;
        }

        private void Studentfee_mouseclick(object sender, MouseEventArgs e)
        {
            StudentFee.BackColor = Color.White;
        }

        private void NIC_num_mouseClick(object sender, MouseEventArgs e)
        {
            NIC.BackColor = Color.White;
        }

        private void Email_mouseClick(object sender, MouseEventArgs e)
        {
            EmailID.BackColor = Color.White;
        }

        private void F_namKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' '))
            {
                e.Handled = true;
            }
        }

        private void L_name_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != (' '))
            {
                e.Handled = true;
            }
        }

        private void DOB_keypress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != ('-'))
            {
                e.Handled = true;
            }
        }

        private void Address_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void TeleNoKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }

        }

        private void StudentFeeKeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != ('.'))
            {
                e.Handled = true;
            }
        }

        private void NIC_keypress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != ('v') & e.KeyChar != ('V'))
            {
                e.Handled = true;
            }
        }

        private void Email_keypress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) & !Char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != ('.') & e.KeyChar != ('@'))
            {
                e.Handled = true;
            }

        }
    }
}
