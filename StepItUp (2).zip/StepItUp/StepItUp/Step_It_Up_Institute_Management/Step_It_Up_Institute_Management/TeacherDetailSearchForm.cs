﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Step_It_Up_Institute_Management
{
    public partial class Clickbutton : Form
    {


        public Clickbutton()
        {
            InitializeComponent();
        }

        void toClear()
        {
            DataGridViewSelectionMode firstmode = TeacherDetaildataGridView.SelectionMode;
            TeacherDetaildataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            TeacherDetaildataGridView.ClearSelection();
            TeacherDetaildataGridView.SelectionMode = firstmode;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void ViewDetailsbutton_Click(object sender, EventArgs e)
        {
            try
            {
                int check = 0;
                toClear();

                foreach (DataGridViewRow row in TeacherDetaildataGridView.Rows)
                {
                    if (row.Cells[0].Value.ToString() == TeacherID.Text)
                    {
                        check = 1;
                        row.Selected = true;
                        break;
                    }
                }
                if (check == 0)
                {
                    MessageBox.Show("TeacherID is Not found");
                }

            }
            catch { MessageBox.Show("Error..."); }


        


     

    }



    private void TeacherDetailSearchForm_Load(object sender, EventArgs e)
        {
            
                // TODO: This line of code loads data into the 'databaseKeerDataSet.Teacher_Details' table. You can move, or remove it, as needed.
                this.teacher_DetailsTableAdapter1.Fill(this.databaseKeerDataSet.Teacher_Details);
                // TODO: This line of code loads data into the 'teacherData.Teacher_Details' table. You can move, or remove it, as needed.
                //this.teacher_DetailsTableAdapter.Fill(this.teacherData.Teacher_Details);
            
            
        }

        private void button1_Click(object sender, EventArgs e)

        {
           
    }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           

        }

       

        private void TeacherDetaildataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            TeacherDetaildataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            int index1 = e.RowIndex;
            DataGridViewRow selectedRow = TeacherDetaildataGridView.Rows[index1];
            string s1 = TeacherDetaildataGridView.SelectedRows[0].Cells[0].Value.ToString();//teacherid
            string s14 = TeacherDetaildataGridView.SelectedRows[0].Cells[1].Value.ToString();//admission date
            String s2 = TeacherDetaildataGridView.SelectedRows[0].Cells[2].Value.ToString();//fi_name
            String s3 = TeacherDetaildataGridView.SelectedRows[0].Cells[3].Value.ToString();//Las_name
            String s4 = TeacherDetaildataGridView.SelectedRows[0].Cells[4].Value.ToString();//DOB
            //String s5 = TeacherDetaildataGridView.SelectedRows[0].Cells[5].Value.ToString();//month
           // int s6 = (int)TeacherDetaildataGridView.SelectedRows[0].Cells[6].Value;//day
            String s5 = TeacherDetaildataGridView.SelectedRows[0].Cells[5].Value.ToString();//sex
            String s6 = TeacherDetaildataGridView.SelectedRows[0].Cells[6].Value.ToString();//subject
            String s7 = TeacherDetaildataGridView.SelectedRows[0].Cells[7].Value.ToString();//Address
            int s8 = (int)TeacherDetaildataGridView.SelectedRows[0].Cells[8].Value;//Teleno
            //int s11 = 12;
            int s9 = (int)TeacherDetaildataGridView.SelectedRows[0].Cells[9].Value;//fee
            String s10 = TeacherDetaildataGridView.SelectedRows[0].Cells[10].Value.ToString();//email
            String s11 = TeacherDetaildataGridView.SelectedRows[0].Cells[11].Value.ToString();//NIC
            String s12 = TeacherDetaildataGridView.SelectedRows[0].Cells[12].Value.ToString();//removalDate
            String s13 = TeacherDetaildataGridView.SelectedRows[0].Cells[13].Value.ToString();//status
            TeacherDetailAlterationForm form_init = new TeacherDetailAlterationForm(s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13,s14);
            form_init.Show();
            this.Hide();
        }

        private void Mouse_Click_event(object sender, DataGridViewCellMouseEventArgs e)
        {
           
        }
    }
}
