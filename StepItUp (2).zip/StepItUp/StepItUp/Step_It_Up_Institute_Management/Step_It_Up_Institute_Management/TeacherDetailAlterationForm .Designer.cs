﻿namespace Step_It_Up_Institute_Management
{
    partial class TeacherDetailAlterationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.DOB = new System.Windows.Forms.TextBox();
            this.EmailID = new System.Windows.Forms.TextBox();
            this.StudentFee = new System.Windows.Forms.TextBox();
            this.TelephoneNo = new System.Windows.Forms.TextBox();
            this.Address = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.TextBox();
            this.FirstName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Last_Name = new System.Windows.Forms.Label();
            this.First_Name = new System.Windows.Forms.Label();
            this.Updatebutton = new System.Windows.Forms.Button();
            this.Deletebutton = new System.Windows.Forms.Button();
            this.TeacherID = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Date = new System.Windows.Forms.TextBox();
            this.AdmissionDate = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.NIC = new System.Windows.Forms.TextBox();
            this.Status = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Subject = new System.Windows.Forms.ComboBox();
            this.Malebutton = new System.Windows.Forms.RadioButton();
            this.Femalebutton = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(567, 365);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 47);
            this.button1.TabIndex = 55;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Clearbutton
            // 
            this.Clearbutton.Location = new System.Drawing.Point(378, 365);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(115, 47);
            this.Clearbutton.TabIndex = 54;
            this.Clearbutton.Text = "Clear All Details";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // DOB
            // 
            this.DOB.Location = new System.Drawing.Point(203, 99);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(309, 20);
            this.DOB.TabIndex = 52;
            this.DOB.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DOB_mouseclick);
            this.DOB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DOB_keypress);
            // 
            // EmailID
            // 
            this.EmailID.Location = new System.Drawing.Point(203, 313);
            this.EmailID.Name = "EmailID";
            this.EmailID.Size = new System.Drawing.Size(309, 20);
            this.EmailID.TabIndex = 47;
            this.EmailID.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Email_mouseClick);
            this.EmailID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Email_keypress);
            // 
            // StudentFee
            // 
            this.StudentFee.Location = new System.Drawing.Point(203, 254);
            this.StudentFee.Name = "StudentFee";
            this.StudentFee.Size = new System.Drawing.Size(309, 20);
            this.StudentFee.TabIndex = 46;
            this.StudentFee.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Studentfee_mouseclick);
            this.StudentFee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.StudentFeeKeyPress);
            // 
            // TelephoneNo
            // 
            this.TelephoneNo.Location = new System.Drawing.Point(203, 222);
            this.TelephoneNo.Name = "TelephoneNo";
            this.TelephoneNo.Size = new System.Drawing.Size(309, 20);
            this.TelephoneNo.TabIndex = 45;
            this.TelephoneNo.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TelephoneNo_mouseClick);
            this.TelephoneNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TeleNoKeyPress);
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(203, 192);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(309, 20);
            this.Address.TabIndex = 44;
            this.Address.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Address_mouseclick);
            this.Address.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Address_KeyPress);
            // 
            // LastName
            // 
            this.LastName.Location = new System.Drawing.Point(203, 73);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(309, 20);
            this.LastName.TabIndex = 43;
            this.LastName.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LastName_mouseclick);
            this.LastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.L_name_KeyPress);
            // 
            // FirstName
            // 
            this.FirstName.Location = new System.Drawing.Point(203, 50);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(309, 20);
            this.FirstName.TabIndex = 42;
            this.FirstName.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Firstname_mouseclick);
            this.FirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.F_namKeyPress);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(88, 313);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(109, 20);
            this.label10.TabIndex = 41;
            this.label10.Text = "Email ID";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(97, 254);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 20);
            this.label6.TabIndex = 37;
            this.label6.Text = "Student Fee";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(97, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 20);
            this.label5.TabIndex = 36;
            this.label5.Text = "Telephone No";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(97, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 20);
            this.label4.TabIndex = 35;
            this.label4.Text = "Address";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(97, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 20);
            this.label3.TabIndex = 34;
            this.label3.Text = "Subject";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(97, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 33;
            this.label2.Text = "Sex";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(97, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 20);
            this.label1.TabIndex = 32;
            this.label1.Text = "Date Of Birth";
            // 
            // Last_Name
            // 
            this.Last_Name.Location = new System.Drawing.Point(97, 73);
            this.Last_Name.Name = "Last_Name";
            this.Last_Name.Size = new System.Drawing.Size(109, 20);
            this.Last_Name.TabIndex = 31;
            this.Last_Name.Text = "Last Name";
            // 
            // First_Name
            // 
            this.First_Name.Location = new System.Drawing.Point(88, 53);
            this.First_Name.Name = "First_Name";
            this.First_Name.Size = new System.Drawing.Size(109, 20);
            this.First_Name.TabIndex = 30;
            this.First_Name.Text = "First Name";
            // 
            // Updatebutton
            // 
            this.Updatebutton.Location = new System.Drawing.Point(114, 366);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(115, 47);
            this.Updatebutton.TabIndex = 58;
            this.Updatebutton.Text = "Update Details";
            this.Updatebutton.UseVisualStyleBackColor = true;
            this.Updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // Deletebutton
            // 
            this.Deletebutton.Location = new System.Drawing.Point(257, 365);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(115, 47);
            this.Deletebutton.TabIndex = 59;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = true;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // TeacherID
            // 
            this.TeacherID.Location = new System.Drawing.Point(203, -2);
            this.TeacherID.Name = "TeacherID";
            this.TeacherID.Size = new System.Drawing.Size(309, 20);
            this.TeacherID.TabIndex = 62;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(88, 5);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(109, 20);
            this.label11.TabIndex = 63;
            this.label11.Text = "Teacher ID";
            // 
            // Date
            // 
            this.Date.Location = new System.Drawing.Point(203, 24);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(309, 20);
            this.Date.TabIndex = 64;
            // 
            // AdmissionDate
            // 
            this.AdmissionDate.Location = new System.Drawing.Point(88, 25);
            this.AdmissionDate.Name = "AdmissionDate";
            this.AdmissionDate.Size = new System.Drawing.Size(109, 20);
            this.AdmissionDate.TabIndex = 65;
            this.AdmissionDate.Text = "AdmissionDate";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(88, 284);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 20);
            this.label7.TabIndex = 66;
            this.label7.Text = "NIC Number";
            // 
            // NIC
            // 
            this.NIC.Location = new System.Drawing.Point(203, 281);
            this.NIC.Name = "NIC";
            this.NIC.Size = new System.Drawing.Size(309, 20);
            this.NIC.TabIndex = 67;
            this.NIC.MouseClick += new System.Windows.Forms.MouseEventHandler(this.NIC_num_mouseClick);
            this.NIC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NIC_keypress);
            // 
            // Status
            // 
            this.Status.Location = new System.Drawing.Point(203, 339);
            this.Status.Name = "Status";
            this.Status.Size = new System.Drawing.Size(309, 20);
            this.Status.TabIndex = 68;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(88, 339);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 20);
            this.label8.TabIndex = 69;
            this.label8.Text = "Status";
            // 
            // Subject
            // 
            this.Subject.FormattingEnabled = true;
            this.Subject.Items.AddRange(new object[] {
            "Combined Maths",
            "Biology",
            "Physics",
            "Chemistry",
            "Technology"});
            this.Subject.Location = new System.Drawing.Point(203, 162);
            this.Subject.Name = "Subject";
            this.Subject.Size = new System.Drawing.Size(309, 21);
            this.Subject.TabIndex = 70;
            this.Subject.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Subject_mouseclick);
            // 
            // Malebutton
            // 
            this.Malebutton.AutoSize = true;
            this.Malebutton.Location = new System.Drawing.Point(212, 132);
            this.Malebutton.Name = "Malebutton";
            this.Malebutton.Size = new System.Drawing.Size(48, 17);
            this.Malebutton.TabIndex = 71;
            this.Malebutton.TabStop = true;
            this.Malebutton.Text = "Male";
            this.Malebutton.UseVisualStyleBackColor = true;
            this.Malebutton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Malebutton_mouseclick);
            // 
            // Femalebutton
            // 
            this.Femalebutton.AutoSize = true;
            this.Femalebutton.Location = new System.Drawing.Point(346, 130);
            this.Femalebutton.Name = "Femalebutton";
            this.Femalebutton.Size = new System.Drawing.Size(59, 17);
            this.Femalebutton.TabIndex = 72;
            this.Femalebutton.TabStop = true;
            this.Femalebutton.Text = "Female";
            this.Femalebutton.UseVisualStyleBackColor = true;
            this.Femalebutton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Femalebutton_mouseclick);
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(527, 99);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 20);
            this.label9.TabIndex = 73;
            this.label9.Text = "yyyy-mm-dd";
            // 
            // TeacherDetailAlterationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 439);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Femalebutton);
            this.Controls.Add(this.Malebutton);
            this.Controls.Add(this.Subject);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Status);
            this.Controls.Add(this.NIC);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.AdmissionDate);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.TeacherID);
            this.Controls.Add(this.Deletebutton);
            this.Controls.Add(this.Updatebutton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.DOB);
            this.Controls.Add(this.EmailID);
            this.Controls.Add(this.StudentFee);
            this.Controls.Add(this.TelephoneNo);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Last_Name);
            this.Controls.Add(this.First_Name);
            this.Name = "TeacherDetailAlterationForm";
            this.Text = "TeacherDetailAlterationForm";
            this.Load += new System.EventHandler(this.TeacherDetailAlterationForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.TextBox DOB;
        private System.Windows.Forms.TextBox EmailID;
        private System.Windows.Forms.TextBox StudentFee;
        private System.Windows.Forms.TextBox TelephoneNo;
        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.TextBox LastName;
        private System.Windows.Forms.TextBox FirstName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Last_Name;
        private System.Windows.Forms.Label First_Name;
        private System.Windows.Forms.Button Updatebutton;
        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.TextBox TeacherID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Date;
        private System.Windows.Forms.Label AdmissionDate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox NIC;
        private System.Windows.Forms.TextBox Status;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox Subject;
        private System.Windows.Forms.RadioButton Malebutton;
        private System.Windows.Forms.RadioButton Femalebutton;
        private System.Windows.Forms.Label label9;
    }
}