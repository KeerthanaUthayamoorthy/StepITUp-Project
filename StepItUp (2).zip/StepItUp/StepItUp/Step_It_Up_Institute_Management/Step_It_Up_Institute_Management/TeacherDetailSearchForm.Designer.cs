﻿namespace Step_It_Up_Institute_Management
{
    partial class Clickbutton
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.TeacherID = new System.Windows.Forms.TextBox();
            this.ViewDetailsbutton = new System.Windows.Forms.Button();
            this.databaseKeerDataSetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.databaseKeerDataSet = new Step_It_Up_Institute_Management.DatabaseKeerDataSet();
            this.teacherDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.teacherData = new Step_It_Up_Institute_Management.TeacherData();
            this.teacher_DetailsTableAdapter = new Step_It_Up_Institute_Management.TeacherDataTableAdapters.Teacher_DetailsTableAdapter();
            this.teacherDetailsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.teacherDetailsBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.teacher_DetailsTableAdapter1 = new Step_It_Up_Institute_Management.DatabaseKeerDataSetTableAdapters.Teacher_DetailsTableAdapter();
            this.databaseKeerDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.teacherDetailsBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.teacherDetailsBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.TeacherDetaildataGridView = new System.Windows.Forms.DataGridView();
            this.teacherDetailsBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.teacherIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.admissionDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateOfBirthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sexDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subjectDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telephoneNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentFeeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nICDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.removalDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.databaseKeerDataSetBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseKeerDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseKeerDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TeacherDetaildataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource5)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Teacher ID";
            // 
            // TeacherID
            // 
            this.TeacherID.Location = new System.Drawing.Point(166, 32);
            this.TeacherID.Name = "TeacherID";
            this.TeacherID.Size = new System.Drawing.Size(190, 20);
            this.TeacherID.TabIndex = 1;
            // 
            // ViewDetailsbutton
            // 
            this.ViewDetailsbutton.Location = new System.Drawing.Point(412, 29);
            this.ViewDetailsbutton.Name = "ViewDetailsbutton";
            this.ViewDetailsbutton.Size = new System.Drawing.Size(97, 22);
            this.ViewDetailsbutton.TabIndex = 2;
            this.ViewDetailsbutton.Text = "ViewDetails";
            this.ViewDetailsbutton.UseVisualStyleBackColor = true;
            this.ViewDetailsbutton.Click += new System.EventHandler(this.ViewDetailsbutton_Click);
            // 
            // databaseKeerDataSetBindingSource1
            // 
            this.databaseKeerDataSetBindingSource1.DataSource = this.databaseKeerDataSet;
            this.databaseKeerDataSetBindingSource1.Position = 0;
            // 
            // databaseKeerDataSet
            // 
            this.databaseKeerDataSet.DataSetName = "DatabaseKeerDataSet";
            this.databaseKeerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // teacherDetailsBindingSource
            // 
            this.teacherDetailsBindingSource.DataMember = "Teacher_Details";
            this.teacherDetailsBindingSource.DataSource = this.teacherData;
            // 
            // teacherData
            // 
            this.teacherData.DataSetName = "TeacherData";
            this.teacherData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // teacher_DetailsTableAdapter
            // 
            this.teacher_DetailsTableAdapter.ClearBeforeFill = true;
            // 
            // teacherDetailsBindingSource1
            // 
            this.teacherDetailsBindingSource1.DataMember = "Teacher_Details";
            this.teacherDetailsBindingSource1.DataSource = this.teacherData;
            // 
            // teacherDetailsBindingSource2
            // 
            this.teacherDetailsBindingSource2.DataMember = "Teacher_Details";
            this.teacherDetailsBindingSource2.DataSource = this.databaseKeerDataSet;
            // 
            // teacher_DetailsTableAdapter1
            // 
            this.teacher_DetailsTableAdapter1.ClearBeforeFill = true;
            // 
            // databaseKeerDataSetBindingSource
            // 
            this.databaseKeerDataSetBindingSource.DataSource = this.databaseKeerDataSet;
            this.databaseKeerDataSetBindingSource.Position = 0;
            // 
            // teacherDetailsBindingSource3
            // 
            this.teacherDetailsBindingSource3.DataMember = "Teacher_Details";
            this.teacherDetailsBindingSource3.DataSource = this.databaseKeerDataSetBindingSource;
            // 
            // teacherDetailsBindingSource4
            // 
            this.teacherDetailsBindingSource4.DataMember = "Teacher_Details";
            this.teacherDetailsBindingSource4.DataSource = this.databaseKeerDataSetBindingSource1;
            // 
            // TeacherDetaildataGridView
            // 
            this.TeacherDetaildataGridView.AllowUserToAddRows = false;
            this.TeacherDetaildataGridView.AllowUserToDeleteRows = false;
            this.TeacherDetaildataGridView.AutoGenerateColumns = false;
            this.TeacherDetaildataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TeacherDetaildataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.teacherIDDataGridViewTextBoxColumn,
            this.admissionDateDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.dateOfBirthDataGridViewTextBoxColumn,
            this.sexDataGridViewTextBoxColumn,
            this.subjectDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.telephoneNoDataGridViewTextBoxColumn,
            this.studentFeeDataGridViewTextBoxColumn,
            this.nICDataGridViewTextBoxColumn,
            this.emailIDDataGridViewTextBoxColumn,
            this.removalDateDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.TeacherDetaildataGridView.DataSource = this.teacherDetailsBindingSource5;
            this.TeacherDetaildataGridView.Location = new System.Drawing.Point(72, 146);
            this.TeacherDetaildataGridView.Name = "TeacherDetaildataGridView";
            this.TeacherDetaildataGridView.ReadOnly = true;
            this.TeacherDetaildataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.TeacherDetaildataGridView.Size = new System.Drawing.Size(727, 197);
            this.TeacherDetaildataGridView.TabIndex = 3;
            this.TeacherDetaildataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TeacherDetaildataGridView_CellContentClick);
            this.TeacherDetaildataGridView.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Mouse_Click_event);
            // 
            // teacherDetailsBindingSource5
            // 
            this.teacherDetailsBindingSource5.DataMember = "Teacher_Details";
            this.teacherDetailsBindingSource5.DataSource = this.databaseKeerDataSet;
            // 
            // teacherIDDataGridViewTextBoxColumn
            // 
            this.teacherIDDataGridViewTextBoxColumn.DataPropertyName = "TeacherID";
            this.teacherIDDataGridViewTextBoxColumn.HeaderText = "TeacherID";
            this.teacherIDDataGridViewTextBoxColumn.Name = "teacherIDDataGridViewTextBoxColumn";
            this.teacherIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // admissionDateDataGridViewTextBoxColumn
            // 
            this.admissionDateDataGridViewTextBoxColumn.DataPropertyName = "AdmissionDate";
            this.admissionDateDataGridViewTextBoxColumn.HeaderText = "AdmissionDate";
            this.admissionDateDataGridViewTextBoxColumn.Name = "admissionDateDataGridViewTextBoxColumn";
            this.admissionDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dateOfBirthDataGridViewTextBoxColumn
            // 
            this.dateOfBirthDataGridViewTextBoxColumn.DataPropertyName = "DateOfBirth";
            this.dateOfBirthDataGridViewTextBoxColumn.HeaderText = "DateOfBirth";
            this.dateOfBirthDataGridViewTextBoxColumn.Name = "dateOfBirthDataGridViewTextBoxColumn";
            this.dateOfBirthDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sexDataGridViewTextBoxColumn
            // 
            this.sexDataGridViewTextBoxColumn.DataPropertyName = "Sex";
            this.sexDataGridViewTextBoxColumn.HeaderText = "Sex";
            this.sexDataGridViewTextBoxColumn.Name = "sexDataGridViewTextBoxColumn";
            this.sexDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // subjectDataGridViewTextBoxColumn
            // 
            this.subjectDataGridViewTextBoxColumn.DataPropertyName = "Subject";
            this.subjectDataGridViewTextBoxColumn.HeaderText = "Subject";
            this.subjectDataGridViewTextBoxColumn.Name = "subjectDataGridViewTextBoxColumn";
            this.subjectDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // telephoneNoDataGridViewTextBoxColumn
            // 
            this.telephoneNoDataGridViewTextBoxColumn.DataPropertyName = "TelephoneNo";
            this.telephoneNoDataGridViewTextBoxColumn.HeaderText = "TelephoneNo";
            this.telephoneNoDataGridViewTextBoxColumn.Name = "telephoneNoDataGridViewTextBoxColumn";
            this.telephoneNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // studentFeeDataGridViewTextBoxColumn
            // 
            this.studentFeeDataGridViewTextBoxColumn.DataPropertyName = "StudentFee";
            this.studentFeeDataGridViewTextBoxColumn.HeaderText = "StudentFee";
            this.studentFeeDataGridViewTextBoxColumn.Name = "studentFeeDataGridViewTextBoxColumn";
            this.studentFeeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nICDataGridViewTextBoxColumn
            // 
            this.nICDataGridViewTextBoxColumn.DataPropertyName = "NIC";
            this.nICDataGridViewTextBoxColumn.HeaderText = "NIC";
            this.nICDataGridViewTextBoxColumn.Name = "nICDataGridViewTextBoxColumn";
            this.nICDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // emailIDDataGridViewTextBoxColumn
            // 
            this.emailIDDataGridViewTextBoxColumn.DataPropertyName = "EmailID";
            this.emailIDDataGridViewTextBoxColumn.HeaderText = "EmailID";
            this.emailIDDataGridViewTextBoxColumn.Name = "emailIDDataGridViewTextBoxColumn";
            this.emailIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // removalDateDataGridViewTextBoxColumn
            // 
            this.removalDateDataGridViewTextBoxColumn.DataPropertyName = "RemovalDate";
            this.removalDateDataGridViewTextBoxColumn.HeaderText = "RemovalDate";
            this.removalDateDataGridViewTextBoxColumn.Name = "removalDateDataGridViewTextBoxColumn";
            this.removalDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Clickbutton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 453);
            this.Controls.Add(this.TeacherDetaildataGridView);
            this.Controls.Add(this.ViewDetailsbutton);
            this.Controls.Add(this.TeacherID);
            this.Controls.Add(this.label1);
            this.Name = "Clickbutton";
            this.Text = "TeacherDetailSearchForm";
            this.Load += new System.EventHandler(this.TeacherDetailSearchForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.databaseKeerDataSetBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseKeerDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseKeerDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TeacherDetaildataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherDetailsBindingSource5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TeacherID;
        private System.Windows.Forms.Button ViewDetailsbutton;
        private TeacherData teacherData;
        private System.Windows.Forms.BindingSource teacherDetailsBindingSource;
        private TeacherDataTableAdapters.Teacher_DetailsTableAdapter teacher_DetailsTableAdapter;
        private System.Windows.Forms.BindingSource teacherDetailsBindingSource1;
        private DatabaseKeerDataSet databaseKeerDataSet;
        private System.Windows.Forms.BindingSource teacherDetailsBindingSource2;
        private DatabaseKeerDataSetTableAdapters.Teacher_DetailsTableAdapter teacher_DetailsTableAdapter1;
        private System.Windows.Forms.BindingSource databaseKeerDataSetBindingSource;
        private System.Windows.Forms.BindingSource databaseKeerDataSetBindingSource1;
        private System.Windows.Forms.BindingSource teacherDetailsBindingSource3;
        private System.Windows.Forms.BindingSource teacherDetailsBindingSource4;
        private System.Windows.Forms.DataGridView TeacherDetaildataGridView;
        private System.Windows.Forms.BindingSource teacherDetailsBindingSource5;
        private System.Windows.Forms.DataGridViewTextBoxColumn teacherIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn admissionDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateOfBirthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sexDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subjectDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telephoneNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentFeeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nICDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn removalDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
    }
}