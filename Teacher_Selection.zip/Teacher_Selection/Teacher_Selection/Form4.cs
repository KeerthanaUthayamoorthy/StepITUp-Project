﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Teacher_Selection
{
    public partial class Form4 : Form
    {
        bool flag;
        public Form4()
        {
            InitializeComponent();
        }

        private void Submit1_IndexNo(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) & !char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Submit_Click(object sender, EventArgs e)
        {


            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
                connection.Open(); //query

                // string query = "insert into Teacher(Name,Subject) VALUES ('" + "abi" + "','" + IndexNo.Text + "')";

                SqlCommand command = new SqlCommand();
                command.CommandText = "Select * from [StudentNew]";
                command.Connection = connection;
                SqlDataReader rd = command.ExecuteReader();
                while (rd.Read())
                {
                    flag = false;
                    if (rd[3].ToString() == IndexNo.Text)
                    {
                        flag = true;
                        break;
                    }
                
                }
                connection.Close();
                if (flag == true)
                {
                    
                    SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
                    con.Open(); //query


                    String query = "select StudentReg from StudentNew where IndexNo='"+IndexNo.Text+"'";
                    SqlCommand com = new SqlCommand(query, con);
                    SqlDataReader reader = com.ExecuteReader();
                        //MessageBox.Show("index correct");
                        //reader = null;
                        try
                        {
                            Console.WriteLine(reader);
                            while (reader.Read())
                            {
                                int a = (int)reader[0];
                            //textBox1.Text = a.ToString();
                            SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
                            conn.Open(); //query
                            string query1 = "select Balance from Payment where StudentReg='"+a+"'";
                            SqlCommand command1 = new SqlCommand(query1, conn);
                            
                            SqlDataReader Line = command1.ExecuteReader();
                            //MessageBox.Show("ff");
                            try
                            {
                                Console.WriteLine(Line);
                                while (Line.Read())
                                {
                                    int r = (int)Line[0];
                                    //textBox1.Text = r.ToString();
                                    Form5 frm5 = new Form5(r);
                                    frm5.Show();
                                    this.Hide();
                                }

                            }
                            finally
                            {
                                //Should close reader after reading finish
                                Line.Close();
                                //reader.Close();
                            }
                           
                        }

                    }
                        finally
                        {
                        if (reader != null)
                        {
                            reader.Close();
                        }
                        }
                    /*SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
                    conn.Open(); //query
                    string query1 = "select Balance from Payment1 where StudentReg=a";
                    SqlCommand command1 = new SqlCommand(query1, conn);
                    //MessageBox.Show(a.ToString());
                    SqlDataReader Line = command1.ExecuteReader();

                    
                    try
                    {
                        Console.WriteLine(Line);
                        while (Line.Read())
                        {
                            int r = (int)Line[0];
                            textBox1.Text = r.ToString();
                            //Form5 frm5 = new Form5(r);
                            //frm5.Show();
                            //this.Hide();
                        }

                    }
                    finally
                    {
                        //Should close reader after reading finish
                        Line.Close();
                        reader.Close();
                    }*/
                    }
                   

                    //SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
                    //conn.Open(); //query

                    

                
                else
                {
                    MessageBox.Show("Index Number not Valid");

                }

               
                IndexNo.Text = "";

                //connection.Close();



            }
            catch
            {
                MessageBox.Show("Error occured in Connection.");

            }

        }

        private void IndexNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}


      
