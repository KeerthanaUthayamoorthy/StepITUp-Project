﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teacher_Selection
{
    public partial class Form6 : Form
    {
        bool flag;
        public Form6()
        {
            InitializeComponent();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Submit_Click(object sender, EventArgs e)
        {

            try
            {

                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
                connection.Open(); //query

                // string query = "insert into Teacher(Name,Subject) VALUES ('" + "abi" + "','" + IndexNo.Text + "')";

                SqlCommand command = new SqlCommand();
                command.CommandText = "Select * from [StudentNew]";
                command.Connection = connection;
                SqlDataReader rd = command.ExecuteReader();
                while (rd.Read())
                {
                    flag = false;
                    if (rd[3].ToString() == IndexNo.Text)
                    {
                        flag = true;
                        break;
                    }

                }
                if (flag == true)
                {
                    //this.Hide();
                    //load form2
                    // Form7 frm7 = new Form7();
                    //frm7.Show();
                    

                        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
                        con.Open(); //query


                        String query = "select StudentReg from StudentNew where IndexNo='" + IndexNo.Text + "'";
                        SqlCommand com = new SqlCommand(query, con);
                        SqlDataReader reader = com.ExecuteReader();
                        //MessageBox.Show("index correct");
                        //reader = null;
                        //int b;
                        try
                        {
                            Console.WriteLine(reader);
                            while (reader.Read())
                            {
                                int a = (int)reader[0];
                               
                                SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
                                conn.Open(); //query
                                string query1 = "select Balance,StudentReg from Payment where StudentReg='" + a + "'";
                                SqlCommand command1 = new SqlCommand(query1, conn);

                                SqlDataReader Line = command1.ExecuteReader();
                                //MessageBox.Show("ff");
                                try
                                {
                                    Console.WriteLine(Line);
                                    while (Line.Read())

                                    {
                                        int r = (int)Line[0];
                                        int s = (int)Line[1];

                                    //MessageBox.Show(r.ToString());
                                        Form7 frm7 = new Form7(r,s);
                                        frm7.Show();
                                        

                                        this.Hide();
                                        
                                    }

                                }
                                finally
                                {
                                    //Should close reader after reading finish
                                    Line.Close();
                                    //reader.Close();
                                }

                            }

                        }
                        finally
                        {
                            if (reader != null)
                            {
                                reader.Close();
                            }
                        }
                        



                    
                }
                else
                {
                    MessageBox.Show("Index Number not Valid");

                }

                //command.ExecuteNonQuery();


                // string IndexNumber = IndexNo.Text;
                IndexNo.Text = "";

                connection.Close();



            }
            catch
            {
                MessageBox.Show("Error occured in Connection.");

            }
        }
       
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void IndexNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) & !char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }
    }
}
