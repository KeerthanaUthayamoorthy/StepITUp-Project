﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Teacher_Selection
{
    public partial class Form2 : Form
    {
        SqlConnection con;
        SqlDataAdapter adap;
        DataSet ds;
        SqlCommandBuilder cmdb1;

        public object DataGridView1 { get; private set; }

        public Form2()
        {
            InitializeComponent();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection();
                con.ConnectionString = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
                con.Open();
                adap = new SqlDataAdapter("Select  TeacherReg, Name, Subject from Teacher", con);
  
                ds = new System.Data.DataSet();
                adap.Fill(ds, "Student");
                dataGridView1.DataSource = ds.Tables[0];

                DataGridViewCheckBoxColumn chc = new DataGridViewCheckBoxColumn();
                chc.HeaderText = "Selection";
                chc.Width = 70;
                //chc.Name = "Selection";
                dataGridView1.Columns.Insert(3, chc);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Submit_Click(object sender, EventArgs e)
        {
            for (int count = 0; count < dataGridView1.Rows.Count; count++)
            {
                if ((Boolean) dataGridView1.Rows[count].Cells[3].Value)
                {
                    string query = "insert into Student_Teacher(StudentReg,TeacherReg,Status) VALUES ('" + 3 + "','" + 1 + "','"+1+"')";

                    SqlCommand command = new SqlCommand(query, con);

                    command.ExecuteNonQuery();
                    con.Close();
                }
                else
                {



                }
            


            }

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}