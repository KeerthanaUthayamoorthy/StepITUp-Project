﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teacher_Selection
{
    public partial class Head_Report_Month_Selection : Form
    {
        public Head_Report_Month_Selection()
        {
            InitializeComponent();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Head_Report_Month_Selection_Load(object sender, EventArgs e)
        {
            String sDate = DateTime.Now.ToString();
            DateTime datevalue = (Convert.ToDateTime(sDate.ToString()));

            
            int mn = Convert.ToInt32(datevalue.Month.ToString());
           
            if (mn == 1)
            {
                String m = "January";
                comboBox.Text = m;
            }
            else if (mn == 2)
            {
                String m = "February";
                comboBox.Text = m;
            }
            else if (mn == 3)
            {
                String m = "March";
                comboBox.Text = m;
            }
            else if (mn == 4)
            {
                String m = "April";
                comboBox.Text = m;
            }
            else if (mn == 5)
            {
                String m = "May";
                comboBox.Text = m;
            }
            else if (mn == 6)
            {
                String m = "June";
                comboBox.Text = m;
            }
            else if (mn == 7)
            {
                String m = "July";
                comboBox.Text = m;
            }
            else if (mn == 8)
            {
                String m = "August";
                comboBox.Text = m;
            }
            else if (mn == 9)
            {
                String m = "September";
                comboBox.Text = m;
            }
            else if (mn == 10)
            {
                String m = "October";
                comboBox.Text = m;
            }
            else if (mn == 11)
            {
                String m = "November";
                comboBox.Text = m;
            }
            else
            {
                String m = "December";
                comboBox.Text = m;
            }

           

        }

        private void Submit_Click(object sender, EventArgs e)
        {
            String gettext = comboBox.SelectedItem.ToString();

            Head_Report frm = new Head_Report(gettext);
            frm.Show();
            this.Hide();
          
            /*
                string conn = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=DataTest;Integrated Security=True";
                SqlConnection connection = new SqlConnection(conn);
                connection.Open(); //query
                String query = "update Payment3 set gettex";
                SqlCommand command = new SqlCommand(query, connection);

                    command.ExecuteNonQuery();
                    //MessageBox.Show(month);
                    connection.Close();
                    this.Close();*/
               
            
            
            


        }

        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void Year_Click(object sender, EventArgs e)
        {

        }

        private void Year_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ( !char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back )
            {
                e.Handled = true;
            }
        }
    }
    }

