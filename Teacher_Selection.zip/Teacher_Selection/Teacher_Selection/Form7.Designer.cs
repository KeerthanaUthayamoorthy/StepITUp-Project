﻿namespace Teacher_Selection
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Ok = new System.Windows.Forms.Button();
            this.Amount = new System.Windows.Forms.TextBox();
            this.Balance = new System.Windows.Forms.Label();
            this.Payment = new System.Windows.Forms.Label();
            this.AmountPay = new System.Windows.Forms.TextBox();
            this.Close = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Month = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Ok
            // 
            this.Ok.Location = new System.Drawing.Point(245, 275);
            this.Ok.Name = "Ok";
            this.Ok.Size = new System.Drawing.Size(113, 47);
            this.Ok.TabIndex = 5;
            this.Ok.Text = "Ok";
            this.Ok.UseVisualStyleBackColor = true;
            this.Ok.Click += new System.EventHandler(this.Ok_Click);
            // 
            // Amount
            // 
            this.Amount.Location = new System.Drawing.Point(302, 109);
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.Size = new System.Drawing.Size(209, 26);
            this.Amount.TabIndex = 4;
            // 
            // Balance
            // 
            this.Balance.Location = new System.Drawing.Point(50, 109);
            this.Balance.Name = "Balance";
            this.Balance.Size = new System.Drawing.Size(128, 20);
            this.Balance.TabIndex = 3;
            this.Balance.Text = "Balance";
            // 
            // Payment
            // 
            this.Payment.AutoSize = true;
            this.Payment.Location = new System.Drawing.Point(50, 185);
            this.Payment.Name = "Payment";
            this.Payment.Size = new System.Drawing.Size(71, 20);
            this.Payment.TabIndex = 6;
            this.Payment.Text = "Payment";
            this.Payment.Click += new System.EventHandler(this.label1_Click);
            // 
            // AmountPay
            // 
            this.AmountPay.Location = new System.Drawing.Point(302, 185);
            this.AmountPay.Name = "AmountPay";
            this.AmountPay.Size = new System.Drawing.Size(209, 26);
            this.AmountPay.TabIndex = 7;
            this.AmountPay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Payment_KeyPress);
            // 
            // Close
            // 
            this.Close.Location = new System.Drawing.Point(420, 275);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(102, 47);
            this.Close.TabIndex = 8;
            this.Close.Text = "Close";
            this.Close.UseVisualStyleBackColor = true;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Month";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Month
            // 
            this.Month.Location = new System.Drawing.Point(302, 44);
            this.Month.Name = "Month";
            this.Month.Size = new System.Drawing.Size(209, 26);
            this.Month.TabIndex = 10;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(561, 355);
            this.Controls.Add(this.Month);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.AmountPay);
            this.Controls.Add(this.Payment);
            this.Controls.Add(this.Ok);
            this.Controls.Add(this.Amount);
            this.Controls.Add(this.Balance);
            this.Name = "Form7";
            this.Text = "Form7";
            this.Load += new System.EventHandler(this.Form7_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Ok;
        private System.Windows.Forms.TextBox Amount;
        private System.Windows.Forms.Label Balance;
        private System.Windows.Forms.Label Payment;
        private System.Windows.Forms.TextBox AmountPay;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Month;
    }
}