﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace timer
{
    public partial class NonPaid_StudentList : Form
    {
        public NonPaid_StudentList()
        {
            InitializeComponent();
        }

        private void NonPaid_StudentList_Load(object sender, EventArgs e)
        {
            button1.BackColor = Color.Purple;
            button2.BackColor = Color.Purple;
            dataGridView1.RowsDefaultCellStyle.SelectionBackColor = Color.Purple;
            string conn = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
            SqlConnection connection = new SqlConnection(conn);
            //connection.Open(); //query
            String que = "select student_Reg,Fees,Balance from Payment where Student_Status='" + "Active" + "'";
            SqlDataAdapter da = new SqlDataAdapter(que, connection);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DataRow[] result = ds.Tables[0].Select();
            int i = 0;
            foreach (DataRow row in result)
            {
                int Reg = Int32.Parse(row[0].ToString());
                int Fees = Int32.Parse(row[1].ToString());
                int Balance = Int32.Parse(row[2].ToString());

                if ((3*Fees > Balance &&Balance > 2 * Fees) || Balance == 2 * Fees)
                {
                    //MessageBox.Show(Reg.ToString());

                    // SqlDataAdapter da1 = new SqlDataAdapter("Select IndexNo,Name from StudentNew where StudentReg='" + Reg + "'", connection);

                    string con = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
                    //SqlConnection connection = new SqlConnection(conn);
                    //connection.Open(); //query
                    String query = "Select IndexNo,Name from StudentNew where StudentReg='" + Reg + "'";
                    using (SqlConnection connectionObj = new SqlConnection(
                          con))
                    {
                        SqlCommand command = new SqlCommand(
                            query, connectionObj);
                        connectionObj.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        try
                        {
                            //int rowNum = 0;
                            Console.WriteLine(reader);
                            while (reader.Read())
                            {
                                String t1 = (String)reader[0];
                                String t2 = (String)reader[1];
                                this.dataGridView1.Rows.Add();
                                this.dataGridView1.Rows[i].Cells[0].Value = t1;
                                this.dataGridView1.Rows[i].Cells[1].Value = t2;
                                //rowNum++;
                                //DataSet ds1 = new DataSet();
                                //da1.Fill(ds1, "StudentNew");
                                //dataGridView1.Rows.Add(ds1);
                                // dataGridView1. = ds1.Tables[0];
                                //MessageBox.Show(IndexNo);
                                //dataGridView1.Rows[i].Cells[0].Value = IndexNo;
                                //dataGridView1.Rows[i].Cells[1].Value = Name;
                                i++;
                            }
                        }
                        finally
                        {
                            reader.Close();
                        }

                    }
                }
                else if (Balance > 3 * Fees || Balance == 3 * Fees)
                {
                    string conn1 = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
                    SqlConnection connection1 = new SqlConnection(conn1);
                    connection1.Open(); //query

                    string query = "update Payment set Student_Status='"+"Deactive"+"' where Student_Reg='"+Reg+"'";

                    SqlCommand command = new SqlCommand(query, connection1);

                    command.ExecuteNonQuery();
                    connection1.Close();
                }
                }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Document doc = new Document(iTextSharp.text.PageSize.LETTER, 10, 10, 42, 35);
            String sDate = DateTime.Now.ToString();
            DateTime datevalue = (Convert.ToDateTime(sDate.ToString()));
            int mn = Convert.ToInt32(datevalue.Month.ToString());
            String yy = datevalue.Year.ToString();
            string day = mn + "_" + yy;
            PdfWriter wr1 = PdfWriter.GetInstance(doc, new FileStream("NonPaid_StudentList.pdf", FileMode.Create));
            doc.Open();
            Paragraph par = new Paragraph("Following index numbers didn't paid their 2 month fees.");
            doc.Add(par);
            //doc.P = iTextSharp.text.Rectangle.BOX;
            //iTextSharp.text.Image Png = iTextSharp.text.Image.GetInstance("maxresdefault.jpg");
            //Png.ScalePercent(100f);
            //Png.ScaleToFit(100f, 200f);
            //Png.SetAbsolutePosition(doc.PageSize.Width - 36f - 72f, doc.PageSize.Height - 36f - 21f);
            //doc.Add(Png);
            Paragraph par1 = new Paragraph("\n\n\n");
            doc.Add(par1);
            PdfPTable table = new PdfPTable(dataGridView1.Columns.Count);
            for (int j = 0; j < dataGridView1.Columns.Count; j++)
            {
                table.AddCell(new Phrase(dataGridView1.Columns[j].HeaderText));
            }
            table.HeaderRows = 1;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int k = 0; k < dataGridView1.Columns.Count; k++)
                {
                    if (dataGridView1[k, i].Value != null)
                    {
                        table.AddCell(new Phrase(dataGridView1[k, i].Value.ToString()));
                    }
                }
            }
            doc.Add(table);
            doc.Close();
            MessageBox.Show("list saved successfully.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
