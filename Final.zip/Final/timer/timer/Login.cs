﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace timer
{

    public partial class Login : Form
    {
        FinalBackground fBg = new FinalBackground();
        public Login()
        {
            InitializeComponent();
            Password.PasswordChar = '*';
        }
        
        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True");
            //connection.Open();
            SqlDataAdapter SDA = new SqlDataAdapter("Select Role from Login_Table Where UserName='" + Username.Text + "' and Password='" + Password.Text + "' and Status='Active'", connection);
            //SqlDataAdapter SDA = new SqlDataAdapter("Select Count(*) from Login_Table Where UserName='" + Username.Text + "' and Password='" + Password.Text + "' ", connection);
            DataTable DT = new DataTable();
            SDA.Fill(DT);
            if (DT.Rows.Count == 1)
            {



                String query = "select Password,Role from Login_Table where UserName='" + Username.Text + "' ";

                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                String UserName = Username.Text;
                String Pass = Password.Text;

                while (reader.Read())
                {


                    String PassCo = (String)reader[0];
                    String UserRole = (String)reader[1];
                    //connection.Close();

                    if (Pass == PassCo)
                    {
                        // MessageBox.Show("correct");

                        //SqlConnection connection1 = new SqlConnection(@"Data Source=ISHA-PC\SQLEXPRESS;Initial Catalog=DatabaseKeer;Integrated Security=True");
                        //

                        //String query1 = "select Role from Login_Table where UserName='" + Username.Text + "' ";
                        //SqlCommand command1 = new SqlCommand(query1, connection);
                        //connection1.Open();
                        //SqlDataReader reader1 = command1.ExecuteReader();
                        //while (reader1.Read())
                        //{


                        //String UserRole = (String)reader1[0];
                        //SIU_Project.StudentDetailCheck sDcheck = new SIU_Project.StudentDetailCheck();
                         //sDcheck.fRole= UserRole;
                        //MessageBox.Show(sDcheck.fRole);
                        if (UserRole == "Teacher")
                        {
                            
                            SIU_Project.Teacher frm = new SIU_Project.Teacher();
                            frm.Show();
                            this.Close();
                            fBg.Close();

                        }
                        else if (UserRole == "Admin")
                        {
                           
                            //Monthly fees update
                            String sDate = DateTime.Now.ToString();
                            DateTime datevalue = (Convert.ToDateTime(sDate.ToString()));
                            int dy = Convert.ToInt32(datevalue.Day.ToString());//To get system date
                            if (dy > 25 || dy < 10)
                            {
                                String conn = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
                                SqlConnection connection4 = new SqlConnection(conn);
                                connection4.Open(); //query
                                String query0 = "select StudentKey from Initial_Payment where UpdateStatus='" + "Deactive" + "'";
                                SqlDataAdapter da = new SqlDataAdapter(query0, connection4);
                                DataSet ds = new DataSet();
                                da.Fill(ds);
                                DataRow[] result = ds.Tables[0].Select();
                                foreach (DataRow dr in result)
                                {
                                    int TR = Convert.ToInt32(dr[0].ToString());
                                    string query1 = "update Initial_Payment set Balance = Fees+Balance where StudentKey='" + TR + "'";
                                    SqlCommand cmdCount = new SqlCommand(query1, connection);
                                    cmdCount.ExecuteNonQuery();
                                    String qu = "update Initial_Payment set UpdateStatus ='" + "Active" + "'where StudentStatus='" + "Active" + "'";
                                    SqlCommand cmd = new SqlCommand(qu, connection);
                                    cmd.ExecuteNonQuery();
                                }
                            }
                            else if (dy > 9 && dy < 26)
                            {
                                String conn = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
                                SqlConnection connection5 = new SqlConnection(conn);
                                connection5.Open(); //query
                                String query0 = "select StudentKey from Initial_Payment where UpdateStatus='" + "Active" + "'";
                                SqlDataAdapter da = new SqlDataAdapter(query0, connection5);
                                DataSet ds = new DataSet();
                                da.Fill(ds);
                                DataRow[] result = ds.Tables[0].Select();
                                foreach (DataRow dr in result)
                                {
                                    int TR = Convert.ToInt32(dr[0].ToString());
                                    String qu = "update Initial_Payment set UpdateStatus ='" + "Deactive" + "'where StudentKey='" + TR + "'";
                                    SqlCommand cmd = new SqlCommand(qu, connection5);
                                    cmd.ExecuteNonQuery();
                                }
                            }


                            try
                            {
                                //Get date,month and year from system
                               String sDate1 = DateTime.Now.ToString();
                               DateTime datevalue1 = (Convert.ToDateTime(sDate1.ToString()));
                                int dy1 = Convert.ToInt32(datevalue.Day.ToString());
                               int mn1 = Convert.ToInt32(datevalue.Month.ToString());
                                int yy1 = Convert.ToInt32(datevalue.Year.ToString());
                                String m = "";
                                if (mn1 == 1)
                                {
                                    m = "January";
                                }
                                else if (mn1 == 2)
                                {
                                    m = "February";
                                }
                                else if (mn1 == 3)
                                {
                                    m = "March";
                                }
                                else if (mn1 == 4)
                                {
                                    m = "April";
                                }
                                else if (mn1 == 5)
                                {
                                    m = "May";
                                }
                                else if (mn1 == 6)
                                {
                                    m = "June";
                                }
                                else if (mn1 == 7)
                                {
                                    m = "July";
                                }
                                else if (mn1 == 8)
                                {
                                    m = "August";
                                }
                                else if (mn1 == 9)
                                {
                                    m = "September";
                                }
                                else if (mn1 == 10)
                                {
                                    m = "October";
                                }
                                else if (mn1 == 11)
                                {
                                    m = "November";
                                }
                                else
                                {
                                    m = "December";
                                }
                                if (dy > 5 && dy < 20)
                                {
                                    SqlConnection connection6 = new SqlConnection(@"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True");
                                    connection6.Open(); //query
                                    String query2 = "select TeacherKey, Name from Teacher2 where Status='" + "Active" + "'";
                                    SqlDataAdapter da = new SqlDataAdapter(query2, connection6);
                                    DataSet ds = new DataSet();
                                    da.Fill(ds);
                                    DataRow[] result = ds.Tables[0].Select();
                                    foreach (DataRow dr in result)
                                    {
                                        int TR = Convert.ToInt32(dr[0].ToString());
                                        String name = dr[1].ToString();
                                        String query1 = "SELECT COUNT(*) FROM Student_Teacher where TeacherKey = '" + TR + "' AND Status = '" + "1" + "'";
                                        SqlCommand command7 = new SqlCommand(query1, connection);
                                        int count = (int)command7.ExecuteScalar();
                                        String query7 = "insert into Count_Table (TeacherKey,TeacherName,Month,Year,NumberOfStudents)values('" + TR + "','" + name + "','" + m + "','" + yy1 + "','" + count + "')";
                                        SqlCommand command1 = new SqlCommand(query7, connection6);
                                        command1.ExecuteNonQuery();
                                    }
                                    String query3 = "SELECT COUNT(*) FROM Teacher2 where Status='" + "Active" + "' ";
                                    SqlCommand command2 = new SqlCommand(query3, connection);
                                    int count1 = (int)command2.ExecuteScalar();
                                    String query4 = "insert into Count_Table (TeacherKey,TeacherName,Month,Year,NumberOfStudents)values('" + 0 + "','" + "Teacher" + "','" + m + "','" + yy1 + "','" + count1 + "')";
                                    SqlCommand command3 = new SqlCommand(query4, connection);
                                    command3.ExecuteNonQuery();
                                    String query5 = "SELECT COUNT(*) FROM Student where Status='" + "Active" + "' ";
                                    SqlCommand command4 = new SqlCommand(query5, connection);
                                    int count2 = (int)command4.ExecuteScalar();
                                    String query6 = "insert into Count_Table (TeacherKey,TeacherName,Month,Year,NumberOfStudents)values('" + 0 + "','" + "Student" + "','" + m + "','" + yy1 + "','" + count2 + "')";
                                    SqlCommand command5 = new SqlCommand(query6, connection);
                                    command5.ExecuteNonQuery();
                                }
                            }
                            catch
                            {
                                //System.Environment.Exit(0);
                            }


                            //String sDate = DateTime.Now.ToString();
                            // DateTime datevalue = (Convert.ToDateTime(sDate.ToString()));
                            // int dy = Convert.ToInt32(datevalue.Day.ToString());
                            int mn = Convert.ToInt32(datevalue.Month.ToString());
                            int yy = Convert.ToInt32(datevalue.Year.ToString());
                            string month = mn.ToString() + "_" + yy.ToString();

                            if (dy > 10 || dy < 25)
                            {


                                String conn = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
                                SqlConnection connection1 = new SqlConnection(conn);
                                connection1.Open(); //query

                                String query0 = "select Month from Notification2 where Month='" + month + "'";
                                SqlDataAdapter da = new SqlDataAdapter(query0, connection1);
                                DataTable ds = new DataTable();
                                da.Fill(ds);
                                if (ds.Rows.Count > 0)
                                {
                                    SIU_Project.Admin fo = new SIU_Project.Admin();
                                    
                                    SIU_Project.Admin frm1=new SIU_Project.Admin();
                                    frm1.Show();
                                    this.Close();
                                    fBg.Close();
                                }
                                else
                                {
                                    SIU_Project.Admin frm1 = new SIU_Project.Admin();
                                    frm1.Show();
                                    Notification frm = new Notification();
                                    frm.Show();
                                    this.Close();
                                    fBg.Close();

                                }
                            }
                            else
                            {
                                this.Hide();
                            }
                        
                        // Teacher_Selection.Adminpage frm = new Teacher_Selection.Adminpage();


                    }
                        else if (UserRole == "Head")
                        {
                            
                            SIU_Project.Head frm = new SIU_Project.Head();
                            frm.Show();
                            this.Close();
                            fBg.Close();
                        }
                        ClearTextBox();

                        //}


                    }
                    else
                    {
                        MessageBox.Show("You have entered an Incorrect Password!!!");
                        ClearTextBox();
                    }
                }
            }



            else
            {
                MessageBox.Show("Invalid Login to the System!!! Please Try Again");
                ClearTextBox();
            }

        }

        private void ClearTextBox()
        {
            Username.Text = "";
            Password.Text = "";
        }

        private void Username_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
