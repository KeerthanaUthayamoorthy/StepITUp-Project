﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace timer
{
    public partial class Notification : Form
    {
        //public static NotifyIcon m_objNotifyIcon;

        public Notification()
        {
            InitializeComponent();
           
        }

        private void Notification_Load(object sender, EventArgs e)
        {
            //m_objNotifyIcon = this.notifyIcon1;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Notification_Move(object sender, EventArgs e)
        {
           //if (this.WindowState == FormWindowState.Minimized)
           //{
             //  }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NonPaid_StudentList frm = new NonPaid_StudentList();
            //this.Hide();
            frm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Show();
        }

        private void view_Click(object sender, EventArgs e)
        {
            String sDate = DateTime.Now.ToString();
            DateTime datevalue = (Convert.ToDateTime(sDate.ToString()));
            int dy = Convert.ToInt32(datevalue.Day.ToString());
            //int mn = Convert.ToInt32(datevalue.Month.ToString());
            String mn = datevalue.Month.ToString();
            MessageBox.Show(mn);
            int yy = Convert.ToInt32(datevalue.Year.ToString());
            string conn = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
            SqlConnection connection = new SqlConnection(conn);
            connection.Open(); //query
           
            String month = mn.ToString() + "_" + yy.ToString();
           
            string query = "insert into Notification2(Month,Status) VALUES ('" + month + "','" + "Active" + "')";

            SqlCommand command = new SqlCommand(query, connection);

            command.ExecuteNonQuery();
            connection.Close();
            NonPaid_StudentList frm = new NonPaid_StudentList();
            this.Hide();
            frm.Show();

        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Hide();
            notifyIcon1.ShowBalloonTip(1000, "Time Reached", "Put the non paid student list.Click here to get the information.", ToolTipIcon.Info);

        }
    }
}
