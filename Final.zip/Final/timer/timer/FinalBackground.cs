﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace timer
{
    public partial class FinalBackground : Form
    {
        public FinalBackground()
        {
            InitializeComponent();
        }

        private void FinalBackground_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            Login log = new Login();
            log.StartPosition = FormStartPosition.CenterScreen;
            log.Show(this);
        }

        private void closeX_Click(object sender, EventArgs e)
        {
           // this.Close();
            Application.Exit();
        }
    }
}
