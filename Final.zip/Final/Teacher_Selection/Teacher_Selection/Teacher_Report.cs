﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text.pdf;
using System.IO;
using iTextSharp.text;

namespace Teacher_Selection
{
    public partial class Teacher_Report : Form
    {
      
        public Teacher_Report(String month, String year)
        {

            InitializeComponent();
            textBox1.Text = month;
            textBox2.Text = year;
        }

        private void Teacher_Report_Load(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
            connection.Open(); //query
            String month = textBox1.Text;
            String year = textBox2.Text;
            string query = "select Number from Count_Table where TeacherReg='" + 1 + "' and Month='" + month + "' and Year='" + year + "'";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            try
            {
                Console.WriteLine(reader);
                while (reader.Read())
                {
                    int a = (int)reader[0];
                    textBox3.Text = a.ToString();
                }
            }
            finally
            {
                reader.Close();
            }
            string query1 = "select Fees from Teacher2 where TeacherReg='" + 1 + "' ";
            SqlCommand command1 = new SqlCommand(query1, connection);
            SqlDataReader reader1 = command1.ExecuteReader();
            try
            {
                Console.WriteLine(reader1);
                while (reader1.Read())
                {
                    int b = (int)reader1[0];
                    textBox4.Text = b.ToString();
                }
            }
            finally
            {
                reader1.Close();
            }
           textBox5.Text = (Convert.ToInt32(textBox3.Text) * Convert.ToInt32(textBox4.Text)).ToString();
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Document doc =new Document(iTextSharp.text.PageSize.LETTER,10,10,42,35);
            PdfWriter wr1 = PdfWriter.GetInstance(doc, new FileStream("Head.pdf", FileMode.Create));
            doc.Open();
            Paragraph par = new Paragraph("Report now");
            doc.Add(par);
            //doc.P = iTextSharp.text.Rectangle.BOX;
            iTextSharp.text.Image Png = iTextSharp.text.Image.GetInstance("maxresdefault.jpg");
            Png.ScalePercent(100f);
            Png.ScaleToFit(40f, 75f);
            //Png.SetAbsolutePosition(doc.PageSize.Width - 36f - 72f, doc.PageSize.Height - 36f - 21f);
            doc.Add(Png);
            List list = new List(List.UNORDERED);
            list.IndentationLeft = 30f;
            list.Add(new ListItem(Month.Text+"                         " +textBox1.Text));
            list.Add(Year.Text+"                           "+textBox2.Text);
            list.Add(nostudents.Text + "   " + textBox3.Text);
            list.Add(Fees.Text + "             " + textBox4.Text);
            list.Add(total.Text + "             " + textBox5.Text);
            doc.Add(list);
           
            doc.Close();
            MessageBox.Show("Report saved successfully.");
        }
    }
}
