﻿namespace Teacher_Selection
{
    partial class AdminPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.title = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.student = new System.Windows.Forms.Button();
            this.teacherselection = new System.Windows.Forms.Button();
            this.batch = new System.Windows.Forms.Button();
            this.Payment = new System.Windows.Forms.Button();
            this.balance = new System.Windows.Forms.Button();
            this.paymentpay = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.title.Dock = System.Windows.Forms.DockStyle.Top;
            this.title.Location = new System.Drawing.Point(0, 0);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(950, 100);
            this.title.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.teacherselection);
            this.panel2.Controls.Add(this.Payment);
            this.panel2.Controls.Add(this.batch);
            this.panel2.Controls.Add(this.student);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(175, 707);
            this.panel2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.paymentpay);
            this.panel3.Controls.Add(this.balance);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(178, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(772, 707);
            this.panel3.TabIndex = 1;
            // 
            // student
            // 
            this.student.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.student.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.student.ForeColor = System.Drawing.Color.White;
            this.student.Location = new System.Drawing.Point(0, 3);
            this.student.Name = "student";
            this.student.Size = new System.Drawing.Size(172, 180);
            this.student.TabIndex = 0;
            this.student.Text = "Student";
            this.student.UseVisualStyleBackColor = false;
            // 
            // teacherselection
            // 
            this.teacherselection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.teacherselection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.teacherselection.ForeColor = System.Drawing.Color.White;
            this.teacherselection.Location = new System.Drawing.Point(3, 360);
            this.teacherselection.Name = "teacherselection";
            this.teacherselection.Size = new System.Drawing.Size(172, 174);
            this.teacherselection.TabIndex = 1;
            this.teacherselection.Text = "Teacher Selection";
            this.teacherselection.UseVisualStyleBackColor = false;
            this.teacherselection.Click += new System.EventHandler(this.teacherselection_Click);
            // 
            // batch
            // 
            this.batch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.batch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.batch.ForeColor = System.Drawing.Color.White;
            this.batch.Location = new System.Drawing.Point(3, 189);
            this.batch.Name = "batch";
            this.batch.Size = new System.Drawing.Size(172, 165);
            this.batch.TabIndex = 2;
            this.batch.Text = "Batch Creation";
            this.batch.UseVisualStyleBackColor = false;
            // 
            // Payment
            // 
            this.Payment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Payment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Payment.ForeColor = System.Drawing.Color.White;
            this.Payment.Location = new System.Drawing.Point(0, 540);
            this.Payment.Name = "Payment";
            this.Payment.Size = new System.Drawing.Size(172, 164);
            this.Payment.TabIndex = 3;
            this.Payment.Text = "Payment";
            this.Payment.UseVisualStyleBackColor = false;
            // 
            // balance
            // 
            this.balance.BackColor = System.Drawing.Color.Purple;
            this.balance.ForeColor = System.Drawing.Color.White;
            this.balance.Location = new System.Drawing.Point(3, 540);
            this.balance.Name = "balance";
            this.balance.Size = new System.Drawing.Size(159, 81);
            this.balance.TabIndex = 4;
            this.balance.Text = "Balance Check";
            this.balance.UseVisualStyleBackColor = false;
            this.balance.Click += new System.EventHandler(this.balance_Click);
            // 
            // paymentpay
            // 
            this.paymentpay.BackColor = System.Drawing.Color.Purple;
            this.paymentpay.ForeColor = System.Drawing.Color.White;
            this.paymentpay.Location = new System.Drawing.Point(3, 623);
            this.paymentpay.Name = "paymentpay";
            this.paymentpay.Size = new System.Drawing.Size(159, 81);
            this.paymentpay.TabIndex = 5;
            this.paymentpay.Text = "Make Payment";
            this.paymentpay.UseVisualStyleBackColor = false;
            this.paymentpay.Click += new System.EventHandler(this.paymentpay_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(162, 90);
            this.button1.TabIndex = 6;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(0, 96);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(162, 90);
            this.button2.TabIndex = 7;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // AdminPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(950, 807);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.title);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdminPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminPage";
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel title;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button teacherselection;
        private System.Windows.Forms.Button Payment;
        private System.Windows.Forms.Button batch;
        private System.Windows.Forms.Button student;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button paymentpay;
        private System.Windows.Forms.Button balance;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}