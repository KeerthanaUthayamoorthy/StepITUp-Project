﻿namespace Teacher_Selection
{
    partial class Teacher_Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Month = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.total = new System.Windows.Forms.Label();
            this.Fees = new System.Windows.Forms.Label();
            this.nostudents = new System.Windows.Forms.Label();
            this.Year = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Month
            // 
            this.Month.AutoSize = true;
            this.Month.Location = new System.Drawing.Point(109, 42);
            this.Month.Name = "Month";
            this.Month.Size = new System.Drawing.Size(54, 20);
            this.Month.TabIndex = 0;
            this.Month.Text = "Month";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(295, 42);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 26);
            this.textBox1.TabIndex = 1;
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.Location = new System.Drawing.Point(118, 342);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(104, 20);
            this.total.TabIndex = 2;
            this.total.Text = "Total Amount";
            // 
            // Fees
            // 
            this.Fees.AutoSize = true;
            this.Fees.Location = new System.Drawing.Point(109, 258);
            this.Fees.Name = "Fees";
            this.Fees.Size = new System.Drawing.Size(105, 20);
            this.Fees.TabIndex = 3;
            this.Fees.Text = "Fees Amount";
            // 
            // nostudents
            // 
            this.nostudents.AutoSize = true;
            this.nostudents.Location = new System.Drawing.Point(109, 183);
            this.nostudents.Name = "nostudents";
            this.nostudents.Size = new System.Drawing.Size(149, 20);
            this.nostudents.TabIndex = 4;
            this.nostudents.Text = "Number of students";
            // 
            // Year
            // 
            this.Year.AutoSize = true;
            this.Year.Location = new System.Drawing.Point(109, 106);
            this.Year.Name = "Year";
            this.Year.Size = new System.Drawing.Size(43, 20);
            this.Year.TabIndex = 5;
            this.Year.Text = "Year";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(295, 115);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 26);
            this.textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(295, 183);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 26);
            this.textBox3.TabIndex = 7;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(295, 255);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 26);
            this.textBox4.TabIndex = 8;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(295, 336);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 26);
            this.textBox5.TabIndex = 9;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(489, 144);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 65);
            this.button1.TabIndex = 10;
            this.button1.Text = "Save PDF";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Teacher_Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 386);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.Year);
            this.Controls.Add(this.nostudents);
            this.Controls.Add(this.Fees);
            this.Controls.Add(this.total);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Month);
            this.Name = "Teacher_Report";
            this.Text = "Teacher_Report";
            this.Load += new System.EventHandler(this.Teacher_Report_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Month;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.Label Fees;
        private System.Windows.Forms.Label nostudents;
        private System.Windows.Forms.Label Year;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button1;
    }
}