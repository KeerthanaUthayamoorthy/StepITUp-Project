﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teacher_Selection
{
    public partial class Form5 : Form
    {
        Form4 frm4 = new Form4();

        public Form5(int r)
        {
            InitializeComponent();
            Amount.Text = r.ToString();
        }

        private void Ok_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            
            

        }
    }
}
