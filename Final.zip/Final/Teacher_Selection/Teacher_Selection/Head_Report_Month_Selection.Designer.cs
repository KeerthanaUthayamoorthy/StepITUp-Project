﻿namespace Teacher_Selection
{
    partial class Head_Report_Month_Selection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Month = new System.Windows.Forms.Label();
            this.comboBox = new System.Windows.Forms.ComboBox();
            this.Submit = new System.Windows.Forms.Button();
            this.Year = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // Month
            // 
            this.Month.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Month.Location = new System.Drawing.Point(64, 94);
            this.Month.Name = "Month";
            this.Month.Size = new System.Drawing.Size(95, 35);
            this.Month.TabIndex = 0;
            this.Month.Text = "Month";
            this.Month.Click += new System.EventHandler(this.label1_Click);
            // 
            // comboBox
            // 
            this.comboBox.FormattingEnabled = true;
            this.comboBox.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.comboBox.Location = new System.Drawing.Point(240, 98);
            this.comboBox.Name = "comboBox";
            this.comboBox.Size = new System.Drawing.Size(184, 28);
            this.comboBox.TabIndex = 1;
            this.comboBox.SelectedIndexChanged += new System.EventHandler(this.comboBox_SelectedIndexChanged);
            // 
            // Submit
            // 
            this.Submit.Location = new System.Drawing.Point(383, 238);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(99, 44);
            this.Submit.TabIndex = 2;
            this.Submit.Text = "Submit";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // Year
            // 
            this.Year.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Year.Location = new System.Drawing.Point(65, 183);
            this.Year.Name = "Year";
            this.Year.Size = new System.Drawing.Size(100, 23);
            this.Year.TabIndex = 3;
            this.Year.Text = "Year";
            this.Year.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(240, 183);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(184, 28);
            this.comboBox1.TabIndex = 4;
            // 
            // Head_Report_Month_Selection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(581, 386);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.Year);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.comboBox);
            this.Controls.Add(this.Month);
            this.Name = "Head_Report_Month_Selection";
            this.Text = "Head_Report_Month_Selection";
            this.Load += new System.EventHandler(this.Head_Report_Month_Selection_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Month;
        private System.Windows.Forms.ComboBox comboBox;
        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.Label Year;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}