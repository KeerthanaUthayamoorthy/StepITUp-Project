﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teacher_Selection
{
    public partial class Form7 : Form
    {
        int s1,r1;
        
        public Form7(int r,int s)
        {
            InitializeComponent();
            Amount.Text = r.ToString();
            s1 = s;
            r1 = r;
        }

        private void Ok_Click(object sender, EventArgs e)
        {
           try
            {
                string conn = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
                SqlConnection connection = new SqlConnection(conn);
                connection.Open(); //query
                int balance = Convert.ToInt32(this.Amount.Text) - Convert.ToInt32(this.AmountPay.Text);
                string query = "update Payment set Balance= '"+balance+"' where Student_Reg= '"+s1+"' ";
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
               
                int payment = Convert.ToInt32(this.AmountPay.Text);
                String month = Month.Text;
                String sDate = DateTime.Now.ToString();
                DateTime datevalue = (Convert.ToDateTime(sDate.ToString()));
                String yy = datevalue.Year.ToString();
                String month_year = month + "_" + yy;
               
                string query1 = "insert into Payment2 (StudentReg,Payment,Month) VALUES  ('"+s1+ "','"+payment+ "','"+ month_year + "')";
                SqlCommand command1 = new SqlCommand(query1,connection);
                command1.ExecuteNonQuery();
                MessageBox.Show("Payment succesfully updated");
                connection.Close();
                this.Close();

            }
            catch
            {
                MessageBox.Show("Error occured in connection");

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Payment_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            String sDate = DateTime.Now.ToString();
            DateTime datevalue = (Convert.ToDateTime(sDate.ToString()));
            int mn = Convert.ToInt32(datevalue.Month.ToString());
            if (mn == 1)
            {
                String m ="January";
                Month.Text = m;
            }
            else if(mn == 2)
            {
                String m = "February";
                Month.Text = m;
            }
            else if (mn == 3)
            {
                String m = "March";
                Month.Text = m;
            }
            else if (mn == 4)
            {
                String m = "April";
                Month.Text = m;
            }
            else if (mn == 5)
            {
                String m = "May";
                Month.Text = m;
            }
            else if (mn == 6)
            {
                String m = "June";
                Month.Text = m;
            }
            else if (mn == 7)
            {
                String m = "July";
                Month.Text = m;
            }
            else if (mn == 8)
            {
                String m = "August";
                Month.Text = m;
            }
            else if (mn == 9)
            {
                String m = "September";
                Month.Text = m;
            }
            else if (mn == 10)
            {
                String m = "October";
                Month.Text = m;
            }
            else if (mn == 11)
            {
                String m = "November";
                Month.Text = m;
            }
            else 
            {
                String m = "December";
                Month.Text = m;
            }
            Month.ReadOnly = true;
            Amount.ReadOnly = true;

        }

        private void Month_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void Form7_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Amount_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
