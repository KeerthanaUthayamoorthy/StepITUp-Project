﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teacher_Selection
{
    public partial class Head_Report_Month_Selection : Form
    {
        public Head_Report_Month_Selection()
        {
            InitializeComponent();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Head_Report_Month_Selection_Load(object sender, EventArgs e)
        {
            String sDate = DateTime.Now.ToString();
            DateTime datevalue = (Convert.ToDateTime(sDate.ToString()));

            int yy = Convert.ToInt32(datevalue.Year.ToString());
            int mn = Convert.ToInt32(datevalue.Month.ToString());

            if (mn == 1)
            {
                String m = "January";
                comboBox.Text = m;
            }
            else if (mn == 2)
            {
                String m = "February";
                comboBox.Text = m;
            }
            else if (mn == 3)
            {
                String m = "March";
                comboBox.Text = m;
            }
            else if (mn == 4)
            {
                String m = "April";
                comboBox.Text = m;
            }
            else if (mn == 5)
            {
                String m = "May";
                comboBox.Text = m;
            }
            else if (mn == 6)
            {
                String m = "June";
                comboBox.Text = m;
            }
            else if (mn == 7)
            {
                String m = "July";
                comboBox.Text = m;
            }
            else if (mn == 8)
            {
                String m = "August";
                comboBox.Text = m;
            }
            else if (mn == 9)
            {
                String m = "September";
                comboBox.Text = m;
            }
            else if (mn == 10)
            {
                String m = "October";
                comboBox.Text = m;
            }
            else if (mn == 11)
            {
                String m = "November";
                comboBox.Text = m;
            }
            else
            {
                String m = "December";
                comboBox.Text = m;
            }

            comboBox1.Text = yy.ToString();
            SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
            connection.Open(); //query
            SqlCommand command = new SqlCommand();
           
            command.CommandText = "Select Distinct Year from Count_Table";
            command.Connection = connection;
            SqlDataReader rd = command.ExecuteReader();

            while (rd.Read())
            {
                comboBox1.Items.Add(rd[0].ToString());
            }
        

        }

        private void Submit_Click(object sender, EventArgs e)
        {
            String month = comboBox.SelectedItem.ToString();
            String year = comboBox1.SelectedItem.ToString();
            Head_Report frm = new Head_Report(month,year);
            frm.Show();
            this.Hide();
        }

        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void Year_Click(object sender, EventArgs e)
        {

        }

        private void Year_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
    }

