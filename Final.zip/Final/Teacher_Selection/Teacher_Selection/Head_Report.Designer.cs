﻿namespace Teacher_Selection
{
    partial class Head_Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Head_Report));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.mon = new System.Windows.Forms.Label();
            this.Month = new System.Windows.Forms.TextBox();
            this.no_student = new System.Windows.Forms.Label();
            this.no_teacher = new System.Windows.Forms.Label();
            this.AmontReceived = new System.Windows.Forms.Label();
            this.nostudent = new System.Windows.Forms.TextBox();
            this.noteacher = new System.Windows.Forms.TextBox();
            this.AmountReceived = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.save = new System.Windows.Forms.Button();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.TeachersTotal = new System.Windows.Forms.TextBox();
            this.Year = new System.Windows.Forms.Label();
            this.yea = new System.Windows.Forms.TextBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // mon
            // 
            this.mon.AutoSize = true;
            this.mon.Location = new System.Drawing.Point(134, 37);
            this.mon.Name = "mon";
            this.mon.Size = new System.Drawing.Size(54, 20);
            this.mon.TabIndex = 0;
            this.mon.Text = "Month";
            // 
            // Month
            // 
            this.Month.Location = new System.Drawing.Point(369, 31);
            this.Month.Name = "Month";
            this.Month.Size = new System.Drawing.Size(100, 26);
            this.Month.TabIndex = 1;
            // 
            // no_student
            // 
            this.no_student.AutoSize = true;
            this.no_student.Location = new System.Drawing.Point(626, 40);
            this.no_student.Name = "no_student";
            this.no_student.Size = new System.Drawing.Size(149, 20);
            this.no_student.TabIndex = 2;
            this.no_student.Text = "Number of students";
            // 
            // no_teacher
            // 
            this.no_teacher.AutoSize = true;
            this.no_teacher.Location = new System.Drawing.Point(626, 103);
            this.no_teacher.Name = "no_teacher";
            this.no_teacher.Size = new System.Drawing.Size(145, 20);
            this.no_teacher.TabIndex = 3;
            this.no_teacher.Text = "Number of Teacher";
            // 
            // AmontReceived
            // 
            this.AmontReceived.AutoSize = true;
            this.AmontReceived.Location = new System.Drawing.Point(134, 179);
            this.AmontReceived.Name = "AmontReceived";
            this.AmontReceived.Size = new System.Drawing.Size(135, 20);
            this.AmontReceived.TabIndex = 4;
            this.AmontReceived.Text = "Amount Received";
            // 
            // nostudent
            // 
            this.nostudent.Location = new System.Drawing.Point(870, 37);
            this.nostudent.Name = "nostudent";
            this.nostudent.Size = new System.Drawing.Size(100, 26);
            this.nostudent.TabIndex = 5;
            // 
            // noteacher
            // 
            this.noteacher.Location = new System.Drawing.Point(870, 100);
            this.noteacher.Name = "noteacher";
            this.noteacher.Size = new System.Drawing.Size(100, 26);
            this.noteacher.TabIndex = 6;
            this.noteacher.TextChanged += new System.EventHandler(this.noteacher_TextChanged);
            // 
            // AmountReceived
            // 
            this.AmountReceived.Location = new System.Drawing.Point(369, 179);
            this.AmountReceived.Name = "AmountReceived";
            this.AmountReceived.Size = new System.Drawing.Size(100, 26);
            this.AmountReceived.TabIndex = 7;
            this.AmountReceived.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(24, 251);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(724, 300);
            this.dataGridView1.TabIndex = 8;
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(1086, 88);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(122, 44);
            this.save.TabIndex = 10;
            this.save.Text = "Save PDF";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(626, 185);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Amount Paid For Teachers";
            // 
            // TeachersTotal
            // 
            this.TeachersTotal.Location = new System.Drawing.Point(870, 185);
            this.TeachersTotal.Name = "TeachersTotal";
            this.TeachersTotal.Size = new System.Drawing.Size(100, 26);
            this.TeachersTotal.TabIndex = 12;
            // 
            // Year
            // 
            this.Year.AutoSize = true;
            this.Year.Location = new System.Drawing.Point(137, 103);
            this.Year.Name = "Year";
            this.Year.Size = new System.Drawing.Size(43, 20);
            this.Year.TabIndex = 13;
            this.Year.Text = "Year";
            // 
            // yea
            // 
            this.yea.Location = new System.Drawing.Point(369, 97);
            this.yea.Name = "yea";
            this.yea.Size = new System.Drawing.Size(100, 26);
            this.yea.TabIndex = 14;
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(792, 251);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Amount for teacher";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Number of students";
            this.chart1.Series.Add(series1);
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(456, 300);
            this.chart1.TabIndex = 15;
            this.chart1.Text = "chart1";
            // 
            // Head_Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1289, 600);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.yea);
            this.Controls.Add(this.Year);
            this.Controls.Add(this.TeachersTotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.save);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.AmountReceived);
            this.Controls.Add(this.noteacher);
            this.Controls.Add(this.nostudent);
            this.Controls.Add(this.AmontReceived);
            this.Controls.Add(this.no_teacher);
            this.Controls.Add(this.no_student);
            this.Controls.Add(this.Month);
            this.Controls.Add(this.mon);
            this.Name = "Head_Report";
            this.Text = "Head_Report";
            this.Load += new System.EventHandler(this.Head_Report_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label mon;
        private System.Windows.Forms.TextBox Month;
        private System.Windows.Forms.Label no_student;
        private System.Windows.Forms.Label no_teacher;
        private System.Windows.Forms.Label AmontReceived;
        private System.Windows.Forms.TextBox nostudent;
        private System.Windows.Forms.TextBox noteacher;
        private System.Windows.Forms.TextBox AmountReceived;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TeachersTotal;
        private System.Windows.Forms.Label Year;
        private System.Windows.Forms.TextBox yea;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
    }
}