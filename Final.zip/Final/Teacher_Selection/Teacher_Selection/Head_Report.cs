﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace Teacher_Selection
{
    public partial class Head_Report : Form
    {

        public Head_Report(String month, String year)
        {
            InitializeComponent();
            Month.Text = month;
            yea.Text = year;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Head_Report_Load(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
            connection.Open(); //query

            string month = Month.Text;
            string year = yea.Text;

            if (month == "January")
            {
                String que = "select January from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();

            }
            else if (month == "February")
            {
                String que = "select February from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();
            }
            else if (month == "March")
            {
                String que = "select March from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();
            }
            else if (month == "April")
            {
                String que = "select April from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();
            }
            else if (month == "May")
            {
                String que = "select May from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();
            }
            else if (month == "June")
            {
                String que = "select June from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();
            }
            else if (month == "July")
            {
                String que = "select July from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();
            }

            else if (month == "August")
            {
                String que = "select August from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();
            }
            else if (month == "September")
            {
                String que = "select September from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();
            }
            else if (month == "October")
            {
                String que = "select October from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();
            }
            else if (month == "November")
            {
                String que = "select November from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();
            }
            else if (month == "December")
            {
                String que = "select December from Payment3 ";
                SqlDataAdapter da = new SqlDataAdapter(que, connection);
                DataSet ds = new DataSet();
                da.Fill(ds);
                DataRow[] result = ds.Tables[0].Select();
                int sum = 0;
                foreach (DataRow row in result)
                {
                    sum += Int32.Parse(row[0].ToString());
                }
                AmountReceived.Text = sum.ToString();
            }
            String query = "select Number from Count_Table where Name='" + "Teacher" + "' and Month='" + month + "' and Year='" + year + "'";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            try
            {
                Console.WriteLine(reader);
                while (reader.Read())
                {
                    int a = (int)reader[0];
                    noteacher.Text = a.ToString();
                }
            }
            finally
            {
                reader.Close();
            }
            String query1 = "select Number from Count_Table where Name='" + "Student" + "' and Month='" + month + "' and Year='" + year + "'";
            SqlCommand command1 = new SqlCommand(query1, connection);
            SqlDataReader reader1 = command1.ExecuteReader();
            try
            {
                Console.WriteLine(reader);
                while (reader1.Read())
                {
                    int b = (int)reader1[0];
                    nostudent.Text = b.ToString();
                }
            }
            finally
            {
                reader1.Close();
            }
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
            con.Open();
            SqlDataAdapter adap = new SqlDataAdapter("Select  TeacherReg,Name,Fees from Teacher2 where Status='" + "Active" + "'", con);

            DataSet ds1 = new DataSet();
            adap.Fill(ds1, "Teacher2");
            dataGridView1.DataSource = ds1.Tables[0];
            //dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].ReadOnly = true;
            dataGridView1.Columns[2].ReadOnly = true;
           
            DataGridViewTextBoxColumn chc = new DataGridViewTextBoxColumn();
            chc.HeaderText = "Number";
            chc.Name = "Number";
            dataGridView1.Columns.Insert(3, chc);

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {

                String Reg = dataGridView1.Rows[i].Cells[0].Value.ToString();
                int n = Convert.ToInt32(Reg);
                String conn = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
                SqlConnection connec = new SqlConnection(conn);
                connec.Open();
                String que1 = "select Number from Count_Table where TeacherReg ='" + n + "' and MONTH='" + month + "' and Year='" + year + "'";
                SqlCommand cmd = new SqlCommand(que1, connec);
                SqlDataReader reader2 = cmd.ExecuteReader();
                try
                {
                    Console.WriteLine(reader2);
                    while (reader2.Read())
                    {
                        int c = (int)reader2[0];
                        dataGridView1.Rows[i].Cells[3].Value = c.ToString();

                    }
                }
                catch
                {
                    reader2.Close();
                }

            }
            DataGridViewTextBoxColumn chc1 = new DataGridViewTextBoxColumn();
            chc1.HeaderText = "Amount";
            chc1.Name = "Amount";
            dataGridView1.Columns.Insert(4, chc1);
            int Fees, Number;
            int sum2 = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (int.TryParse(dataGridView1.Rows[i].Cells[2].Value.ToString(), out Fees) && int.TryParse(dataGridView1.Rows[i].Cells[3].Value.ToString(), out Number))
                {
                    int price = Fees * Number; dataGridView1.Rows[i].Cells[4].Value = price.ToString();
                }
                sum2 += Convert.ToInt32(dataGridView1.Rows[i].Cells[4].Value.ToString());


            }
            TeachersTotal.Text = sum2.ToString();

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                this.chart1.Series["Amount for teacher"].Points.AddXY(dataGridView1.Rows[i].Cells[1].Value,dataGridView1.Rows[i].Cells[4].Value);
                this.chart1.Series["Number of students"].Points.AddXY(dataGridView1.Rows[i].Cells[1].Value, dataGridView1.Rows[i].Cells[3].Value);

            }
        }
    

        

    private void noteacher_TextChanged(object sender, EventArgs e)
        {

        }

        private void save_Click(object sender, EventArgs e)
        {
            /*PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(PrintImage);
            printPreviewDialog1.Document = pd;
            printPreviewDialog1.Show();
            pd.Print();*/
            Document doc = new Document(iTextSharp.text.PageSize.LETTER, 10, 10, 42, 35);
            string month = Month.Text;
            string year = yea.Text;
            string day = month + "_" + year;
            PdfWriter wr1 = PdfWriter.GetInstance(doc, new FileStream("day.pdf", FileMode.Create));
            doc.Open();
            Paragraph par = new Paragraph("Report");
            doc.Add(par);
            //doc.P = iTextSharp.text.Rectangle.BOX;
            iTextSharp.text.Image Png = iTextSharp.text.Image.GetInstance("maxresdefault.jpg");
            Png.ScalePercent(100f);
            Png.ScaleToFit(100f, 200f);
            //Png.SetAbsolutePosition(doc.PageSize.Width - 36f - 72f, doc.PageSize.Height - 36f - 21f);
            doc.Add(Png);
           
            List list = new List(List.UNORDERED);
            list.IndentationLeft = 30f;
            list.Add(new ListItem(mon.Text + "                         " + Month.Text));
            list.Add(yea.Text + "                           " + Year.Text);
            list.Add(AmontReceived.Text + "   " + AmountReceived.Text);
            list.Add(no_student.Text + "             " + nostudent.Text);
            list.Add(no_teacher.Text + "             " + noteacher.Text);
            list.Add(label1.Text + "             " + TeachersTotal.Text);
            doc.Add(list);

            Paragraph par1 = new Paragraph("\n\n\n");
            doc.Add(par1);
            PdfPTable table = new PdfPTable(dataGridView1.Columns.Count);
            for (int j = 0; j < dataGridView1.Columns.Count; j++)
            {
                table.AddCell(new Phrase(dataGridView1.Columns[j].HeaderText));
            }
            table.HeaderRows = 1;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int k = 0; k < dataGridView1.Columns.Count; k++)
                {
                    if (dataGridView1[k, i].Value != null)
                    {
                        table.AddCell(new Phrase(dataGridView1[k, i].Value.ToString()));
                    }
                }
            }
            doc.Add(table);
                doc.Close();
            MessageBox.Show("Report saved successfully.");
        }
        void PrintImage(object o, PrintPageEventArgs e)
        {
            /*int x = SystemInformation.WorkingArea.X;
            int y = SystemInformation.WorkingArea.Y;
            int width = this.Width;
            int height = this.Height;

            Rectangle bounds = new Rectangle(x, y, width, height);

            Bitmap img = new Bitmap(width, height);

            this.DrawToBitmap(img, bounds);
            Point p = new Point(100, 100);
            e.Graphics.DrawImage(img, p);*/
        }
    }
}