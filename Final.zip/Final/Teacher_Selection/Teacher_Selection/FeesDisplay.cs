﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teacher_Selection
{
    public partial class FeesDisplay : Form
    {
        int a1;
        public FeesDisplay(int a)
        {
            InitializeComponent();
            a1 = a;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FeesDisplay_Load(object sender, EventArgs e)
        {
            try
            {
                string conn = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
                string query = "select TeacherReg from Student_Teacher where StudentReg='" + a1 + "' and Status = '1'";
                using (SqlConnection connection = new SqlConnection(conn))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open(); //query
                    SqlDataReader reader = command.ExecuteReader();
                    int fee1 = 0;
                    try
                    {
                        Console.WriteLine(reader);
                        while (reader.Read())
                        {
                            int a = (int)reader[0];
                            string b = a.ToString();
                            string query1 = "select Fees from Teacher2 where TeacherReg='" + b + "' and Status = 'Active'";
                            using (SqlConnection connection1 = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True"))
                            {
                                SqlCommand command1 = new SqlCommand(query1, connection1);
                                connection1.Open(); //query
                                SqlDataReader reader1 = command1.ExecuteReader();
                                //int fee2 = 0;
                                try
                                {
                                    Console.WriteLine(reader1);
                                    while (reader1.Read())
                                    {

                                        int fee3 = (int)reader1[0];

                                        fee1 = (int)fee1 + (int)fee3;
                                    }


                                    //reader.Close();
                                }
                                catch
                                {

                                    reader1.Close();
                                }
                            }
                        }
                        reader.Close();
                        textBox1.Text = fee1.ToString();
                        string conne = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
                        SqlConnection connection2 = new SqlConnection(conne);
                        string query2 = "update Payment set Fees='" + fee1 + "' where Student_Reg= '" + a1 + "' ";
                        SqlCommand command2 = new SqlCommand(query2, connection2);
                        connection2.Open(); //query
                        command2.ExecuteNonQuery();
                        MessageBox.Show("Happy1");
                        //MessageBox.Show("Excecute");
                        connection2.Close();
                    }
                    catch
                    {
                        //reader.Close();
                    }








                }
            }
            catch
            {
                MessageBox.Show("Error occured in connection");
            }
            //this.Close();

        }

        private void Print_Click(object sender, EventArgs e)
        {
            string query1 = "select Name,Address,IndexNo from Student where StudentReg='" + a1 + "'";
            using (SqlConnection connection1 = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True"))
            {
                SqlCommand command1 = new SqlCommand(query1, connection1);
                connection1.Open(); //query
                SqlDataReader reader1 = command1.ExecuteReader();
                //int fee2 = 0;
                try
                {
                    Console.WriteLine(reader1);
                    while (reader1.Read())
                    {

                        String name = (String)reader1[0];
                        String address = (String)reader1[1];
                        String index= (String)reader1[2];
                        String fee = textBox1.Text;
                       
                        Document doc = new Document(iTextSharp.text.PageSize.LETTER, 10, 10, 42, 35);
                          PdfWriter wr1 = PdfWriter.GetInstance(doc, new FileStream("Head1.pdf", FileMode.Create));
                          doc.Open();
                          Paragraph par = new Paragraph("Admission Card");
                          doc.Add(par);
                          //doc.P = iTextSharp.text.Rectangle.BOX;
                         iTextSharp.text.Image Png = iTextSharp.text.Image.GetInstance("1.jpg");
                          Png.ScalePercent(50f);
                         // Png.ScaleToFit(75f, 75f);
                          Png.SetAbsolutePosition(doc.PageSize.Width - 36f - 72f, doc.PageSize.Height - 36f - 216.6f);
                          doc.Add(Png);
                        
                          List list = new List(List.UNORDERED);
                          list.IndentationLeft = 30f;
                          list.Add(new ListItem("Name:-"+"   "+name));
                          list.Add("Address:-" + "   " + address);
                          list.Add("\n");
                          list.Add("School:-" + "   " );
                          list.Add("Index Number:-" + "   " + index);
                          list.Add("Monthly Fee:-" + "   " + fee);
                          doc.Add(list);

                          doc.Close();
                          MessageBox.Show("Report saved successfully.");
                    }
                }
                catch
                {
                    reader1.Close();
                }
            }
        }
    }
}

