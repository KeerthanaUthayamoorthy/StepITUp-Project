﻿namespace Teacher_Selection
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.IndexNo = new System.Windows.Forms.TextBox();
            this.Close = new System.Windows.Forms.Button();
            this.Submit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Index Number";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // IndexNo
            // 
            this.IndexNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IndexNo.Location = new System.Drawing.Point(185, 95);
            this.IndexNo.Name = "IndexNo";
            this.IndexNo.Size = new System.Drawing.Size(242, 39);
            this.IndexNo.TabIndex = 1;
            this.IndexNo.TextChanged += new System.EventHandler(this.IndexNo_TextChanged);
            this.IndexNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.IndexNo_KeyPress);
            // 
            // Close
            // 
            this.Close.Location = new System.Drawing.Point(352, 244);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(75, 40);
            this.Close.TabIndex = 2;
            this.Close.Text = "Close";
            this.Close.UseVisualStyleBackColor = true;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // Submit
            // 
            this.Submit.Location = new System.Drawing.Point(185, 244);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(75, 40);
            this.Submit.TabIndex = 3;
            this.Submit.Text = "Submit";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 329);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.IndexNo);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox IndexNo;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Button Submit;
    }
}

