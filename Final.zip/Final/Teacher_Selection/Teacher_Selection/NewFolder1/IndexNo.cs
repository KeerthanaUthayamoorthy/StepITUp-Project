﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Teacher_Selection
{
    public partial class Form1 : Form
    {
        bool flag=false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void IndexNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) & !char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void Submit_Click(object sender, EventArgs e)
        {
            try
            {
                String reg = IndexNo.Text;
                SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
                connection.Open(); //query

               // string query = "insert into Teacher(Name,Subject) VALUES ('" + "abi" + "','" + IndexNo.Text + "')";

                SqlCommand command = new SqlCommand();
                command.CommandText = "Select * from [Student]";
                command.Connection = connection;
                SqlDataReader rd = command.ExecuteReader();
                while(rd.Read())
                {
                    flag = false;
                    if (rd[4].ToString() == "Active")
                    {
                        if (rd[3].ToString() == IndexNo.Text)
                        {
                            flag = true;
                            break;
                        }
                    }
                   
                }
                if (flag == true)
                {
                    //this.Hide();
                    /*using (SqlCommand q = connection.CreateCommand())
                    {
                        q.CommandText = String.Format(
                          @"select {0}
            from Student where IndexNo = @prmPizzaType", "StudentReg");

                        q.Parameters.AddWithValue("@prmPizzaType", IndexNo.Text);
                        var reader = q.ExecuteReader();
                        String n = reader.GetValue();*/

                           /*String n = "select StudentReg from StudentNew where IndexNo = IndexNo.Text";
                            SqlCommand sc = new SqlCommand(n, connection);
                            int p = (int)sc.ExecuteScalar();
                    Type q = p.GetType();*/
                    //String g = Convert.ToString(p);
                    //Type p = sc.GetType();
                            //textBox1.Text =q.ToString();

                    //select TeacherREg, Status from Student_Teacher where StudentReg = 2

                 /*using (SqlCommand q = connection.CreateCommand())
                        {
                            q.CommandText = String.Format(
                              @"select {0}
            from StudentNew
           where IndexNo = @prmPizzaType", StudentReg);

                            q.Parameters.AddWithValue("@prmPizzaType", IndexNo.Text);

                            using (var reader = q.ExecuteReader())
                            {
                                if (reader.Read())
                                {

                                    if (reader.Read())
                                    {
                                        //TODO: At least 2 values: put your code here
                                    }
                                }
                                else
                                {
                                    //TODO: no such value: put your code here
                                }
                            }
                        }
                    }*/






                    //load form2
                    Form2 frm = new Form2(reg);
                    frm.Show();
                    


                }
                else
                {
                    MessageBox.Show("Index Number not Valid");

                }

                //command.ExecuteNonQuery();


               // string IndexNumber = IndexNo.Text;
                IndexNo.Text = "";

                connection.Close();
                
                

            }
            catch
            {
                MessageBox.Show("Error occured in Connection.");

            }
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void IndexNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
