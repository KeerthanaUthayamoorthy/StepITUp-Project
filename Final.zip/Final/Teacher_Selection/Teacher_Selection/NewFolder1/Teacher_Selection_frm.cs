﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Teacher_Selection
{
    public partial class Form2 : Form
    {
        SqlConnection con;
        SqlDataAdapter adap;
        DataSet ds;
        SqlCommandBuilder cmdb1;


        String reg1;
        public Form2(String reg)
        {
            InitializeComponent();
            reg1 = reg;
           
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                
                con = new SqlConnection();
                con.ConnectionString = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
                con.Open();
                adap = new SqlDataAdapter("Select  TeacherReg, Name, Fees from Teacher2 where Status='Active'", con);
  
                ds = new System.Data.DataSet();
                adap.Fill(ds, "Student");
                dataGridView1.DataSource = ds.Tables[0];

                DataGridViewCheckBoxColumn chc = new DataGridViewCheckBoxColumn();
                chc.HeaderText = "Selection";
                chc.Width = 70;
                //chc.Name = "Selection";
                dataGridView1.Columns.Insert(3, chc);
                dataGridView1.Columns[1].ReadOnly = true;
                dataGridView1.Columns[0].Visible = false;
                dataGridView1.Columns[1].ReadOnly = true;
                dataGridView1.Columns[2].ReadOnly = true;

                con.Close();

                string query = "select StudentReg from Student where IndexNo='" + reg1 + "'";
                using (SqlConnection connection1 = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True"))
                {
                    SqlCommand command = new SqlCommand(query, connection1);
                    connection1.Open(); //query
                    SqlDataReader reader = command.ExecuteReader();
                    try
                    {
                        Console.WriteLine(reader);
                        while (reader.Read())
                        {
                            int a = (int)reader[0];
                           
                            SqlConnection connection2 = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
                            connection2.Open(); //query
                            SqlCommand command1 = new SqlCommand();
                            
                            command1.CommandText = "Select TeacherReg from Student_Teacher where StudentReg='" + a + "' and  Status='1'";
                            command1.Connection = connection2;
                            

                            for (int count = 0; count < dataGridView1.Rows.Count; count++)
                            {
                                
                                SqlDataReader rd = command1.ExecuteReader();
                                
                                try
                                {
                                    while (rd.Read())
                                    {
                                        if (rd[0].ToString() == dataGridView1.Rows[count].Cells[0].Value.ToString())
                                        {
                                            //MessageBox.Show(rd[0].ToString());
                                            dataGridView1.Rows[count].Cells[3].Value = true;

                                            break;

                                        }
                                    }
                                    rd.Close();
                                }

                                catch
                                {
                                    rd.Close();
                                }

                            }
                            connection2.Close();

                        }
                        reader.Close();
                    }
                    catch
                    {
                        reader.Close();
                    }
                }

                

            }
           
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Submit_Click(object sender, EventArgs e)
        {
            string query = "select StudentReg from Student where IndexNo='" + reg1 + "'";
            using (SqlConnection connection1 = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True"))
            {
                SqlCommand command = new SqlCommand(query, connection1);
                connection1.Open(); //query
                SqlDataReader reader = command.ExecuteReader();
                try
                {
                    Console.WriteLine(reader);
                    while (reader.Read())
                    {
                        int a = (int)reader[0];
                        
                        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True");
                        conn.Open(); //query
                        SqlCommand command2 = new SqlCommand();
                        command2.CommandText = "Select TeacherReg from Student_Teacher where StudentReg='" + a + "'";
                        command2.Connection = conn;

                        for (int count = 0; count < dataGridView1.Rows.Count; count++)
                        {
                            SqlDataReader rd = command2.ExecuteReader();
                            try
                            {
                                bool god = false;
                                while (rd.Read())
                                {
                                    if (rd[0].ToString() == dataGridView1.Rows[count].Cells[0].Value.ToString())
                                    {
                                        god = true;
                                        int s = (int)rd[0];
                                        break;

                                    }
                                }
                                //MessageBox.Show(god.ToString());
                                //rd.Close();
                                if (god == true)
                                {
                                    if ((bool)(dataGridView1.Rows[count].Cells[3].Value) == false)
                                    {
                                        //MessageBox.Show("Hi");
                                        string l = dataGridView1.Rows[count].Cells[0].Value.ToString();
                                        string connec = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
                                        SqlConnection connection4 = new SqlConnection(connec);
                                        string query4 = "update Student_Teacher set Status='0' where StudentReg='" + a + "' and TeacherReg='" + l + "'";

                                        SqlCommand command1 = new SqlCommand(query4, connection4);

                                        connection4.Open();
                                        command1.ExecuteNonQuery();
                                        //MessageBox.Show("show1");
                                        connection4.Close();
                                    }
                                    else
                                    {
                                        //MessageBox.Show("Hi1");
                                        string j = dataGridView1.Rows[count].Cells[0].Value.ToString();
                                        string Conn = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
                                        SqlConnection connection5 = new SqlConnection(Conn);
                                        string query5 = "update Student_Teacher set Status='1' where StudentReg='" + a + "' and TeacherReg='" + j + "'";

                                        SqlCommand command4 = new SqlCommand(query5, connection5);

                                        connection5.Open();
                                        command4.ExecuteNonQuery();
                                        //MessageBox.Show("show3");
                                        connection5.Close();
                                    }
                                }
                                else
                                {
                                    if ((bool)(dataGridView1.Rows[count].Cells[3].Value) == true)
                                    {
                                        MessageBox.Show(a.ToString());
                                        String z = dataGridView1.Rows[count].Cells[0].Value.ToString();
                                        MessageBox.Show(z);
                                        string conne = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
                                        SqlConnection connection3 = new SqlConnection(conne);
                                        connection3.Open();
                                        string query3 = "insert into Student_Teacher(StudentReg,TeacherReg,Status) values('" + a + "', '" + z + "' ,'1')";
                                        SqlCommand command3 = new SqlCommand(query3, connection3);
                                        command3.ExecuteNonQuery();

                                        //MessageBox.Show("show2");
                                        connection3.Close();
                                    }

                                }

                                rd.Close();
                            }

                            catch
                            {
                                rd.Close();
                            }

                        }
                        conn.Close();
                        this.Hide();
                      
                        FeesDisplay form = new FeesDisplay(a);
                        form.Show();
                        

                        this.Close();
                       

                    }
                }
                catch { }
                }
        }





                

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}