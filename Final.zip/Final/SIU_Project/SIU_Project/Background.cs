﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIU_Project
{
    public partial class Background : Form
    {
        public Background()
        {
            InitializeComponent();
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            Admin h = new Admin();
            h.StartPosition = FormStartPosition.CenterScreen;
            h.Show(this);
        }

        private void Background_Load(object sender, EventArgs e)
        {

        }
    }
}
