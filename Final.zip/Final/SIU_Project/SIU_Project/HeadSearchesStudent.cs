﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIU_Project
{
    public partial class HeadSearchesStudent : Form
    {
        
        public HeadSearchesStudent()
        {
            InitializeComponent();
        }
        
        private void former_Click(object sender, EventArgs e)
        {
            StudentDetailCheck sDetailCheckForm = new StudentDetailCheck();
            sDetailCheckForm.Show();
            sDetailCheckForm.statusE = "Deactive";
            MessageBox.Show(sDetailCheckForm.statusE);
            
        }
        

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void current_Click(object sender, EventArgs e)
        {
            try
            {
                StudentDetailCheck sDetailCheckForm = new StudentDetailCheck();
                sDetailCheckForm.Show();
                sDetailCheckForm.statusE = "Active";
                MessageBox.Show(sDetailCheckForm.statusE);
            }
            catch {
                MessageBox.Show("Error");
            }


        }
        
    }
}
