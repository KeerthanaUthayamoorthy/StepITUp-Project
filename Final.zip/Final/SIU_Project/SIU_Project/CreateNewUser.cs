﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIU_Project
{
    public partial class CreateNewUser : Form
    {
        string role1;
        public CreateNewUser(String role)
        {
            InitializeComponent();
            role1 = role;
        }

        private void Create_Click(object sender, EventArgs e)
        {
            MessageBox.Show(role1);
            if (role1 == "Head")
            {
                string query1 = "select UserName from LoginTable";
                using (SqlConnection connection1 = new SqlConnection(@"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True"))
                {
                    SqlCommand command = new SqlCommand(query1, connection1);
                    connection1.Open(); //query
                    SqlDataReader reader = command.ExecuteReader();
                    bool us = false;
                    try
                    {
                        Console.WriteLine(reader);
                        while (reader.Read())
                        {
                            if (reader[0].ToString() == username.Text)
                            {
                                us = true;
                                break;
                            }
                        }
                        if (us == true)
                        {
                            if (pw.Text == compass.Text)
                            {
                                String connection = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
                                //open connection
                                SqlConnection connecObj = new SqlConnection(connection);
                                connecObj.Open();
                                string pw1 = pw.Text;
                                string query = "update LoginTable set Password='" + pw.Text + "' where UserName='" + username.Text + "'and Status='Active'";

                                SqlCommand command1 = new SqlCommand(query, connecObj);


                                command1.ExecuteNonQuery();
                                this.Close();
                                MessageBox.Show("Password changed successfully." + "\n" + "New password:-" + pw1);
                                connecObj.Close();
                            }
                            else
                            {
                                label3.Visible = true;
                                label3.Text = "Please enter correct passwords.";
                            }
                        }
                        else
                        {
                            label3.Text = "";
                            label3.Visible = true;
                            label3.Text = "Entered username is incorrect.";
                        }
                    }
                    catch { }
                }
            }
       
        else if (role1=="Teacher"){
                if (pw.Text == compass.Text)
                {
                    String connection = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
                    //open connection
                    SqlConnection connecObj = new SqlConnection(connection);
                    connecObj.Open();
                    string pw1 = pw.Text;
                    string query = "update LoginTable set Password='" + pw.Text + "' where UserName='" + "ano" + "'";

                    SqlCommand command1 = new SqlCommand(query, connecObj);


                    command1.ExecuteNonQuery();
                    this.Close();
                    MessageBox.Show("Password changed successfully." + "\n" + "New password:-" + pw1);
                    connecObj.Close();
                }
                else
                {
                    label3.Visible = true;
                    label3.Text = "Please enter correct passwords.";
                }
            }
        }

        private void CreateNewUser_Load(object sender, EventArgs e)
        {
            label3.Visible = false;
            if (role1 == "Teacher")
            {
                label1.Visible = false;
                username.Visible = false;
            }
        }
    }
}
