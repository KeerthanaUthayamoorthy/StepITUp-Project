﻿namespace SIU_Project
{
    partial class CreateNewUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Create = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.Label();
            this.pw = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.compass = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Create
            // 
            this.Create.Location = new System.Drawing.Point(378, 284);
            this.Create.Name = "Create";
            this.Create.Size = new System.Drawing.Size(75, 33);
            this.Create.TabIndex = 0;
            this.Create.Text = "Create";
            this.Create.UseVisualStyleBackColor = true;
            this.Create.Click += new System.EventHandler(this.Create_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(80, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "User Name";
            // 
            // username
            // 
            this.username.Location = new System.Drawing.Point(284, 76);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(100, 26);
            this.username.TabIndex = 2;
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.Location = new System.Drawing.Point(80, 158);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(113, 20);
            this.password.TabIndex = 3;
            this.password.Text = "New Password";
            // 
            // pw
            // 
            this.pw.Location = new System.Drawing.Point(284, 152);
            this.pw.Name = "pw";
            this.pw.Size = new System.Drawing.Size(100, 26);
            this.pw.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(80, 222);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Confirm Password";
            // 
            // compass
            // 
            this.compass.Location = new System.Drawing.Point(284, 216);
            this.compass.Name = "compass";
            this.compass.Size = new System.Drawing.Size(100, 26);
            this.compass.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(95, 256);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(289, 23);
            this.label3.TabIndex = 7;
            // 
            // CreateNewUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(488, 345);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.compass);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pw);
            this.Controls.Add(this.password);
            this.Controls.Add(this.username);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Create);
            this.Name = "CreateNewUser";
            this.Text = "CreateNewUser";
            this.Load += new System.EventHandler(this.CreateNewUser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Create;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.TextBox pw;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox compass;
        private System.Windows.Forms.Label label3;
    }
}