﻿namespace SIU_Project
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.chgPassWord = new System.Windows.Forms.Button();
            this.teacherselection = new System.Windows.Forms.Button();
            this.Payment = new System.Windows.Forms.Button();
            this.student = new System.Windows.Forms.Button();
            this.batch = new System.Windows.Forms.Button();
            this.balance = new System.Windows.Forms.Button();
            this.paymentpay = new System.Windows.Forms.Button();
            this.addstudent = new System.Windows.Forms.Button();
            this.search = new System.Windows.Forms.Button();
            this.former = new System.Windows.Forms.Button();
            this.current = new System.Windows.Forms.Button();
            this.title = new System.Windows.Forms.Panel();
            this.bodyAdmin = new System.Windows.Forms.Panel();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.splitter4 = new System.Windows.Forms.Splitter();
            this.splitter5 = new System.Windows.Forms.Splitter();
            this.splitter6 = new System.Windows.Forms.Splitter();
            this.splitter7 = new System.Windows.Forms.Splitter();
            this.panel7 = new System.Windows.Forms.Panel();
            this.splitter8 = new System.Windows.Forms.Splitter();
            this.panel8 = new System.Windows.Forms.Panel();
            this.splitter9 = new System.Windows.Forms.Splitter();
            this.logout = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.title.SuspendLayout();
            this.bodyAdmin.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.splitter1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 127);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(157, 597);
            this.panel2.TabIndex = 2;
            // 
            // chgPassWord
            // 
            this.chgPassWord.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.chgPassWord.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chgPassWord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chgPassWord.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F);
            this.chgPassWord.ForeColor = System.Drawing.Color.White;
            this.chgPassWord.Location = new System.Drawing.Point(0, 0);
            this.chgPassWord.Name = "chgPassWord";
            this.chgPassWord.Size = new System.Drawing.Size(154, 115);
            this.chgPassWord.TabIndex = 10;
            this.chgPassWord.Text = "Change Password";
            this.chgPassWord.UseVisualStyleBackColor = false;
            this.chgPassWord.Click += new System.EventHandler(this.chgPassWord_Click);
            // 
            // teacherselection
            // 
            this.teacherselection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.teacherselection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.teacherselection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.teacherselection.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F);
            this.teacherselection.ForeColor = System.Drawing.Color.White;
            this.teacherselection.Location = new System.Drawing.Point(0, 0);
            this.teacherselection.Margin = new System.Windows.Forms.Padding(2);
            this.teacherselection.Name = "teacherselection";
            this.teacherselection.Size = new System.Drawing.Size(154, 118);
            this.teacherselection.TabIndex = 1;
            this.teacherselection.Text = "Teacher Selection";
            this.teacherselection.UseVisualStyleBackColor = false;
            this.teacherselection.Click += new System.EventHandler(this.teacherselection_Click);
            // 
            // Payment
            // 
            this.Payment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Payment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Payment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Payment.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F);
            this.Payment.ForeColor = System.Drawing.Color.White;
            this.Payment.Location = new System.Drawing.Point(0, 0);
            this.Payment.Margin = new System.Windows.Forms.Padding(2);
            this.Payment.Name = "Payment";
            this.Payment.Size = new System.Drawing.Size(154, 118);
            this.Payment.TabIndex = 3;
            this.Payment.Text = "Payment";
            this.Payment.UseVisualStyleBackColor = false;
            this.Payment.Click += new System.EventHandler(this.Payment_Click);
            // 
            // student
            // 
            this.student.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.student.Dock = System.Windows.Forms.DockStyle.Fill;
            this.student.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.student.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F);
            this.student.ForeColor = System.Drawing.Color.White;
            this.student.Location = new System.Drawing.Point(0, 0);
            this.student.Margin = new System.Windows.Forms.Padding(2);
            this.student.Name = "student";
            this.student.Size = new System.Drawing.Size(154, 118);
            this.student.TabIndex = 0;
            this.student.Text = "Student";
            this.student.UseVisualStyleBackColor = false;
            this.student.Click += new System.EventHandler(this.student_Click);
            // 
            // batch
            // 
            this.batch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.batch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.batch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.batch.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F);
            this.batch.ForeColor = System.Drawing.Color.White;
            this.batch.Location = new System.Drawing.Point(0, 0);
            this.batch.Margin = new System.Windows.Forms.Padding(2);
            this.batch.Name = "batch";
            this.batch.Size = new System.Drawing.Size(154, 115);
            this.batch.TabIndex = 2;
            this.batch.Text = "Batch Creation";
            this.batch.UseVisualStyleBackColor = false;
            this.batch.Click += new System.EventHandler(this.batch_Click);
            // 
            // balance
            // 
            this.balance.BackColor = System.Drawing.Color.Gray;
            this.balance.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.balance.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balance.ForeColor = System.Drawing.Color.Black;
            this.balance.Location = new System.Drawing.Point(-1, 237);
            this.balance.Margin = new System.Windows.Forms.Padding(2);
            this.balance.Name = "balance";
            this.balance.Size = new System.Drawing.Size(211, 59);
            this.balance.TabIndex = 4;
            this.balance.Text = "Balance Check";
            this.balance.UseVisualStyleBackColor = false;
            this.balance.Click += new System.EventHandler(this.balance_Click);
            // 
            // paymentpay
            // 
            this.paymentpay.BackColor = System.Drawing.Color.Gray;
            this.paymentpay.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.paymentpay.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentpay.ForeColor = System.Drawing.Color.Black;
            this.paymentpay.Location = new System.Drawing.Point(-1, 296);
            this.paymentpay.Margin = new System.Windows.Forms.Padding(2);
            this.paymentpay.Name = "paymentpay";
            this.paymentpay.Size = new System.Drawing.Size(211, 59);
            this.paymentpay.TabIndex = 5;
            this.paymentpay.Text = "Make Payment";
            this.paymentpay.UseVisualStyleBackColor = false;
            this.paymentpay.Click += new System.EventHandler(this.paymentpay_Click);
            // 
            // addstudent
            // 
            this.addstudent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addstudent.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addstudent.Location = new System.Drawing.Point(-3, 2);
            this.addstudent.Margin = new System.Windows.Forms.Padding(2);
            this.addstudent.Name = "addstudent";
            this.addstudent.Size = new System.Drawing.Size(211, 59);
            this.addstudent.TabIndex = 6;
            this.addstudent.Text = "Add Student";
            this.addstudent.UseVisualStyleBackColor = true;
            this.addstudent.Click += new System.EventHandler(this.addstudent_Click);
            // 
            // search
            // 
            this.search.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.search.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search.Location = new System.Drawing.Point(-3, 61);
            this.search.Margin = new System.Windows.Forms.Padding(2);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(211, 59);
            this.search.TabIndex = 7;
            this.search.Text = "Search";
            this.search.UseVisualStyleBackColor = true;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // former
            // 
            this.former.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.former.Location = new System.Drawing.Point(208, 89);
            this.former.Name = "former";
            this.former.Size = new System.Drawing.Size(185, 29);
            this.former.TabIndex = 9;
            this.former.Text = "Former Student";
            this.former.UseVisualStyleBackColor = true;
            this.former.Click += new System.EventHandler(this.former_Click);
            // 
            // current
            // 
            this.current.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.current.Location = new System.Drawing.Point(208, 60);
            this.current.Name = "current";
            this.current.Size = new System.Drawing.Size(185, 30);
            this.current.TabIndex = 8;
            this.current.Text = "Current Student";
            this.current.UseVisualStyleBackColor = true;
            this.current.Click += new System.EventHandler(this.current_Click);
            // 
            // title
            // 
            this.title.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.title.Controls.Add(this.splitter9);
            this.title.Controls.Add(this.panel8);
            this.title.Controls.Add(this.panel7);
            this.title.Controls.Add(this.splitter2);
            this.title.Dock = System.Windows.Forms.DockStyle.Top;
            this.title.Location = new System.Drawing.Point(0, 0);
            this.title.Margin = new System.Windows.Forms.Padding(2);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(990, 127);
            this.title.TabIndex = 3;
            // 
            // bodyAdmin
            // 
            this.bodyAdmin.BackColor = System.Drawing.Color.Gray;
            this.bodyAdmin.Controls.Add(this.paymentpay);
            this.bodyAdmin.Controls.Add(this.addstudent);
            this.bodyAdmin.Controls.Add(this.balance);
            this.bodyAdmin.Controls.Add(this.search);
            this.bodyAdmin.Controls.Add(this.former);
            this.bodyAdmin.Controls.Add(this.current);
            this.bodyAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bodyAdmin.Location = new System.Drawing.Point(157, 127);
            this.bodyAdmin.Margin = new System.Windows.Forms.Padding(2);
            this.bodyAdmin.Name = "bodyAdmin";
            this.bodyAdmin.Size = new System.Drawing.Size(833, 597);
            this.bodyAdmin.TabIndex = 8;
            this.bodyAdmin.Click += new System.EventHandler(this.bodyAdminClick);
            this.bodyAdmin.Paint += new System.Windows.Forms.PaintEventHandler(this.bodyAdmin_Paint);
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter1.Location = new System.Drawing.Point(154, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 597);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // splitter2
            // 
            this.splitter2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter2.Location = new System.Drawing.Point(0, 124);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(990, 3);
            this.splitter2.TabIndex = 11;
            this.splitter2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.chgPassWord);
            this.panel1.Controls.Add(this.splitter7);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 472);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(154, 118);
            this.panel1.TabIndex = 11;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.batch);
            this.panel3.Controls.Add(this.splitter6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 354);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(154, 118);
            this.panel3.TabIndex = 12;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel4.Controls.Add(this.splitter5);
            this.panel4.Controls.Add(this.Payment);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 236);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(154, 118);
            this.panel4.TabIndex = 12;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.splitter4);
            this.panel5.Controls.Add(this.teacherselection);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 118);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(154, 118);
            this.panel5.TabIndex = 12;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel6.Controls.Add(this.splitter3);
            this.panel6.Controls.Add(this.student);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(154, 118);
            this.panel6.TabIndex = 12;
            // 
            // splitter3
            // 
            this.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter3.Location = new System.Drawing.Point(0, 115);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(154, 3);
            this.splitter3.TabIndex = 0;
            this.splitter3.TabStop = false;
            // 
            // splitter4
            // 
            this.splitter4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter4.Location = new System.Drawing.Point(0, 115);
            this.splitter4.Name = "splitter4";
            this.splitter4.Size = new System.Drawing.Size(154, 3);
            this.splitter4.TabIndex = 0;
            this.splitter4.TabStop = false;
            // 
            // splitter5
            // 
            this.splitter5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter5.Location = new System.Drawing.Point(0, 115);
            this.splitter5.Name = "splitter5";
            this.splitter5.Size = new System.Drawing.Size(154, 3);
            this.splitter5.TabIndex = 0;
            this.splitter5.TabStop = false;
            // 
            // splitter6
            // 
            this.splitter6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter6.Location = new System.Drawing.Point(0, 115);
            this.splitter6.Name = "splitter6";
            this.splitter6.Size = new System.Drawing.Size(154, 3);
            this.splitter6.TabIndex = 0;
            this.splitter6.TabStop = false;
            // 
            // splitter7
            // 
            this.splitter7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter7.Location = new System.Drawing.Point(0, 115);
            this.splitter7.Name = "splitter7";
            this.splitter7.Size = new System.Drawing.Size(154, 3);
            this.splitter7.TabIndex = 0;
            this.splitter7.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.BackgroundImage = global::SIU_Project.Properties.Resources.maxresdefault;
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel7.Controls.Add(this.splitter8);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(154, 124);
            this.panel7.TabIndex = 12;
            // 
            // splitter8
            // 
            this.splitter8.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter8.Location = new System.Drawing.Point(151, 0);
            this.splitter8.Name = "splitter8";
            this.splitter8.Size = new System.Drawing.Size(3, 124);
            this.splitter8.TabIndex = 0;
            this.splitter8.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.logout);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel8.Location = new System.Drawing.Point(870, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(120, 124);
            this.panel8.TabIndex = 13;
            // 
            // splitter9
            // 
            this.splitter9.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter9.Location = new System.Drawing.Point(867, 0);
            this.splitter9.Name = "splitter9";
            this.splitter9.Size = new System.Drawing.Size(3, 124);
            this.splitter9.TabIndex = 14;
            this.splitter9.TabStop = false;
            // 
            // logout
            // 
            this.logout.Dock = System.Windows.Forms.DockStyle.Top;
            this.logout.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.logout.ForeColor = System.Drawing.Color.White;
            this.logout.Location = new System.Drawing.Point(0, 0);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(120, 33);
            this.logout.TabIndex = 15;
            this.logout.Text = "Logout";
            this.logout.UseVisualStyleBackColor = true;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 724);
            this.Controls.Add(this.bodyAdmin);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.title);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Admin";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Admin_Load);
            this.panel2.ResumeLayout(false);
            this.title.ResumeLayout(false);
            this.bodyAdmin.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button teacherselection;
        private System.Windows.Forms.Button Payment;
        private System.Windows.Forms.Button batch;
        private System.Windows.Forms.Button student;
        private System.Windows.Forms.Button balance;
        private System.Windows.Forms.Button paymentpay;
        private System.Windows.Forms.Button addstudent;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.Button former;
        private System.Windows.Forms.Button current;
        private System.Windows.Forms.Button chgPassWord;
        private System.Windows.Forms.Panel title;
        private System.Windows.Forms.Panel bodyAdmin;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Splitter splitter7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Splitter splitter6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Splitter splitter5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Splitter splitter4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Splitter splitter3;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Splitter splitter9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Splitter splitter8;
        private System.Windows.Forms.Splitter splitter2;
    }
}