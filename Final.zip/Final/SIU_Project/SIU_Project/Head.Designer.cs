﻿namespace SIU_Project
{
    partial class Head
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Report = new System.Windows.Forms.Button();
            this.newUser = new System.Windows.Forms.Button();
            this.Teacher = new System.Windows.Forms.Button();
            this.Student = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.former = new System.Windows.Forms.Button();
            this.current = new System.Windows.Forms.Button();
            this.titlebar = new System.Windows.Forms.Panel();
            this.splitter4 = new System.Windows.Forms.Splitter();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.splitter8 = new System.Windows.Forms.Splitter();
            this.panel7 = new System.Windows.Forms.Panel();
            this.splitter7 = new System.Windows.Forms.Splitter();
            this.panel8 = new System.Windows.Forms.Panel();
            this.splitter6 = new System.Windows.Forms.Splitter();
            this.panel9 = new System.Windows.Forms.Panel();
            this.splitter5 = new System.Windows.Forms.Splitter();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.panel2 = new System.Windows.Forms.Panel();
            this.logOut = new System.Windows.Forms.Button();
            this.titlebar.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Report
            // 
            this.Report.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Report.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Report.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Report.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Report.ForeColor = System.Drawing.Color.White;
            this.Report.Location = new System.Drawing.Point(0, 0);
            this.Report.Name = "Report";
            this.Report.Size = new System.Drawing.Size(154, 120);
            this.Report.TabIndex = 2;
            this.Report.Text = "Report";
            this.Report.UseVisualStyleBackColor = false;
            this.Report.Click += new System.EventHandler(this.Report_Click);
            // 
            // newUser
            // 
            this.newUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.newUser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.newUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newUser.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newUser.ForeColor = System.Drawing.Color.White;
            this.newUser.Location = new System.Drawing.Point(0, 0);
            this.newUser.Name = "newUser";
            this.newUser.Size = new System.Drawing.Size(154, 117);
            this.newUser.TabIndex = 3;
            this.newUser.Text = "Create new user";
            this.newUser.UseVisualStyleBackColor = false;
            this.newUser.Click += new System.EventHandler(this.newUser_Click);
            // 
            // Teacher
            // 
            this.Teacher.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Teacher.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Teacher.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Teacher.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Teacher.ForeColor = System.Drawing.Color.White;
            this.Teacher.Location = new System.Drawing.Point(0, 0);
            this.Teacher.Name = "Teacher";
            this.Teacher.Size = new System.Drawing.Size(154, 120);
            this.Teacher.TabIndex = 1;
            this.Teacher.Text = "Teacher";
            this.Teacher.UseVisualStyleBackColor = false;
            this.Teacher.Click += new System.EventHandler(this.Teacher_Click);
            // 
            // Student
            // 
            this.Student.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Student.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Student.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Student.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Student.ForeColor = System.Drawing.Color.White;
            this.Student.Location = new System.Drawing.Point(0, 0);
            this.Student.Name = "Student";
            this.Student.Size = new System.Drawing.Size(154, 120);
            this.Student.TabIndex = 0;
            this.Student.Text = "Student";
            this.Student.UseVisualStyleBackColor = false;
            this.Student.Click += new System.EventHandler(this.Student_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 118);
            this.button2.TabIndex = 7;
            this.button2.Text = "Change Password";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // former
            // 
            this.former.BackColor = System.Drawing.Color.Gray;
            this.former.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.former.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.former.ForeColor = System.Drawing.Color.Black;
            this.former.Location = new System.Drawing.Point(1, -1);
            this.former.Name = "former";
            this.former.Size = new System.Drawing.Size(231, 59);
            this.former.TabIndex = 6;
            this.former.Text = "Former Student";
            this.former.UseVisualStyleBackColor = false;
            this.former.Click += new System.EventHandler(this.former_Click);
            // 
            // current
            // 
            this.current.BackColor = System.Drawing.Color.Gray;
            this.current.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.current.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.current.ForeColor = System.Drawing.Color.Black;
            this.current.Location = new System.Drawing.Point(0, 60);
            this.current.Name = "current";
            this.current.Size = new System.Drawing.Size(232, 59);
            this.current.TabIndex = 5;
            this.current.Text = "Current Student";
            this.current.UseVisualStyleBackColor = false;
            this.current.Click += new System.EventHandler(this.current_Click);
            // 
            // titlebar
            // 
            this.titlebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.titlebar.Controls.Add(this.splitter4);
            this.titlebar.Controls.Add(this.splitter3);
            this.titlebar.Controls.Add(this.panel4);
            this.titlebar.Controls.Add(this.panel3);
            this.titlebar.Controls.Add(this.splitter1);
            this.titlebar.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlebar.Location = new System.Drawing.Point(0, 0);
            this.titlebar.Name = "titlebar";
            this.titlebar.Size = new System.Drawing.Size(990, 127);
            this.titlebar.TabIndex = 8;
            // 
            // splitter4
            // 
            this.splitter4.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter4.Location = new System.Drawing.Point(862, 0);
            this.splitter4.Name = "splitter4";
            this.splitter4.Size = new System.Drawing.Size(3, 124);
            this.splitter4.TabIndex = 4;
            this.splitter4.TabStop = false;
            // 
            // splitter3
            // 
            this.splitter3.Location = new System.Drawing.Point(157, 0);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(3, 124);
            this.splitter3.TabIndex = 3;
            this.splitter3.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.logOut);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(865, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(125, 124);
            this.panel4.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = global::SIU_Project.Properties.Resources.maxresdefault;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(157, 124);
            this.panel3.TabIndex = 1;
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter1.Location = new System.Drawing.Point(0, 124);
            this.splitter1.Margin = new System.Windows.Forms.Padding(0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(990, 3);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.splitter2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 127);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(157, 597);
            this.panel1.TabIndex = 9;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button2);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 480);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(154, 120);
            this.panel5.TabIndex = 8;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.newUser);
            this.panel6.Controls.Add(this.splitter8);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 360);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(154, 120);
            this.panel6.TabIndex = 9;
            // 
            // splitter8
            // 
            this.splitter8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter8.Location = new System.Drawing.Point(0, 117);
            this.splitter8.Name = "splitter8";
            this.splitter8.Size = new System.Drawing.Size(154, 3);
            this.splitter8.TabIndex = 0;
            this.splitter8.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.splitter7);
            this.panel7.Controls.Add(this.Report);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 240);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(154, 120);
            this.panel7.TabIndex = 9;
            // 
            // splitter7
            // 
            this.splitter7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter7.Location = new System.Drawing.Point(0, 117);
            this.splitter7.Name = "splitter7";
            this.splitter7.Size = new System.Drawing.Size(154, 3);
            this.splitter7.TabIndex = 0;
            this.splitter7.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.splitter6);
            this.panel8.Controls.Add(this.Teacher);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 120);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(154, 120);
            this.panel8.TabIndex = 9;
            // 
            // splitter6
            // 
            this.splitter6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter6.Location = new System.Drawing.Point(0, 117);
            this.splitter6.Name = "splitter6";
            this.splitter6.Size = new System.Drawing.Size(154, 3);
            this.splitter6.TabIndex = 0;
            this.splitter6.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.splitter5);
            this.panel9.Controls.Add(this.Student);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(154, 120);
            this.panel9.TabIndex = 9;
            // 
            // splitter5
            // 
            this.splitter5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter5.Location = new System.Drawing.Point(0, 117);
            this.splitter5.Name = "splitter5";
            this.splitter5.Size = new System.Drawing.Size(154, 3);
            this.splitter5.TabIndex = 0;
            this.splitter5.TabStop = false;
            // 
            // splitter2
            // 
            this.splitter2.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter2.Location = new System.Drawing.Point(154, 0);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(3, 597);
            this.splitter2.TabIndex = 0;
            this.splitter2.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.current);
            this.panel2.Controls.Add(this.former);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(157, 127);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(833, 597);
            this.panel2.TabIndex = 10;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint_1);
            // 
            // logOut
            // 
            this.logOut.Dock = System.Windows.Forms.DockStyle.Top;
            this.logOut.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.logOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logOut.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.logOut.ForeColor = System.Drawing.Color.White;
            this.logOut.Location = new System.Drawing.Point(0, 0);
            this.logOut.Name = "logOut";
            this.logOut.Size = new System.Drawing.Size(125, 27);
            this.logOut.TabIndex = 7;
            this.logOut.Text = "Logout";
            this.logOut.UseVisualStyleBackColor = true;
            this.logOut.Click += new System.EventHandler(this.logOut_Click_1);
            // 
            // Head
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(990, 724);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.titlebar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Head";
            this.Text = "Head";
            this.Load += new System.EventHandler(this.Head_Load);
            this.titlebar.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button Report;
        private System.Windows.Forms.Button newUser;
        private System.Windows.Forms.Button Teacher;
        private System.Windows.Forms.Button Student;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button former;
        private System.Windows.Forms.Button current;
        private System.Windows.Forms.Panel titlebar;
        private System.Windows.Forms.Splitter splitter4;
        private System.Windows.Forms.Splitter splitter3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Splitter splitter2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Splitter splitter8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Splitter splitter7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Splitter splitter6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Splitter splitter5;
        private System.Windows.Forms.Button logOut;
    }
}