﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIU_Project
{
    public partial class Head : Form
    {
        String role;
        public Head()
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            role = "Head";
            InitializeComponent();
            current.Visible = false;
            former.Visible = false;
        }

        private void Head_Load(object sender, EventArgs e)
        {

        }



        private void Student_Click(object sender, EventArgs e)
        {
            current.Visible = true;
            former.Visible = true;
        }

       /* void loadForm() {
            StudentDetailCheck sCheck = new StudentDetailCheck();
            sCheck.TopLevel = false;
            sCheck.Parent = body;
            sCheck.Show();
        }*/

        private void current_Click(object sender, EventArgs e)
        {
            current.Visible = false;
            former.Visible = false;
            try
            {
                StudentDetailCheck sDetailCheckForm = new StudentDetailCheck();
                sDetailCheckForm.Show();
                sDetailCheckForm.statusE = "Active";
                sDetailCheckForm.fRole = role;
                //loadForm();
                //MessageBox.Show(sDetailCheckForm.statusE);
            }
            catch
            {
                MessageBox.Show("Error");
            }

        }

        private void former_Click(object sender, EventArgs e)
        {
            current.Visible = false;
            former.Visible = false;
            StudentDetailCheck sDetailCheckForm = new StudentDetailCheck();
            sDetailCheckForm.Show();
            // loadForm();
            sDetailCheckForm.statusE = "Deactive";
            sDetailCheckForm.fRole = role;

            // MessageBox.Show(sDetailCheckForm.statusE);
        }

        private void body_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void bodyClick(object sender, EventArgs e)
        {
            current.Visible = false;
            former.Visible = false;
        }

        private void newUser_Click(object sender, EventArgs e)
        {
            MessageBox.Show(role);
            CreateNewUser newuser = new CreateNewUser(role);
            newuser.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Report_Click(object sender, EventArgs e)
        {
            Teacher_Selection.Head_Report_Month_Selection reportHead = new Teacher_Selection.Head_Report_Month_Selection();
            reportHead.Show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Teacher_Click(object sender, EventArgs e)
        {

        }

        private void leftSide_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Close1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

       

       

        private void logOut_Click_1(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
