﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIU_Project
{
    public partial class Teacher : Form
    {
        string role = "Teacher";
        public Teacher()
        {
            InitializeComponent();
            
        }

        private void changepass_Click(object sender, EventArgs e)
        {
            MessageBox.Show(role);
            CreateNewUser frm = new CreateNewUser(role );
            frm.Show();
           
           /* String connection = @"Data Source=LAPTOP-LOGQKVQ5;Initial Catalog=SIU;Integrated Security=True";
            //open connection
            SqlConnection connecObj = new SqlConnection(connection);
            connecObj.Open();
            string pw1 = pw.Text;
            string query = "update LoginTable set Password='" + pw.Text + "' where UserName='" + username.Text + "'and Status='Active'";

            SqlCommand command = new SqlCommand(query, connecObj);


            command.ExecuteNonQuery();
            this.Close();
            MessageBox.Show("Password changed successfully." + "\n" + "New password:-" + pw1);
            connecObj.Close();*/
        }

        private void Teacher_Load(object sender, EventArgs e)
        {

        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void report_Click(object sender, EventArgs e)
        {
            Teacher_Selection.Teacher_Report_Month_Selection reportTeach = new Teacher_Selection.Teacher_Report_Month_Selection();
            reportTeach.Show();
        }
    }
}
