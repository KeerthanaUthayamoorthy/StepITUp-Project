﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIU_Project
{
    public partial class Admin : Form
    {
        String role;
        public Admin()
        {
            //this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            role = "Admin";
            InitializeComponent();
            current.Visible = false;
            former.Visible = false;
        }

        private void teacherselection_Click(object sender, EventArgs e)
        {
            Teacher_Selection.Form1 frm = new Teacher_Selection.Form1();
            frm.Show();
        }
        int checkName(String y) {
            
            String conn = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
            SqlConnection connObj1 = new SqlConnection(conn);
            connObj1.Open();
            string qu1 = "select BatchName from FinalBatchTable where BatchName='"+y+"'";
            SqlCommand comm = new SqlCommand(qu1,connObj1);
            SqlDataReader re = comm.ExecuteReader();
            int count = 0;
            try
            {
                MessageBox.Show("what");
                while (re.Read())
                {
                    count += 1;
                }
            }
            catch { }
            re.Close();
            connObj1.Close();
            return count;
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            balance.Visible = false;
            paymentpay.Visible = false;
            addstudent.Visible = false;
            search.Visible = false;
        }

        private void Payment_Click(object sender, EventArgs e)
        {

            balance.Visible = true;
            paymentpay.Visible = true;
        }

        private void balance_Click(object sender, EventArgs e)
        {
            balance.Visible = false;
            paymentpay.Visible = false;
            Teacher_Selection.Form4 frm = new Teacher_Selection.Form4();
            frm.Show();
        }

        private void paymentpay_Click(object sender, EventArgs e)
        {
            balance.Visible = false;
            paymentpay.Visible = false;
            Teacher_Selection.Form6 frm = new Teacher_Selection.Form6();
            frm.Show();
        }

        private void student_Click(object sender, EventArgs e)
        {
            addstudent.Visible = true;
            search.Visible = true;
        }

        private void addstudent_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
        }

        private void search_Click(object sender, EventArgs e)
        {
            current.Visible = true;
            former.Visible = true;
        }

        private void current_Click(object sender, EventArgs e)
        {
            current.Visible = false;
            former.Visible = false;
            try
            {
                StudentDetailCheck sDetailCheckForm = new StudentDetailCheck();
                sDetailCheckForm.Show();
                sDetailCheckForm.statusE = "Active";
                sDetailCheckForm.fRole = role;
                //loadForm();
                //MessageBox.Show(sDetailCheckForm.statusE);
            }
            catch
            {
                MessageBox.Show("Error");
            }

        }

        private void former_Click(object sender, EventArgs e)
        {
            current.Visible = false;
            former.Visible = false;
            StudentDetailCheck sDetailCheckForm = new StudentDetailCheck();
            sDetailCheckForm.Show();
            // loadForm();
            sDetailCheckForm.statusE = "Deactive";
            sDetailCheckForm.fRole = role;
        }

        private void bodyAdmin_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bodyAdminClick(object sender, EventArgs e)
        {
            balance.Visible = false;
            paymentpay.Visible = false;
            addstudent.Visible = false;
            search.Visible = false;
        }

        private void chgPassWord_Click(object sender, EventArgs e)
        {

        }

        
        

        private void batch_Click(object sender, EventArgs e)
        {
            if (batch.Enabled==false) {
                MessageBox.Show("You are not allowed now");
            }
            String connection = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
            String y = "" ;
            String date=DateTime.Now.ToShortDateString();
            String month = DateTime.Now.Month.ToString();
            String year = DateTime.Now.Year.ToString();
            MessageBox.Show(month);
            //--------------------------------
            
            //----------------------------------
            if (month == "12" || month == "1") {
                if (month == "12") {
                    y = (Convert.ToInt32(year) + 3).ToString();
                   

                        try
                        {
                            String connection1 = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
                            //String connection = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
                            SqlConnection connecObj1 = new SqlConnection(connection1);
                            connecObj1.Open();
                            string query1 = "update FinalBatchTable set Status= 'Deactive' where BatchName='" + year + "'";
                            SqlCommand command1 = new SqlCommand(query1, connecObj1);
                            command1.ExecuteNonQuery();
                            MessageBox.Show(year);
                            connecObj1.Close();
                        }
                        catch (Exception ex) { MessageBox.Show(ex.ToString()); }

                    
                }
                else if (month == "1") {
                    y = (Convert.ToInt32(year) + 2).ToString();
                    String yDel = (Convert.ToInt32(year)-1).ToString();
                    try
                    {
                        //String connection = @"Data Source=DESKTOP-MV18312;Initial Catalog=SIU_database;Integrated Security=True";
                        SqlConnection connecObj1 = new SqlConnection(connection);
                        connecObj1.Open();
                        string query1 = "update FinalBatchTable set Status= 'Deactive' where BatchName='" + yDel + "'";
                        SqlCommand command1 = new SqlCommand(query1, connecObj1);
                        command1.ExecuteNonQuery();
                        connecObj1.Close();
                    }
                    catch { }
                    

                }
                if (checkName(y) == 0)
                {
                    SqlConnection connecObj = new SqlConnection(connection);
                    connecObj.Open();
                    string query = "insert into FinalBatchTable(BatchName,StartedDate,Status) VALUES  ( '" + y + "','" + date + "', 'Active')";
                    SqlCommand command = new SqlCommand(query, connecObj);
                    command.ExecuteNonQuery();
                    connecObj.Close();
                    MessageBox.Show("New batch is created");
                }
                else { MessageBox.Show("already exists"); }
            } else {
                MessageBox.Show("You aren't allowed to create new batch now");
            }
            
        }

        private void CloseX_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
